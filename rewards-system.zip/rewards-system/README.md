# نظام إدارة المكافآت – Rewards Management System

نظام متكامل لإدارة مكافآت الموظفين مبني بـ FastAPI + Vue.js + PostgreSQL + Redis.

---

## 🗂️ هيكل المشروع

```
rewards-system/
├── backend/                  # FastAPI backend
│   ├── app/
│   │   ├── api/v1/endpoints/ # جميع endpoints (auth, areas, employees, awards, ...)
│   │   ├── core/             # config, security, deps, redis
│   │   ├── db/               # session, Base
│   │   ├── models/           # SQLAlchemy models
│   │   ├── schemas/          # Pydantic schemas
│   │   ├── services/         # logging_service
│   │   └── scripts/          # seed_data.py, import_data.py
│   ├── alembic/              # قواعد البيانات migration
│   ├── alembic.ini
│   ├── requirements.txt
│   └── Dockerfile
│
├── frontend/                 # Vue 3 + Element Plus
│   ├── src/
│   │   ├── api/              # axios client + resource helpers
│   │   ├── components/       # DataTable, NotificationPanel, AppLayout
│   │   ├── router/           # Vue Router + auth guards
│   │   ├── stores/           # Pinia (auth)
│   │   └── views/            # dashboard, area, employee, empjob, awdeg, awardes, users, logs, settings
│   ├── vite.config.js
│   ├── package.json
│   └── Dockerfile
│
├── desktop/                  # Flet desktop app (Python)
│   ├── main.py
│   └── requirements.txt
│
├── mobile/                   # Flutter mobile app
│   ├── lib/
│   │   ├── main.dart
│   │   ├── screens/
│   │   └── services/
│   └── pubspec.yaml
│
├── nginx/
│   └── nginx.conf
├── docker-compose.yml
└── .env
```

---

## 🚀 تشغيل المشروع

### المتطلبات الأساسية
- Docker Desktop (أو Docker + Docker Compose)
- Git

### خطوات التشغيل

```bash
# 1. استنسخ المشروع
git clone <repo-url> rewards-system
cd rewards-system

# 2. انسخ ملف الإعدادات وعدّل القيم
cp .env .env.local
# افتح .env وعدّل كلمات المرور والمفاتيح

# 3. شغّل كل شيء دفعة واحدة
docker-compose up --build

# 4. الوصول:
#    Frontend  → http://localhost:5173  (أو http://localhost عبر Nginx)
#    Backend   → http://localhost:8000
#    API Docs  → http://localhost:8000/docs
#    pgAdmin   → استخدم أي عميل PostgreSQL على المنفذ 5432
```

---

## 👤 إنشاء أول مستخدم (Admin)

يتم تلقائياً عند أول تشغيل بناءً على متغيرات البيئة:

```env
FIRST_ADMIN_EMAIL=admin@example.com
FIRST_ADMIN_PASSWORD=Admin@123456
FIRST_ADMIN_NAME=System Admin
```

أو يدوياً:

```bash
docker exec -it rewards_backend python -m app.scripts.seed_data
```

---

## 📥 استيراد البيانات القديمة (من Django)

### تصدير البيانات من Django القديم:

```bash
# في مشروع Django القديم:
python manage.py dumpdata awards.area --format=csv > area.csv
python manage.py dumpdata awards.empjob --format=csv > empjob.csv
# أو عبر pgAdmin / psql:
COPY area TO '/tmp/area.csv' CSV HEADER;
COPY empjob TO '/tmp/empjob.csv' CSV HEADER;
COPY awdeg TO '/tmp/awdeg.csv' CSV HEADER;
COPY awardes TO '/tmp/awardes.csv' CSV HEADER;
COPY employee TO '/tmp/employee.csv' CSV HEADER;
COPY awemp TO '/tmp/awemp.csv' CSV HEADER;
```

### تشغيل سكريبت الاستيراد:

```bash
# انسخ ملفات CSV إلى الحاوية
docker cp /path/to/csvs/. rewards_backend:/tmp/import_data/

# شغّل السكريبت
docker exec -it rewards_backend python -m app.scripts.import_data --data-dir /tmp/import_data

# أو من خارج Docker (مع ضبط DATABASE_URL):
cd backend
python -m app.scripts.import_data --data-dir /path/to/csvs
```

**صيغة ملفات CSV المتوقعة:**

| ملف | الأعمدة المطلوبة |
|-----|-----------------|
| `area.csv` | `area_id, area_name` |
| `empjob.csv` | `job_id, job_name` |
| `awdeg.csv` | `deg_id, deg_name, def_mony, tax_percent` |
| `awardes.csv` | `award_id, award_title, award_reson, award_date` |
| `employee.csv` | `emp_id, emp_name, file_number, area_id, job_id, deg_id` |
| `awemp.csv` | `award_id, emp_id, aw_mony, tax_percent_applied, total_amount, award_date` |

---

## 🔑 Google OAuth

### إعداد Google Cloud Console:
1. اذهب إلى [console.cloud.google.com](https://console.cloud.google.com)
2. أنشئ مشروعاً جديداً
3. فعّل **Google OAuth 2.0**
4. أنشئ **OAuth Client ID** من نوع **Web application**
5. أضف `http://localhost:8000/api/v1/auth/google/callback` في Authorized redirect URIs

### أضف في `.env`:
```env
GOOGLE_CLIENT_ID=xxxxxxxxxx.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=GOCSPX-xxxxxxxxxx
GOOGLE_REDIRECT_URI=http://localhost:8000/api/v1/auth/google/callback
```

---

## 📋 نظام الصلاحيات

### المجموعات الافتراضية:

| المجموعة | الصلاحيات |
|---------|-----------|
| `إدارة الموقع` | كل الصلاحيات |
| `تعديل` | add + change + view على الجداول الرئيسية |
| `إدخال` | add + view فقط |
| `مشرف` | view فقط |

### صلاحيات المستخدم `global_admin`:
يتجاوز كل الصلاحيات — يرى ويفعل كل شيء.

---

## 📤 التصدير إلى Word

### رفع قالب مخصص:
1. اذهب إلى **الإعدادات → قوالب التصدير**
2. ارفع ملف `.docx` يحتوي على متغيرات `docxtpl`:

```
{{ award_title }}
{{ award_date }}
{% for emp in employees %}
  {{ emp.emp_name }} - {{ emp.total_amount }}
{% endfor %}
```

### المتغيرات المتاحة لقرارات المكافآت:
- `award_title`, `award_reson`, `award_date`
- `export_date`
- `employees[]`: `emp_name, file_number, area, job, aw_mony, tax_percent, total_amount, award_date`
- `total_sum`

---

## 🖥️ تطبيق سطح المكتب (Flet)

```bash
cd desktop
pip install -r requirements.txt
python main.py
```

يتصل بالـ API على `http://localhost:8000` بشكل افتراضي.

---

## 📱 تطبيق الموبايل (Flutter)

```bash
cd mobile
flutter pub get
flutter run
```

> **ملاحظة:** في محاكي Android، عنوان الخادم هو `http://10.0.2.2:8000` (يُشير إلى localhost).
> للأجهزة الحقيقية، استخدم IP الشبكة المحلية لجهازك.

---

## 🗄️ قاعدة البيانات

### الاتصال المباشر:
```bash
docker exec -it rewards_db psql -U rewards_user -d rewards_db
```

### تشغيل migration يدوياً:
```bash
docker exec -it rewards_backend alembic upgrade head
```

### إنشاء migration جديد:
```bash
docker exec -it rewards_backend alembic revision --autogenerate -m "description"
```

---

## 🌐 API Documentation

بعد تشغيل المشروع:
- **Swagger UI**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc
- **OpenAPI JSON**: http://localhost:8000/openapi.json

### أمثلة على API:

```bash
# تسجيل الدخول
curl -X POST http://localhost:8000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username": "admin@example.com", "password": "Admin@123456"}'

# جلب قائمة الموظفين
curl http://localhost:8000/api/v1/employees \
  -H "Authorization: Bearer <token>"

# إضافة موظف
curl -X POST http://localhost:8000/api/v1/employees \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{"emp_name": "محمد أحمد", "file_number": "123456", "area_id": 1}'
```

---

## 🏗️ Soft Delete

جميع الجداول تدعم **Soft Delete** (لا حذف نهائي):
- الحذف يضبط `deleted_at = now()`
- جميع الاستعلامات تتجاهل السجلات المحذوفة تلقائياً
- **جدول `log`**: محمي من الحذف والتعديل عبر قواعد PostgreSQL

---

## 🔧 متغيرات البيئة الكاملة

```env
# قاعدة البيانات
POSTGRES_DB=rewards_db
POSTGRES_USER=rewards_user
POSTGRES_PASSWORD=rewards_pass_change_me

# Redis
REDIS_URL=redis://redis:6379/0

# JWT
SECRET_KEY=your-super-secret-key-min-32-chars
ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=30
REFRESH_TOKEN_EXPIRE_DAYS=7

# Google OAuth (اختياري)
GOOGLE_CLIENT_ID=
GOOGLE_CLIENT_SECRET=
GOOGLE_REDIRECT_URI=http://localhost:8000/api/v1/auth/google/callback

# أول مستخدم Admin
FIRST_ADMIN_EMAIL=admin@example.com
FIRST_ADMIN_PASSWORD=Admin@123456
FIRST_ADMIN_NAME=System Admin

# Frontend
VITE_API_URL=http://localhost:8000
```

---

## 🐛 استكشاف الأخطاء

### المشكلة: الـ backend لا يبدأ
```bash
# تحقق من logs
docker-compose logs backend

# تأكد من أن قاعدة البيانات جاهزة
docker-compose ps
```

### المشكلة: خطأ في migration
```bash
docker exec -it rewards_backend alembic upgrade head
```

### المشكلة: Frontend لا يتصل بالـ API
```bash
# تأكد من VITE_API_URL في .env
# أو عدّل في vite.config.js proxy
```

---

## 📄 الترخيص

هذا النظام مملوك لمؤسستك. جميع الحقوق محفوظة.

"""initial migration

Revision ID: 001_initial
Revises: 
Create Date: 2024-01-01 00:00:00.000000
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = '001_initial'
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    # area
    op.create_table('area',
        sa.Column('area_id', sa.Integer(), nullable=False),
        sa.Column('area_name', sa.String(255), nullable=False),
        sa.Column('deleted_at', sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint('area_id')
    )
    op.create_index('ix_area_area_id', 'area', ['area_id'])

    # empjob
    op.create_table('empjob',
        sa.Column('job_id', sa.Integer(), nullable=False),
        sa.Column('job_name', sa.String(255), nullable=False),
        sa.Column('deleted_at', sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint('job_id')
    )

    # awdeg
    op.create_table('awdeg',
        sa.Column('deg_id', sa.Integer(), nullable=False),
        sa.Column('deg_name', sa.String(255), nullable=True),
        sa.Column('def_mony', sa.Numeric(10, 2), nullable=True),
        sa.Column('rate', sa.Numeric(10, 2), nullable=True),
        sa.Column('tax_percent', sa.Numeric(5, 2), nullable=True, server_default='0'),
        sa.Column('deleted_at', sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint('deg_id')
    )

    # awardes
    op.create_table('awardes',
        sa.Column('award_id', sa.Integer(), nullable=False),
        sa.Column('award_title', sa.String(255), nullable=True),
        sa.Column('award_reson', sa.Text(), nullable=True),
        sa.Column('award_date', sa.DateTime(), nullable=True),
        sa.Column('deleted_at', sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint('award_id')
    )

    # employee
    op.create_table('employee',
        sa.Column('emp_id', sa.Integer(), nullable=False),
        sa.Column('file_number', sa.String(6), nullable=True),
        sa.Column('emp_name', sa.String(255), nullable=True),
        sa.Column('area_id', sa.Integer(), nullable=True),
        sa.Column('job_id', sa.Integer(), nullable=True),
        sa.Column('deg_id', sa.Integer(), nullable=True),
        sa.Column('deleted_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['area_id'], ['area.area_id'], ondelete='SET NULL'),
        sa.ForeignKeyConstraint(['job_id'], ['empjob.job_id'], ondelete='SET NULL'),
        sa.ForeignKeyConstraint(['deg_id'], ['awdeg.deg_id'], ondelete='SET NULL'),
        sa.PrimaryKeyConstraint('emp_id'),
        sa.UniqueConstraint('file_number')
    )

    # awemp
    op.create_table('awemp',
        sa.Column('awemp_id', sa.Integer(), nullable=False),
        sa.Column('award_id', sa.Integer(), nullable=False),
        sa.Column('emp_id', sa.Integer(), nullable=False),
        sa.Column('aw_mony', sa.Numeric(10, 2), nullable=True),
        sa.Column('award_date', sa.Date(), nullable=True),
        sa.Column('tax_percent_applied', sa.Numeric(5, 2), nullable=True),
        sa.Column('total_amount', sa.Numeric(10, 2), nullable=True),
        sa.Column('deleted_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['award_id'], ['awardes.award_id'], ondelete='CASCADE'),
        sa.ForeignKeyConstraint(['emp_id'], ['employee.emp_id'], ondelete='CASCADE'),
        sa.PrimaryKeyConstraint('awemp_id')
    )

    # users
    op.create_table('users',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('full_name', sa.String(255), nullable=False),
        sa.Column('employee_number', sa.String(50), nullable=True),
        sa.Column('email', sa.String(255), nullable=False),
        sa.Column('password_hash', sa.String(255), nullable=True),
        sa.Column('is_active', sa.Boolean(), nullable=True, server_default='true'),
        sa.Column('global_admin', sa.Boolean(), nullable=True, server_default='false'),
        sa.Column('avatar_url', sa.Text(), nullable=True),
        sa.Column('google_id', sa.String(255), nullable=True),
        sa.Column('last_login', sa.DateTime(), nullable=True),
        sa.Column('date_joined', sa.DateTime(), server_default=sa.text('now()'), nullable=True),
        sa.Column('deleted_at', sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('email'),
        sa.UniqueConstraint('employee_number'),
        sa.UniqueConstraint('google_id')
    )

    # log
    op.create_table('log',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('user_id', sa.Integer(), nullable=True),
        sa.Column('action_type', sa.String(50), nullable=False),
        sa.Column('table_name', sa.String(100), nullable=False),
        sa.Column('record_id', sa.Integer(), nullable=True),
        sa.Column('old_data', postgresql.JSONB(), nullable=True),
        sa.Column('new_data', postgresql.JSONB(), nullable=True),
        sa.Column('ip_address', sa.String(45), nullable=True),
        sa.Column('created_at', sa.DateTime(), server_default=sa.text('now()'), nullable=False),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], ondelete='SET NULL'),
        sa.PrimaryKeyConstraint('id')
    )

    # notification
    op.create_table('notification',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('user_id', sa.Integer(), nullable=False),
        sa.Column('title', sa.String(255), nullable=False),
        sa.Column('message', sa.Text(), nullable=False),
        sa.Column('is_read', sa.Boolean(), server_default='false', nullable=True),
        sa.Column('created_at', sa.DateTime(), server_default=sa.text('now()'), nullable=True),
        sa.Column('deleted_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], ondelete='CASCADE'),
        sa.PrimaryKeyConstraint('id')
    )

    # groups
    op.create_table('groups',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('name', sa.String(100), nullable=False),
        sa.Column('deleted_at', sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('name')
    )

    # permissions
    op.create_table('permissions',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('codename', sa.String(100), nullable=False),
        sa.Column('name', sa.String(255), nullable=False),
        sa.Column('content_type', sa.String(100), nullable=False),
        sa.Column('deleted_at', sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('codename')
    )

    # user_group
    op.create_table('user_group',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('user_id', sa.Integer(), nullable=False),
        sa.Column('group_id', sa.Integer(), nullable=False),
        sa.ForeignKeyConstraint(['group_id'], ['groups.id'], ondelete='CASCADE'),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], ondelete='CASCADE'),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('user_id', 'group_id')
    )

    # group_permission
    op.create_table('group_permission',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('group_id', sa.Integer(), nullable=False),
        sa.Column('permission_id', sa.Integer(), nullable=False),
        sa.ForeignKeyConstraint(['group_id'], ['groups.id'], ondelete='CASCADE'),
        sa.ForeignKeyConstraint(['permission_id'], ['permissions.id'], ondelete='CASCADE'),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('group_id', 'permission_id')
    )

    # export_template
    op.create_table('export_template',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('name', sa.String(255), nullable=False),
        sa.Column('table_name', sa.String(100), nullable=False),
        sa.Column('export_type', sa.Enum('table_only', 'related', name='exporttype'), nullable=False, server_default='table_only'),
        sa.Column('template_path', sa.String(500), nullable=True),
        sa.Column('is_default', sa.Boolean(), server_default='false', nullable=True),
        sa.Column('created_at', sa.DateTime(), server_default=sa.text('now()'), nullable=True),
        sa.Column('deleted_at', sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint('id')
    )

    # Protect log table: create a rule to prevent DELETE and UPDATE
    op.execute("""
        CREATE RULE no_update_log AS ON UPDATE TO log DO INSTEAD NOTHING;
        CREATE RULE no_delete_log AS ON DELETE TO log DO INSTEAD NOTHING;
    """)


def downgrade() -> None:
    op.execute("DROP RULE IF EXISTS no_update_log ON log")
    op.execute("DROP RULE IF EXISTS no_delete_log ON log")

    for tbl in [
        'export_template', 'group_permission', 'user_group',
        'permissions', 'groups', 'notification', 'log', 'users',
        'awemp', 'employee', 'awardes', 'awdeg', 'empjob', 'area'
    ]:
        op.drop_table(tbl)

    op.execute("DROP TYPE IF EXISTS exporttype")

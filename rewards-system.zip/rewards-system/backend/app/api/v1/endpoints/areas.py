from fastapi import APIRouter, Depends, HTTPException, Query, Request
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, or_
from sqlalchemy.orm import selectinload
from typing import Optional, List
from datetime import datetime

from app.db.session import get_db
from app.models.models import Area, Employee
from app.schemas.schemas import (
    AreaCreate, AreaUpdate, AreaOut, AreaWithEmployees,
    PaginatedResponse, BulkDeleteRequest, BulkDeleteResponse
)
from app.core.deps import get_current_active_user, require_permission
from app.services.logging_service import create_log, model_to_dict
from app.models.models import User

router = APIRouter()


@router.get("", response_model=PaginatedResponse)
async def list_areas(
    page: int = Query(1, ge=1),
    page_size: int = Query(25, ge=1, le=100),
    search: Optional[str] = None,
    sort_by: str = Query("area_id"),
    sort_dir: str = Query("asc"),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("view_area")),
):
    query = select(Area).where(Area.deleted_at.is_(None))

    if search:
        query = query.where(Area.area_name.ilike(f"%{search}%"))

    # Count total
    count_q = select(func.count()).select_from(query.subquery())
    total = (await db.execute(count_q)).scalar()

    # Sort
    sort_col = getattr(Area, sort_by, Area.area_id)
    if sort_dir == "desc":
        sort_col = sort_col.desc()
    query = query.order_by(sort_col)

    # Paginate
    offset = (page - 1) * page_size
    query = query.offset(offset).limit(page_size)

    result = await db.execute(query)
    areas = result.scalars().all()

    return PaginatedResponse(
        items=[AreaOut.model_validate(a) for a in areas],
        total=total,
        page=page,
        page_size=page_size,
        pages=(total + page_size - 1) // page_size,
    )


@router.get("/{area_id}", response_model=AreaWithEmployees)
async def get_area(
    area_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("view_area")),
):
    result = await db.execute(
        select(Area).where(Area.area_id == area_id, Area.deleted_at.is_(None))
        .options(selectinload(Area.employees))
    )
    area = result.scalar_one_or_none()
    if not area:
        raise HTTPException(status_code=404, detail="Area not found")
    return area


@router.post("", response_model=AreaOut, status_code=201)
async def create_area(
    request: Request,
    body: AreaCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("add_area")),
):
    area = Area(**body.model_dump())
    db.add(area)
    await db.flush()
    await create_log(db, "create", "area", user_id=current_user.id, record_id=area.area_id,
                     new_data=model_to_dict(area), ip_address=request.client.host if request.client else None)
    await db.commit()
    await db.refresh(area)
    return area


@router.put("/{area_id}", response_model=AreaOut)
async def update_area(
    area_id: int,
    request: Request,
    body: AreaUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("change_area")),
):
    result = await db.execute(
        select(Area).where(Area.area_id == area_id, Area.deleted_at.is_(None))
    )
    area = result.scalar_one_or_none()
    if not area:
        raise HTTPException(status_code=404, detail="Area not found")

    old_data = model_to_dict(area)
    for k, v in body.model_dump(exclude_unset=True).items():
        setattr(area, k, v)

    await create_log(db, "update", "area", user_id=current_user.id, record_id=area_id,
                     old_data=old_data, new_data=model_to_dict(area),
                     ip_address=request.client.host if request.client else None)
    await db.commit()
    await db.refresh(area)
    return area


@router.delete("/{area_id}")
async def delete_area(
    area_id: int,
    request: Request,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("delete_area")),
):
    result = await db.execute(
        select(Area).where(Area.area_id == area_id, Area.deleted_at.is_(None))
    )
    area = result.scalar_one_or_none()
    if not area:
        raise HTTPException(status_code=404, detail="Area not found")

    old_data = model_to_dict(area)
    area.deleted_at = datetime.utcnow()
    await create_log(db, "delete", "area", user_id=current_user.id, record_id=area_id,
                     old_data=old_data, ip_address=request.client.host if request.client else None)
    await db.commit()
    return {"message": "Area deleted", "area_id": area_id}


@router.post("/bulk-delete", response_model=BulkDeleteResponse)
async def bulk_delete_areas(
    request: Request,
    body: BulkDeleteRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("delete_area")),
):
    now = datetime.utcnow()
    deleted_ids = []
    for area_id in body.ids:
        result = await db.execute(
            select(Area).where(Area.area_id == area_id, Area.deleted_at.is_(None))
        )
        area = result.scalar_one_or_none()
        if area:
            area.deleted_at = now
            deleted_ids.append(area_id)

    await create_log(db, "bulk_delete", "area", user_id=current_user.id,
                     new_data={"deleted_ids": deleted_ids},
                     ip_address=request.client.host if request.client else None)
    await db.commit()
    return BulkDeleteResponse(deleted_count=len(deleted_ids), ids=deleted_ids)


@router.get("/{area_id}/stats")
async def area_stats(
    area_id: int,
    date_from: Optional[str] = None,
    date_to: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("view_area")),
):
    """Get total rewards for employees in an area."""
    from sqlalchemy import and_
    from app.models.models import AweEmp

    query = (
        select(func.sum(AweEmp.total_amount))
        .join(Employee, AweEmp.emp_id == Employee.emp_id)
        .where(
            Employee.area_id == area_id,
            Employee.deleted_at.is_(None),
            AweEmp.deleted_at.is_(None),
        )
    )

    if date_from:
        query = query.where(AweEmp.award_date >= date_from)
    if date_to:
        query = query.where(AweEmp.award_date <= date_to)

    total = (await db.execute(query)).scalar() or 0

    emp_count_q = select(func.count(Employee.emp_id)).where(
        Employee.area_id == area_id, Employee.deleted_at.is_(None)
    )
    emp_count = (await db.execute(emp_count_q)).scalar() or 0

    return {"area_id": area_id, "employee_count": emp_count, "total_rewards": float(total)}

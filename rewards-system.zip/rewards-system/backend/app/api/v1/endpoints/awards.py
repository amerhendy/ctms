from fastapi import APIRouter, Depends, HTTPException, Query, Request
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, or_, and_
from typing import Optional, List
from datetime import datetime

from app.db.session import get_db
from app.models.models import Awardes, AweEmp, Employee, AwDeg
from app.schemas.schemas import (
    AwardesCreate, AwardesUpdate, AwardesOut,
    AweEmpCreate, AweEmpUpdate, AweEmpOut, AweEmpWithDetails,
    PaginatedResponse, BulkDeleteRequest, BulkDeleteResponse
)
from app.core.deps import get_current_active_user, require_permission
from app.services.logging_service import create_log, model_to_dict
from app.models.models import User

router = APIRouter()


@router.get("", response_model=PaginatedResponse)
async def list_awards(
    page: int = Query(1, ge=1),
    page_size: int = Query(25, ge=1, le=100),
    search: Optional[str] = None,
    year: Optional[int] = None,
    month: Optional[int] = None,
    date_from: Optional[str] = None,
    date_to: Optional[str] = None,
    sort_by: str = Query("award_id"),
    sort_dir: str = Query("desc"),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("view_awardes")),
):
    query = select(Awardes).where(Awardes.deleted_at.is_(None))

    if search:
        query = query.where(
            or_(
                Awardes.award_title.ilike(f"%{search}%"),
                Awardes.award_reson.ilike(f"%{search}%"),
            )
        )
    if year:
        query = query.where(func.extract("year", Awardes.award_date) == year)
    if month:
        query = query.where(func.extract("month", Awardes.award_date) == month)
    if date_from:
        query = query.where(Awardes.award_date >= date_from)
    if date_to:
        query = query.where(Awardes.award_date <= date_to)

    total = (await db.execute(select(func.count()).select_from(query.subquery()))).scalar()

    sort_col = getattr(Awardes, sort_by, Awardes.award_id)
    if sort_dir == "desc":
        sort_col = sort_col.desc()
    query = query.order_by(sort_col).offset((page - 1) * page_size).limit(page_size)

    result = await db.execute(query)
    awards = result.scalars().all()

    return PaginatedResponse(
        items=[AwardesOut.model_validate(a) for a in awards],
        total=total,
        page=page,
        page_size=page_size,
        pages=(total + page_size - 1) // page_size,
    )


@router.get("/{award_id}", response_model=AwardesOut)
async def get_award(
    award_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("view_awardes")),
):
    result = await db.execute(
        select(Awardes).where(Awardes.award_id == award_id, Awardes.deleted_at.is_(None))
    )
    award = result.scalar_one_or_none()
    if not award:
        raise HTTPException(status_code=404, detail="Award not found")
    return award


@router.get("/{award_id}/employees")
async def get_award_employees(
    award_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("view_awardes")),
):
    """Get all employees linked to an award with their amounts."""
    result = await db.execute(
        select(AweEmp).where(
            AweEmp.award_id == award_id,
            AweEmp.deleted_at.is_(None),
        )
    )
    records = result.scalars().all()
    return [AweEmpWithDetails.model_validate(r) for r in records]


@router.post("", response_model=AwardesOut, status_code=201)
async def create_award(
    request: Request,
    body: AwardesCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("add_awardes")),
):
    award = Awardes(**body.model_dump())
    db.add(award)
    await db.flush()
    await create_log(db, "create", "awardes", user_id=current_user.id, record_id=award.award_id,
                     new_data=model_to_dict(award), ip_address=request.client.host if request.client else None)
    await db.commit()
    await db.refresh(award)
    return award


@router.put("/{award_id}", response_model=AwardesOut)
async def update_award(
    award_id: int,
    request: Request,
    body: AwardesUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("change_awardes")),
):
    result = await db.execute(
        select(Awardes).where(Awardes.award_id == award_id, Awardes.deleted_at.is_(None))
    )
    award = result.scalar_one_or_none()
    if not award:
        raise HTTPException(status_code=404, detail="Award not found")

    old_data = model_to_dict(award)
    for k, v in body.model_dump(exclude_unset=True).items():
        setattr(award, k, v)

    await create_log(db, "update", "awardes", user_id=current_user.id, record_id=award_id,
                     old_data=old_data, new_data=model_to_dict(award),
                     ip_address=request.client.host if request.client else None)
    await db.commit()
    await db.refresh(award)
    return award


@router.delete("/{award_id}")
async def delete_award(
    award_id: int,
    request: Request,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("delete_awardes")),
):
    result = await db.execute(
        select(Awardes).where(Awardes.award_id == award_id, Awardes.deleted_at.is_(None))
    )
    award = result.scalar_one_or_none()
    if not award:
        raise HTTPException(status_code=404, detail="Award not found")

    old_data = model_to_dict(award)
    award.deleted_at = datetime.utcnow()
    await create_log(db, "delete", "awardes", user_id=current_user.id, record_id=award_id,
                     old_data=old_data, ip_address=request.client.host if request.client else None)
    await db.commit()
    return {"message": "Award deleted", "award_id": award_id}


@router.post("/bulk-delete", response_model=BulkDeleteResponse)
async def bulk_delete_awards(
    request: Request,
    body: BulkDeleteRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("delete_awardes")),
):
    now = datetime.utcnow()
    deleted_ids = []
    for award_id in body.ids:
        result = await db.execute(
            select(Awardes).where(Awardes.award_id == award_id, Awardes.deleted_at.is_(None))
        )
        a = result.scalar_one_or_none()
        if a:
            a.deleted_at = now
            deleted_ids.append(award_id)

    await create_log(db, "bulk_delete", "awardes", user_id=current_user.id,
                     new_data={"deleted_ids": deleted_ids},
                     ip_address=request.client.host if request.client else None)
    await db.commit()
    return BulkDeleteResponse(deleted_count=len(deleted_ids), ids=deleted_ids)


# ─── AweEmp (Award-Employee link) endpoints ───

@router.post("/{award_id}/employees", response_model=AweEmpOut, status_code=201)
async def add_employee_to_award(
    award_id: int,
    request: Request,
    body: AweEmpCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("add_awemp")),
):
    body_data = body.model_dump()
    body_data["award_id"] = award_id

    # Auto-fill from employee degree if not provided
    if body.emp_id:
        emp_r = await db.execute(
            select(Employee).where(Employee.emp_id == body.emp_id, Employee.deleted_at.is_(None))
        )
        emp = emp_r.scalar_one_or_none()
        if emp and emp.deg_id:
            deg_r = await db.execute(
                select(AwDeg).where(AwDeg.deg_id == emp.deg_id, AwDeg.deleted_at.is_(None))
            )
            deg = deg_r.scalar_one_or_none()
            if deg:
                if body_data.get("aw_mony") is None:
                    body_data["aw_mony"] = deg.def_mony
                if body_data.get("tax_percent_applied") is None:
                    body_data["tax_percent_applied"] = deg.tax_percent
                if body_data.get("total_amount") is None and body_data.get("aw_mony"):
                    m = float(body_data["aw_mony"])
                    t = float(body_data.get("tax_percent_applied") or 0)
                    body_data["total_amount"] = round(m + (m * t / 100), 2)

    awemp = AweEmp(**body_data)
    db.add(awemp)
    await db.flush()

    await create_log(db, "create", "awemp", user_id=current_user.id, record_id=awemp.awemp_id,
                     new_data=model_to_dict(awemp), ip_address=request.client.host if request.client else None)
    await db.commit()
    await db.refresh(awemp)
    return awemp


@router.put("/awemp/{awemp_id}", response_model=AweEmpOut)
async def update_awemp(
    awemp_id: int,
    request: Request,
    body: AweEmpUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("change_awemp")),
):
    result = await db.execute(
        select(AweEmp).where(AweEmp.awemp_id == awemp_id, AweEmp.deleted_at.is_(None))
    )
    awemp = result.scalar_one_or_none()
    if not awemp:
        raise HTTPException(status_code=404, detail="Record not found")

    old_data = model_to_dict(awemp)
    for k, v in body.model_dump(exclude_unset=True).items():
        setattr(awemp, k, v)

    await create_log(db, "update", "awemp", user_id=current_user.id, record_id=awemp_id,
                     old_data=old_data, new_data=model_to_dict(awemp),
                     ip_address=request.client.host if request.client else None)
    await db.commit()
    await db.refresh(awemp)
    return awemp


@router.delete("/awemp/{awemp_id}")
async def delete_awemp(
    awemp_id: int,
    request: Request,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("delete_awemp")),
):
    result = await db.execute(
        select(AweEmp).where(AweEmp.awemp_id == awemp_id, AweEmp.deleted_at.is_(None))
    )
    awemp = result.scalar_one_or_none()
    if not awemp:
        raise HTTPException(status_code=404, detail="Record not found")

    old_data = model_to_dict(awemp)
    awemp.deleted_at = datetime.utcnow()
    await create_log(db, "delete", "awemp", user_id=current_user.id, record_id=awemp_id,
                     old_data=old_data, ip_address=request.client.host if request.client else None)
    await db.commit()
    return {"message": "Record deleted", "awemp_id": awemp_id}

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from typing import Optional
from datetime import datetime

from app.db.session import get_db
from app.models.models import EmpJob, AwDeg, Employee
from app.schemas.schemas import (
    EmpJobCreate, EmpJobUpdate, EmpJobOut,
    AwDegCreate, AwDegUpdate, AwDegOut,
    PaginatedResponse, BulkDeleteRequest, BulkDeleteResponse
)
from app.core.deps import require_permission
from app.services.logging_service import create_log, model_to_dict
from app.models.models import User

job_router = APIRouter()
deg_router = APIRouter()


# ─── EmpJob ───────────────────────────────────

@job_router.get("", response_model=PaginatedResponse)
async def list_jobs(
    page: int = Query(1, ge=1),
    page_size: int = Query(25, ge=1, le=100),
    search: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("view_empjob")),
):
    query = select(EmpJob).where(EmpJob.deleted_at.is_(None))
    if search:
        query = query.where(EmpJob.job_name.ilike(f"%{search}%"))

    total = (await db.execute(select(func.count()).select_from(query.subquery()))).scalar()
    result = await db.execute(query.offset((page - 1) * page_size).limit(page_size))
    jobs = result.scalars().all()

    return PaginatedResponse(
        items=[EmpJobOut.model_validate(j) for j in jobs],
        total=total, page=page, page_size=page_size,
        pages=(total + page_size - 1) // page_size,
    )


@job_router.get("/{job_id}", response_model=EmpJobOut)
async def get_job(job_id: int, db: AsyncSession = Depends(get_db),
                  current_user: User = Depends(require_permission("view_empjob"))):
    result = await db.execute(select(EmpJob).where(EmpJob.job_id == job_id, EmpJob.deleted_at.is_(None)))
    job = result.scalar_one_or_none()
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    return job


@job_router.post("", response_model=EmpJobOut, status_code=201)
async def create_job(request: Request, body: EmpJobCreate, db: AsyncSession = Depends(get_db),
                     current_user: User = Depends(require_permission("add_empjob"))):
    job = EmpJob(**body.model_dump())
    db.add(job)
    await db.flush()
    await create_log(db, "create", "empjob", user_id=current_user.id, record_id=job.job_id,
                     new_data=model_to_dict(job), ip_address=request.client.host if request.client else None)
    await db.commit()
    await db.refresh(job)
    return job


@job_router.put("/{job_id}", response_model=EmpJobOut)
async def update_job(job_id: int, request: Request, body: EmpJobUpdate,
                     db: AsyncSession = Depends(get_db),
                     current_user: User = Depends(require_permission("change_empjob"))):
    result = await db.execute(select(EmpJob).where(EmpJob.job_id == job_id, EmpJob.deleted_at.is_(None)))
    job = result.scalar_one_or_none()
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")

    old = model_to_dict(job)
    for k, v in body.model_dump(exclude_unset=True).items():
        setattr(job, k, v)
    await create_log(db, "update", "empjob", user_id=current_user.id, record_id=job_id,
                     old_data=old, new_data=model_to_dict(job),
                     ip_address=request.client.host if request.client else None)
    await db.commit()
    await db.refresh(job)
    return job


@job_router.delete("/{job_id}")
async def delete_job(job_id: int, request: Request, db: AsyncSession = Depends(get_db),
                     current_user: User = Depends(require_permission("delete_empjob"))):
    result = await db.execute(select(EmpJob).where(EmpJob.job_id == job_id, EmpJob.deleted_at.is_(None)))
    job = result.scalar_one_or_none()
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")

    old = model_to_dict(job)
    job.deleted_at = datetime.utcnow()
    await create_log(db, "delete", "empjob", user_id=current_user.id, record_id=job_id,
                     old_data=old, ip_address=request.client.host if request.client else None)
    await db.commit()
    return {"message": "Job deleted"}


@job_router.post("/bulk-delete", response_model=BulkDeleteResponse)
async def bulk_delete_jobs(request: Request, body: BulkDeleteRequest,
                           db: AsyncSession = Depends(get_db),
                           current_user: User = Depends(require_permission("delete_empjob"))):
    now = datetime.utcnow()
    deleted_ids = []
    for job_id in body.ids:
        result = await db.execute(select(EmpJob).where(EmpJob.job_id == job_id, EmpJob.deleted_at.is_(None)))
        j = result.scalar_one_or_none()
        if j:
            j.deleted_at = now
            deleted_ids.append(job_id)
    await create_log(db, "bulk_delete", "empjob", user_id=current_user.id,
                     new_data={"deleted_ids": deleted_ids})
    await db.commit()
    return BulkDeleteResponse(deleted_count=len(deleted_ids), ids=deleted_ids)


# ─── AwDeg ────────────────────────────────────

@deg_router.get("", response_model=PaginatedResponse)
async def list_degrees(
    page: int = Query(1, ge=1),
    page_size: int = Query(25, ge=1, le=100),
    search: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("view_awdeg")),
):
    query = select(AwDeg).where(AwDeg.deleted_at.is_(None))
    if search:
        query = query.where(AwDeg.deg_name.ilike(f"%{search}%"))

    total = (await db.execute(select(func.count()).select_from(query.subquery()))).scalar()
    result = await db.execute(query.offset((page - 1) * page_size).limit(page_size))
    degs = result.scalars().all()

    return PaginatedResponse(
        items=[AwDegOut.model_validate(d) for d in degs],
        total=total, page=page, page_size=page_size,
        pages=(total + page_size - 1) // page_size,
    )


@deg_router.get("/{deg_id}", response_model=AwDegOut)
async def get_degree(deg_id: int, db: AsyncSession = Depends(get_db),
                     current_user: User = Depends(require_permission("view_awdeg"))):
    result = await db.execute(select(AwDeg).where(AwDeg.deg_id == deg_id, AwDeg.deleted_at.is_(None)))
    deg = result.scalar_one_or_none()
    if not deg:
        raise HTTPException(status_code=404, detail="Degree not found")
    return deg


@deg_router.post("", response_model=AwDegOut, status_code=201)
async def create_degree(request: Request, body: AwDegCreate, db: AsyncSession = Depends(get_db),
                        current_user: User = Depends(require_permission("add_awdeg"))):
    deg = AwDeg(**body.model_dump())
    db.add(deg)
    await db.flush()
    await create_log(db, "create", "awdeg", user_id=current_user.id, record_id=deg.deg_id,
                     new_data=model_to_dict(deg), ip_address=request.client.host if request.client else None)
    await db.commit()
    await db.refresh(deg)
    return deg


@deg_router.put("/{deg_id}", response_model=AwDegOut)
async def update_degree(deg_id: int, request: Request, body: AwDegUpdate,
                        db: AsyncSession = Depends(get_db),
                        current_user: User = Depends(require_permission("change_awdeg"))):
    result = await db.execute(select(AwDeg).where(AwDeg.deg_id == deg_id, AwDeg.deleted_at.is_(None)))
    deg = result.scalar_one_or_none()
    if not deg:
        raise HTTPException(status_code=404, detail="Degree not found")

    old = model_to_dict(deg)
    for k, v in body.model_dump(exclude_unset=True).items():
        setattr(deg, k, v)
    await create_log(db, "update", "awdeg", user_id=current_user.id, record_id=deg_id,
                     old_data=old, new_data=model_to_dict(deg),
                     ip_address=request.client.host if request.client else None)
    await db.commit()
    await db.refresh(deg)
    return deg


@deg_router.delete("/{deg_id}")
async def delete_degree(deg_id: int, request: Request, db: AsyncSession = Depends(get_db),
                        current_user: User = Depends(require_permission("delete_awdeg"))):
    result = await db.execute(select(AwDeg).where(AwDeg.deg_id == deg_id, AwDeg.deleted_at.is_(None)))
    deg = result.scalar_one_or_none()
    if not deg:
        raise HTTPException(status_code=404, detail="Degree not found")

    old = model_to_dict(deg)
    deg.deleted_at = datetime.utcnow()
    await create_log(db, "delete", "awdeg", user_id=current_user.id, record_id=deg_id,
                     old_data=old, ip_address=request.client.host if request.client else None)
    await db.commit()
    return {"message": "Degree deleted"}


@deg_router.post("/bulk-delete", response_model=BulkDeleteResponse)
async def bulk_delete_degrees(request: Request, body: BulkDeleteRequest,
                              db: AsyncSession = Depends(get_db),
                              current_user: User = Depends(require_permission("delete_awdeg"))):
    now = datetime.utcnow()
    deleted_ids = []
    for deg_id in body.ids:
        result = await db.execute(select(AwDeg).where(AwDeg.deg_id == deg_id, AwDeg.deleted_at.is_(None)))
        d = result.scalar_one_or_none()
        if d:
            d.deleted_at = now
            deleted_ids.append(deg_id)
    await create_log(db, "bulk_delete", "awdeg", user_id=current_user.id,
                     new_data={"deleted_ids": deleted_ids})
    await db.commit()
    return BulkDeleteResponse(deleted_count=len(deleted_ids), ids=deleted_ids)

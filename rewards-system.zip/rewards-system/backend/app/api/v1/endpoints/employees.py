from fastapi import APIRouter, Depends, HTTPException, Query, Request
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, or_
from typing import Optional
from datetime import datetime, date

from app.db.session import get_db
from app.models.models import Employee, AweEmp, Awardes, AwDeg
from app.schemas.schemas import (
    EmployeeCreate, EmployeeUpdate, EmployeeOut, EmployeeWithRewards,
    AweEmpCreate, AweEmpOut, PaginatedResponse, BulkDeleteRequest, BulkDeleteResponse
)
from app.core.deps import get_current_active_user, require_permission
from app.services.logging_service import create_log, model_to_dict
from app.models.models import User

router = APIRouter()


@router.get("", response_model=PaginatedResponse)
async def list_employees(
    page: int = Query(1, ge=1),
    page_size: int = Query(25, ge=1, le=100),
    search: Optional[str] = None,
    area_id: Optional[int] = None,
    job_id: Optional[int] = None,
    deg_id: Optional[int] = None,
    sort_by: str = Query("emp_id"),
    sort_dir: str = Query("asc"),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("view_employee")),
):
    query = select(Employee).where(Employee.deleted_at.is_(None))

    if search:
        query = query.where(
            or_(
                Employee.emp_name.ilike(f"%{search}%"),
                Employee.file_number.ilike(f"%{search}%"),
            )
        )
    if area_id:
        query = query.where(Employee.area_id == area_id)
    if job_id:
        query = query.where(Employee.job_id == job_id)
    if deg_id:
        query = query.where(Employee.deg_id == deg_id)

    total = (await db.execute(select(func.count()).select_from(query.subquery()))).scalar()

    sort_col = getattr(Employee, sort_by, Employee.emp_id)
    if sort_dir == "desc":
        sort_col = sort_col.desc()
    query = query.order_by(sort_col).offset((page - 1) * page_size).limit(page_size)

    result = await db.execute(query)
    employees = result.scalars().all()

    return PaginatedResponse(
        items=[EmployeeOut.model_validate(e) for e in employees],
        total=total,
        page=page,
        page_size=page_size,
        pages=(total + page_size - 1) // page_size,
    )


@router.get("/{emp_id}", response_model=EmployeeWithRewards)
async def get_employee(
    emp_id: int,
    date_from: Optional[str] = None,
    date_to: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("view_employee")),
):
    result = await db.execute(
        select(Employee).where(Employee.emp_id == emp_id, Employee.deleted_at.is_(None))
    )
    emp = result.scalar_one_or_none()
    if not emp:
        raise HTTPException(status_code=404, detail="Employee not found")

    # Calculate total rewards
    rewards_q = select(func.sum(AweEmp.total_amount)).where(
        AweEmp.emp_id == emp_id,
        AweEmp.deleted_at.is_(None),
    )
    if date_from:
        rewards_q = rewards_q.where(AweEmp.award_date >= date_from)
    if date_to:
        rewards_q = rewards_q.where(AweEmp.award_date <= date_to)

    total_rewards = (await db.execute(rewards_q)).scalar() or 0

    emp_data = EmployeeWithRewards.model_validate(emp)
    emp_data.total_rewards = total_rewards
    return emp_data


@router.post("", response_model=EmployeeOut, status_code=201)
async def create_employee(
    request: Request,
    body: EmployeeCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("add_employee")),
):
    emp = Employee(**body.model_dump())
    db.add(emp)
    await db.flush()
    await create_log(db, "create", "employee", user_id=current_user.id, record_id=emp.emp_id,
                     new_data=model_to_dict(emp), ip_address=request.client.host if request.client else None)
    await db.commit()
    await db.refresh(emp)
    return emp


@router.put("/{emp_id}", response_model=EmployeeOut)
async def update_employee(
    emp_id: int,
    request: Request,
    body: EmployeeUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("change_employee")),
):
    result = await db.execute(
        select(Employee).where(Employee.emp_id == emp_id, Employee.deleted_at.is_(None))
    )
    emp = result.scalar_one_or_none()
    if not emp:
        raise HTTPException(status_code=404, detail="Employee not found")

    old_data = model_to_dict(emp)
    for k, v in body.model_dump(exclude_unset=True).items():
        setattr(emp, k, v)

    await create_log(db, "update", "employee", user_id=current_user.id, record_id=emp_id,
                     old_data=old_data, new_data=model_to_dict(emp),
                     ip_address=request.client.host if request.client else None)
    await db.commit()
    await db.refresh(emp)
    return emp


@router.delete("/{emp_id}")
async def delete_employee(
    emp_id: int,
    request: Request,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("delete_employee")),
):
    result = await db.execute(
        select(Employee).where(Employee.emp_id == emp_id, Employee.deleted_at.is_(None))
    )
    emp = result.scalar_one_or_none()
    if not emp:
        raise HTTPException(status_code=404, detail="Employee not found")

    old_data = model_to_dict(emp)
    emp.deleted_at = datetime.utcnow()
    await create_log(db, "delete", "employee", user_id=current_user.id, record_id=emp_id,
                     old_data=old_data, ip_address=request.client.host if request.client else None)
    await db.commit()
    return {"message": "Employee deleted", "emp_id": emp_id}


@router.post("/bulk-delete", response_model=BulkDeleteResponse)
async def bulk_delete_employees(
    request: Request,
    body: BulkDeleteRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("delete_employee")),
):
    now = datetime.utcnow()
    deleted_ids = []
    for emp_id in body.ids:
        result = await db.execute(
            select(Employee).where(Employee.emp_id == emp_id, Employee.deleted_at.is_(None))
        )
        emp = result.scalar_one_or_none()
        if emp:
            emp.deleted_at = now
            deleted_ids.append(emp_id)

    await create_log(db, "bulk_delete", "employee", user_id=current_user.id,
                     new_data={"deleted_ids": deleted_ids},
                     ip_address=request.client.host if request.client else None)
    await db.commit()
    return BulkDeleteResponse(deleted_count=len(deleted_ids), ids=deleted_ids)


@router.get("/{emp_id}/degree-defaults")
async def get_employee_degree_defaults(
    emp_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("view_employee")),
):
    """Return default reward values from employee's degree."""
    result = await db.execute(
        select(Employee).where(Employee.emp_id == emp_id, Employee.deleted_at.is_(None))
    )
    emp = result.scalar_one_or_none()
    if not emp:
        raise HTTPException(status_code=404, detail="Employee not found")

    if not emp.deg_id:
        return {"def_mony": 0, "tax_percent": 0, "total": 0}

    deg_result = await db.execute(
        select(AwDeg).where(AwDeg.deg_id == emp.deg_id, AwDeg.deleted_at.is_(None))
    )
    deg = deg_result.scalar_one_or_none()
    if not deg:
        return {"def_mony": 0, "tax_percent": 0, "total": 0}

    def_mony = float(deg.def_mony or 0)
    tax_pct = float(deg.tax_percent or 0)
    total = def_mony + (def_mony * tax_pct / 100)

    return {
        "deg_id": deg.deg_id,
        "deg_name": deg.deg_name,
        "def_mony": def_mony,
        "tax_percent": tax_pct,
        "total": round(total, 2),
    }


@router.post("/{emp_id}/rewards", response_model=AweEmpOut, status_code=201)
async def add_reward_to_employee(
    emp_id: int,
    request: Request,
    body: AweEmpCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("add_awemp")),
):
    """Add a reward record to an employee."""
    body.emp_id = emp_id
    awemp = AweEmp(**body.model_dump())
    db.add(awemp)
    await db.flush()

    await create_log(db, "create", "awemp", user_id=current_user.id, record_id=awemp.awemp_id,
                     new_data=model_to_dict(awemp), ip_address=request.client.host if request.client else None)

    # Notify user
    from app.models.models import Notification
    notif = Notification(
        user_id=current_user.id,
        title="مكافأة جديدة",
        message=f"تم إضافة مكافأة جديدة للموظف رقم {emp_id}",
    )
    db.add(notif)

    await db.commit()
    await db.refresh(awemp)
    return awemp

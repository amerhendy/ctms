from fastapi import APIRouter, Depends, Query, HTTPException, UploadFile, File
from fastapi.responses import StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from typing import Optional
import io
import csv
import openpyxl
from docxtpl import DocxTemplate
from datetime import datetime

from app.db.session import get_db
from app.models.models import (
    Area, Employee, EmpJob, AwDeg, Awardes, AweEmp,
    ExportTemplate, Log
)
from app.schemas.schemas import ExportTemplateOut
from app.core.deps import get_current_active_user, require_permission
from app.services.logging_service import create_log
from app.models.models import User

router = APIRouter()


async def get_employees_data(db: AsyncSession, area_id=None, job_id=None, deg_id=None):
    query = select(Employee).where(Employee.deleted_at.is_(None))
    if area_id:
        query = query.where(Employee.area_id == area_id)
    if job_id:
        query = query.where(Employee.job_id == job_id)
    if deg_id:
        query = query.where(Employee.deg_id == deg_id)
    result = await db.execute(query)
    return result.scalars().all()


@router.get("/employees/csv")
async def export_employees_csv(
    area_id: Optional[int] = None,
    job_id: Optional[int] = None,
    deg_id: Optional[int] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("view_employee")),
):
    employees = await get_employees_data(db, area_id, job_id, deg_id)

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["ID", "رقم الملف", "الاسم", "المنطقة", "الوظيفة", "درجة المكافأة"])

    for emp in employees:
        writer.writerow([
            emp.emp_id,
            emp.file_number or "",
            emp.emp_name or "",
            emp.area.area_name if emp.area else "",
            emp.job.job_name if emp.job else "",
            emp.degree.deg_name if emp.degree else "",
        ])

    await create_log(db, "export", "employee", user_id=current_user.id,
                     new_data={"format": "csv", "filters": {"area_id": area_id, "job_id": job_id}})
    await db.commit()

    output.seek(0)
    return StreamingResponse(
        io.BytesIO(output.getvalue().encode("utf-8-sig")),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=employees.csv"},
    )


@router.get("/employees/excel")
async def export_employees_excel(
    area_id: Optional[int] = None,
    job_id: Optional[int] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("view_employee")),
):
    employees = await get_employees_data(db, area_id, job_id)

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "الموظفون"

    headers = ["ID", "رقم الملف", "الاسم", "المنطقة", "الوظيفة", "الدرجة"]
    ws.append(headers)

    for emp in employees:
        ws.append([
            emp.emp_id,
            emp.file_number or "",
            emp.emp_name or "",
            emp.area.area_name if emp.area else "",
            emp.job.job_name if emp.job else "",
            emp.degree.deg_name if emp.degree else "",
        ])

    output = io.BytesIO()
    wb.save(output)
    output.seek(0)

    await create_log(db, "export", "employee", user_id=current_user.id,
                     new_data={"format": "excel"})
    await db.commit()

    return StreamingResponse(
        output,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": "attachment; filename=employees.xlsx"},
    )


@router.get("/awards/{award_id}/word")
async def export_award_word(
    award_id: int,
    template_id: Optional[int] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("view_awardes")),
):
    """Export an award decision with all employee data as a Word document."""
    award_result = await db.execute(
        select(Awardes).where(Awardes.award_id == award_id, Awardes.deleted_at.is_(None))
    )
    award = award_result.scalar_one_or_none()
    if not award:
        raise HTTPException(status_code=404, detail="Award not found")

    awemp_result = await db.execute(
        select(AweEmp).where(AweEmp.award_id == award_id, AweEmp.deleted_at.is_(None))
    )
    records = awemp_result.scalars().all()

    # Find template
    template_path = None
    if template_id:
        tmpl_result = await db.execute(
            select(ExportTemplate).where(ExportTemplate.id == template_id)
        )
        tmpl = tmpl_result.scalar_one_or_none()
        if tmpl:
            template_path = tmpl.template_path
    else:
        tmpl_result = await db.execute(
            select(ExportTemplate).where(
                ExportTemplate.table_name == "awardes",
                ExportTemplate.is_default == True,
                ExportTemplate.deleted_at.is_(None),
            )
        )
        tmpl = tmpl_result.scalar_one_or_none()
        if tmpl:
            template_path = tmpl.template_path

    employees_data = []
    total_sum = 0
    for rec in records:
        emp = rec.employee
        employees_data.append({
            "emp_name": emp.emp_name if emp else "",
            "file_number": emp.file_number if emp else "",
            "area": emp.area.area_name if emp and emp.area else "",
            "job": emp.job.job_name if emp and emp.job else "",
            "aw_mony": float(rec.aw_mony or 0),
            "tax_percent": float(rec.tax_percent_applied or 0),
            "total_amount": float(rec.total_amount or 0),
            "award_date": str(rec.award_date) if rec.award_date else "",
        })
        total_sum += float(rec.total_amount or 0)

    context = {
        "award_title": award.award_title or "",
        "award_reson": award.award_reson or "",
        "award_date": str(award.award_date) if award.award_date else "",
        "employees": employees_data,
        "total_sum": total_sum,
        "export_date": datetime.utcnow().strftime("%Y-%m-%d"),
    }

    if template_path:
        import os
        if os.path.exists(template_path):
            doc = DocxTemplate(template_path)
            doc.render(context)
            output = io.BytesIO()
            doc.save(output)
            output.seek(0)
        else:
            output = _generate_default_award_doc(context)
    else:
        output = _generate_default_award_doc(context)

    await create_log(db, "export", "awardes", user_id=current_user.id,
                     record_id=award_id, new_data={"format": "word"})
    await db.commit()

    return StreamingResponse(
        output,
        media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        headers={"Content-Disposition": f"attachment; filename=award_{award_id}.docx"},
    )


def _generate_default_award_doc(context: dict) -> io.BytesIO:
    """Generate a simple Word doc without a template."""
    from docx import Document
    from docx.shared import Pt, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH

    doc = Document()

    # Title
    title = doc.add_heading(f"قرار مكافأة: {context['award_title']}", 0)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER

    doc.add_paragraph(f"السبب: {context['award_reson']}")
    doc.add_paragraph(f"تاريخ القرار: {context['award_date']}")
    doc.add_paragraph()

    # Table of employees
    table = doc.add_table(rows=1, cols=7)
    table.style = "Table Grid"
    headers = ["الاسم", "رقم الملف", "المنطقة", "الوظيفة", "المبلغ", "الضريبة%", "الإجمالي"]
    hdr_cells = table.rows[0].cells
    for i, h in enumerate(headers):
        hdr_cells[i].text = h

    for emp in context["employees"]:
        row = table.add_row().cells
        row[0].text = emp["emp_name"]
        row[1].text = emp["file_number"]
        row[2].text = emp["area"]
        row[3].text = emp["job"]
        row[4].text = str(emp["aw_mony"])
        row[5].text = str(emp["tax_percent"])
        row[6].text = str(emp["total_amount"])

    doc.add_paragraph()
    doc.add_paragraph(f"الإجمالي الكلي: {context['total_sum']:.2f}")

    output = io.BytesIO()
    doc.save(output)
    output.seek(0)
    return output


# ─── Template Management ──────────────────────

@router.get("/templates", response_model=list)
async def list_templates(
    table_name: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("manage_export_templates")),
):
    query = select(ExportTemplate).where(ExportTemplate.deleted_at.is_(None))
    if table_name:
        query = query.where(ExportTemplate.table_name == table_name)
    result = await db.execute(query)
    return [ExportTemplateOut.model_validate(t) for t in result.scalars().all()]


@router.post("/templates/upload")
async def upload_template(
    name: str,
    table_name: str,
    export_type: str = "table_only",
    is_default: bool = False,
    file: UploadFile = File(...),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("manage_export_templates")),
):
    import os
    import aiofiles

    if not file.filename.endswith(".docx"):
        raise HTTPException(status_code=400, detail="Only .docx files accepted")

    # Save file
    os.makedirs("templates", exist_ok=True)
    filename = f"templates/{table_name}_{datetime.utcnow().timestamp()}.docx"

    async with aiofiles.open(filename, "wb") as f:
        content = await file.read()
        await f.write(content)

    template = ExportTemplate(
        name=name,
        table_name=table_name,
        export_type=export_type,
        template_path=filename,
        is_default=is_default,
    )
    db.add(template)
    await db.commit()
    await db.refresh(template)

    return ExportTemplateOut.model_validate(template)

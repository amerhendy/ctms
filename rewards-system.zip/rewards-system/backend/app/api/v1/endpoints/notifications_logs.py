from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from typing import Optional

from app.db.session import get_db
from app.models.models import Notification, Log
from app.schemas.schemas import NotificationOut, LogOut, PaginatedResponse
from app.core.deps import get_current_active_user, require_permission
from app.models.models import User
from datetime import datetime

notif_router = APIRouter()
log_router = APIRouter()


# ─── Notifications ────────────────────────────

@notif_router.get("", response_model=PaginatedResponse)
async def list_notifications(
    page: int = Query(1, ge=1),
    page_size: int = Query(25, ge=1, le=100),
    unread_only: bool = False,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    query = select(Notification).where(
        Notification.user_id == current_user.id,
        Notification.deleted_at.is_(None),
    )
    if unread_only:
        query = query.where(Notification.is_read == False)

    total = (await db.execute(select(func.count()).select_from(query.subquery()))).scalar()
    result = await db.execute(
        query.order_by(Notification.created_at.desc()).offset((page - 1) * page_size).limit(page_size)
    )
    notifs = result.scalars().all()

    return PaginatedResponse(
        items=[NotificationOut.model_validate(n) for n in notifs],
        total=total, page=page, page_size=page_size,
        pages=(total + page_size - 1) // page_size,
    )


@notif_router.patch("/{notif_id}/read")
async def mark_read(
    notif_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    result = await db.execute(
        select(Notification).where(
            Notification.id == notif_id,
            Notification.user_id == current_user.id,
        )
    )
    notif = result.scalar_one_or_none()
    if notif:
        notif.is_read = True
        await db.commit()
    return {"message": "Marked as read"}


@notif_router.patch("/mark-all-read")
async def mark_all_read(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    from sqlalchemy import update
    await db.execute(
        select(Notification).where(
            Notification.user_id == current_user.id,
            Notification.is_read == False,
        )
    )
    result = await db.execute(
        select(Notification).where(
            Notification.user_id == current_user.id,
            Notification.is_read == False,
        )
    )
    for n in result.scalars().all():
        n.is_read = True
    await db.commit()
    return {"message": "All marked as read"}


@notif_router.delete("/{notif_id}")
async def delete_notification(
    notif_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    result = await db.execute(
        select(Notification).where(
            Notification.id == notif_id,
            Notification.user_id == current_user.id,
        )
    )
    notif = result.scalar_one_or_none()
    if notif:
        notif.deleted_at = datetime.utcnow()
        await db.commit()
    return {"message": "Deleted"}


@notif_router.get("/unread-count")
async def unread_count(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    count = (await db.execute(
        select(func.count(Notification.id)).where(
            Notification.user_id == current_user.id,
            Notification.is_read == False,
            Notification.deleted_at.is_(None),
        )
    )).scalar()
    return {"unread_count": count}


# ─── Logs ─────────────────────────────────────

@log_router.get("", response_model=PaginatedResponse)
async def list_logs(
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=100),
    user_id: Optional[int] = None,
    table_name: Optional[str] = None,
    action_type: Optional[str] = None,
    date_from: Optional[str] = None,
    date_to: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("view_logentry")),
):
    query = select(Log)

    if user_id:
        query = query.where(Log.user_id == user_id)
    if table_name:
        query = query.where(Log.table_name == table_name)
    if action_type:
        query = query.where(Log.action_type == action_type)
    if date_from:
        query = query.where(Log.created_at >= date_from)
    if date_to:
        query = query.where(Log.created_at <= date_to)

    total = (await db.execute(select(func.count()).select_from(query.subquery()))).scalar()
    result = await db.execute(
        query.order_by(Log.created_at.desc()).offset((page - 1) * page_size).limit(page_size)
    )
    logs = result.scalars().all()

    return PaginatedResponse(
        items=[LogOut.model_validate(l) for l in logs],
        total=total, page=page, page_size=page_size,
        pages=(total + page_size - 1) // page_size,
    )

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from typing import Optional, List
from datetime import datetime

from app.db.session import get_db
from app.models.models import User, Group, Permission, UserGroup, GroupPermission
from app.schemas.schemas import (
    UserCreate, UserUpdate, UserOut,
    GroupCreate, GroupUpdate, GroupOut,
    PermissionOut, PaginatedResponse, BulkDeleteRequest
)
from app.core.deps import get_current_active_user, require_permission
from app.core.security import get_password_hash
from app.services.logging_service import create_log, model_to_dict

router = APIRouter()


# ─── Users ────────────────────────────────────

@router.get("", response_model=PaginatedResponse)
async def list_users(
    page: int = Query(1, ge=1),
    page_size: int = Query(25, ge=1, le=100),
    search: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("view_user")),
):
    query = select(User).where(User.deleted_at.is_(None))
    if search:
        from sqlalchemy import or_
        query = query.where(
            or_(
                User.full_name.ilike(f"%{search}%"),
                User.email.ilike(f"%{search}%"),
                User.employee_number.ilike(f"%{search}%"),
            )
        )
    total = (await db.execute(select(func.count()).select_from(query.subquery()))).scalar()
    result = await db.execute(query.offset((page - 1) * page_size).limit(page_size))
    users = result.scalars().all()

    return PaginatedResponse(
        items=[UserOut.model_validate(u) for u in users],
        total=total, page=page, page_size=page_size,
        pages=(total + page_size - 1) // page_size,
    )


@router.get("/{user_id}", response_model=UserOut)
async def get_user(user_id: int, db: AsyncSession = Depends(get_db),
                   current_user: User = Depends(require_permission("view_user"))):
    result = await db.execute(select(User).where(User.id == user_id, User.deleted_at.is_(None)))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user


@router.post("", response_model=UserOut, status_code=201)
async def create_user(request: Request, body: UserCreate, db: AsyncSession = Depends(get_db),
                      current_user: User = Depends(require_permission("add_user"))):
    # Check email uniqueness
    existing = await db.execute(select(User).where(User.email == body.email, User.deleted_at.is_(None)))
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="Email already registered")

    user_data = body.model_dump(exclude={"password"})
    if body.password:
        user_data["password_hash"] = get_password_hash(body.password)

    user = User(**user_data)
    db.add(user)
    await db.flush()
    await create_log(db, "create", "users", user_id=current_user.id, record_id=user.id,
                     new_data={"email": user.email, "full_name": user.full_name},
                     ip_address=request.client.host if request.client else None)
    await db.commit()
    await db.refresh(user)
    return user


@router.put("/{user_id}", response_model=UserOut)
async def update_user(user_id: int, request: Request, body: UserUpdate,
                      db: AsyncSession = Depends(get_db),
                      current_user: User = Depends(require_permission("change_user"))):
    result = await db.execute(select(User).where(User.id == user_id, User.deleted_at.is_(None)))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    old_data = {"email": user.email, "full_name": user.full_name, "is_active": user.is_active}
    update_data = body.model_dump(exclude_unset=True, exclude={"password"})
    if body.password:
        update_data["password_hash"] = get_password_hash(body.password)

    for k, v in update_data.items():
        setattr(user, k, v)

    await create_log(db, "update", "users", user_id=current_user.id, record_id=user_id,
                     old_data=old_data, new_data=update_data,
                     ip_address=request.client.host if request.client else None)
    await db.commit()
    await db.refresh(user)
    return user


@router.delete("/{user_id}")
async def delete_user(user_id: int, request: Request, db: AsyncSession = Depends(get_db),
                      current_user: User = Depends(require_permission("delete_user"))):
    if user_id == current_user.id:
        raise HTTPException(status_code=400, detail="Cannot delete yourself")

    result = await db.execute(select(User).where(User.id == user_id, User.deleted_at.is_(None)))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    user.deleted_at = datetime.utcnow()
    await create_log(db, "delete", "users", user_id=current_user.id, record_id=user_id,
                     old_data={"email": user.email},
                     ip_address=request.client.host if request.client else None)
    await db.commit()
    return {"message": "User deleted"}


@router.post("/{user_id}/groups/{group_id}")
async def assign_group_to_user(user_id: int, group_id: int, db: AsyncSession = Depends(get_db),
                                current_user: User = Depends(require_permission("change_user"))):
    user_group = UserGroup(user_id=user_id, group_id=group_id)
    db.add(user_group)
    try:
        await db.commit()
    except Exception:
        await db.rollback()
        raise HTTPException(status_code=400, detail="Already assigned or invalid IDs")
    return {"message": "Group assigned"}


@router.delete("/{user_id}/groups/{group_id}")
async def remove_group_from_user(user_id: int, group_id: int, db: AsyncSession = Depends(get_db),
                                  current_user: User = Depends(require_permission("change_user"))):
    result = await db.execute(
        select(UserGroup).where(UserGroup.user_id == user_id, UserGroup.group_id == group_id)
    )
    ug = result.scalar_one_or_none()
    if not ug:
        raise HTTPException(status_code=404, detail="Not found")
    await db.delete(ug)
    await db.commit()
    return {"message": "Group removed"}


# ─── Groups ───────────────────────────────────

@router.get("/groups/all", response_model=List[GroupOut])
async def list_groups(db: AsyncSession = Depends(get_db),
                      current_user: User = Depends(require_permission("view_group"))):
    result = await db.execute(select(Group).where(Group.deleted_at.is_(None)))
    return [GroupOut.model_validate(g) for g in result.scalars().all()]


@router.post("/groups", response_model=GroupOut, status_code=201)
async def create_group(body: GroupCreate, db: AsyncSession = Depends(get_db),
                       current_user: User = Depends(require_permission("add_group"))):
    group = Group(name=body.name)
    db.add(group)
    await db.flush()

    for perm_id in body.permission_ids:
        db.add(GroupPermission(group_id=group.id, permission_id=perm_id))

    await db.commit()
    await db.refresh(group)
    return group


@router.put("/groups/{group_id}", response_model=GroupOut)
async def update_group(group_id: int, body: GroupUpdate, db: AsyncSession = Depends(get_db),
                       current_user: User = Depends(require_permission("change_group"))):
    result = await db.execute(select(Group).where(Group.id == group_id, Group.deleted_at.is_(None)))
    group = result.scalar_one_or_none()
    if not group:
        raise HTTPException(status_code=404, detail="Group not found")

    if body.name:
        group.name = body.name

    if body.permission_ids is not None:
        # Remove old permissions
        await db.execute(
            select(GroupPermission).where(GroupPermission.group_id == group_id)
        )
        from sqlalchemy import delete
        await db.execute(delete(GroupPermission).where(GroupPermission.group_id == group_id))

        # Add new ones
        for perm_id in body.permission_ids:
            db.add(GroupPermission(group_id=group_id, permission_id=perm_id))

    await db.commit()
    await db.refresh(group)
    return group


# ─── Permissions ──────────────────────────────

@router.get("/permissions/all", response_model=List[PermissionOut])
async def list_permissions(db: AsyncSession = Depends(get_db),
                           current_user: User = Depends(require_permission("view_permission"))):
    result = await db.execute(select(Permission).where(Permission.deleted_at.is_(None)))
    return [PermissionOut.model_validate(p) for p in result.scalars().all()]

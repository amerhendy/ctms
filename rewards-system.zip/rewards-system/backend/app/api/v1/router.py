from fastapi import APIRouter

from app.api.v1.endpoints.auth import router as auth_router
from app.api.v1.endpoints.areas import router as areas_router
from app.api.v1.endpoints.employees import router as employees_router
from app.api.v1.endpoints.empjob_awdeg import job_router, deg_router
from app.api.v1.endpoints.awards import router as awards_router
from app.api.v1.endpoints.users import router as users_router
from app.api.v1.endpoints.exports import router as exports_router
from app.api.v1.endpoints.notifications_logs import notif_router, log_router

api_router = APIRouter()

api_router.include_router(auth_router, prefix="/auth", tags=["Authentication"])
api_router.include_router(areas_router, prefix="/areas", tags=["Areas"])
api_router.include_router(employees_router, prefix="/employees", tags=["Employees"])
api_router.include_router(job_router, prefix="/jobs", tags=["Jobs"])
api_router.include_router(deg_router, prefix="/degrees", tags=["Degrees"])
api_router.include_router(awards_router, prefix="/awards", tags=["Awards"])
api_router.include_router(users_router, prefix="/users", tags=["Users"])
api_router.include_router(exports_router, prefix="/export", tags=["Export"])
api_router.include_router(notif_router, prefix="/notifications", tags=["Notifications"])
api_router.include_router(log_router, prefix="/logs", tags=["Logs"])

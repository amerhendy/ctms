from fastapi import Depends, HTTPException, status, Request
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.db.session import get_db
from app.models.models import User, Permission, Group
from app.core.security import oauth2_scheme, decode_token


async def get_current_user(
    token: str = Depends(oauth2_scheme),
    db: AsyncSession = Depends(get_db)
) -> User:
    payload = decode_token(token)
    user_id: int = payload.get("sub")
    if user_id is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token")

    result = await db.execute(
        select(User).where(User.id == int(user_id), User.deleted_at.is_(None), User.is_active == True)
    )
    user = result.scalar_one_or_none()
    if user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="User not found or inactive")
    return user


async def get_current_active_user(current_user: User = Depends(get_current_user)) -> User:
    if not current_user.is_active:
        raise HTTPException(status_code=400, detail="Inactive user")
    return current_user


async def get_user_permissions(user: User, db: AsyncSession) -> set:
    """Get all permission codenames for a user"""
    if user.global_admin:
        return {"*"}  # All permissions

    perms = set()
    for group in user.groups:
        for perm in group.permissions:
            perms.add(perm.codename)
    return perms


def require_permission(codename: str):
    """Dependency factory to require a specific permission"""
    async def _check(
        current_user: User = Depends(get_current_active_user),
        db: AsyncSession = Depends(get_db)
    ):
        if current_user.global_admin:
            return current_user
        perms = await get_user_permissions(current_user, db)
        if codename not in perms and "*" not in perms:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Permission '{codename}' required"
            )
        return current_user
    return _check


def require_global_admin():
    async def _check(current_user: User = Depends(get_current_active_user)):
        if not current_user.global_admin:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Global admin required")
        return current_user
    return _check

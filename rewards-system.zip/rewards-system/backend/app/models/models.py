from sqlalchemy import (
    Column, Integer, String, Text, Numeric, Boolean, DateTime, Date,
    ForeignKey, Enum, JSON, UniqueConstraint, event
)
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from sqlalchemy.dialects.postgresql import INET, JSONB
from datetime import datetime
import enum

from app.db.session import Base


# ─────────────────────────────────────────────
# 1. Area – المناطق
# ─────────────────────────────────────────────
class Area(Base):
    __tablename__ = "area"

    area_id = Column(Integer, primary_key=True, index=True)
    area_name = Column(String(255), nullable=False)
    deleted_at = Column(DateTime, nullable=True)

    employees = relationship("Employee", back_populates="area", lazy="selectin")


# ─────────────────────────────────────────────
# 2. EmpJob – الوظائف
# ─────────────────────────────────────────────
class EmpJob(Base):
    __tablename__ = "empjob"

    job_id = Column(Integer, primary_key=True, index=True)
    job_name = Column(String(255), nullable=False)
    deleted_at = Column(DateTime, nullable=True)

    employees = relationship("Employee", back_populates="job", lazy="selectin")


# ─────────────────────────────────────────────
# 3. AwDeg – درجات المكافآت
# ─────────────────────────────────────────────
class AwDeg(Base):
    __tablename__ = "awdeg"

    deg_id = Column(Integer, primary_key=True, index=True)
    deg_name = Column(String(255), nullable=True)
    def_mony = Column(Numeric(10, 2), nullable=True)
    rate = Column(Numeric(10, 2), nullable=True)
    tax_percent = Column(Numeric(5, 2), default=0)
    deleted_at = Column(DateTime, nullable=True)

    employees = relationship("Employee", back_populates="degree", lazy="selectin")


# ─────────────────────────────────────────────
# 4. Awardes – قرارات المكافآت
# ─────────────────────────────────────────────
class Awardes(Base):
    __tablename__ = "awardes"

    award_id = Column(Integer, primary_key=True, index=True)
    award_title = Column(String(255), nullable=True)
    award_reson = Column(Text, nullable=True)
    award_date = Column(DateTime, nullable=True)
    deleted_at = Column(DateTime, nullable=True)

    awemp_records = relationship("AweEmp", back_populates="award", cascade="all, delete-orphan", lazy="selectin")


# ─────────────────────────────────────────────
# 5. Employee – الموظفون
# ─────────────────────────────────────────────
class Employee(Base):
    __tablename__ = "employee"

    emp_id = Column(Integer, primary_key=True, index=True)
    file_number = Column(String(6), unique=True, nullable=True)
    emp_name = Column(String(255), nullable=True)
    area_id = Column(Integer, ForeignKey("area.area_id", ondelete="SET NULL"), nullable=True)
    job_id = Column(Integer, ForeignKey("empjob.job_id", ondelete="SET NULL"), nullable=True)
    deg_id = Column(Integer, ForeignKey("awdeg.deg_id", ondelete="SET NULL"), nullable=True)
    deleted_at = Column(DateTime, nullable=True)

    area = relationship("Area", back_populates="employees", lazy="selectin")
    job = relationship("EmpJob", back_populates="employees", lazy="selectin")
    degree = relationship("AwDeg", back_populates="employees", lazy="selectin")
    awemp_records = relationship("AweEmp", back_populates="employee", cascade="all, delete-orphan", lazy="selectin")


# ─────────────────────────────────────────────
# 6. AweEmp – ربط المكافآت بالموظفين
# ─────────────────────────────────────────────
class AweEmp(Base):
    __tablename__ = "awemp"

    awemp_id = Column(Integer, primary_key=True, index=True)
    award_id = Column(Integer, ForeignKey("awardes.award_id", ondelete="CASCADE"), nullable=False)
    emp_id = Column(Integer, ForeignKey("employee.emp_id", ondelete="CASCADE"), nullable=False)
    aw_mony = Column(Numeric(10, 2), nullable=True)
    award_date = Column(Date, nullable=True)
    tax_percent_applied = Column(Numeric(5, 2), nullable=True)
    total_amount = Column(Numeric(10, 2), nullable=True)
    deleted_at = Column(DateTime, nullable=True)

    award = relationship("Awardes", back_populates="awemp_records", lazy="selectin")
    employee = relationship("Employee", back_populates="awemp_records", lazy="selectin")


# ─────────────────────────────────────────────
# 7. Users – مستخدمو النظام
# ─────────────────────────────────────────────
class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    full_name = Column(String(255), nullable=False)
    employee_number = Column(String(50), unique=True, nullable=True)
    email = Column(String(255), unique=True, nullable=False)
    password_hash = Column(String(255), nullable=True)
    is_active = Column(Boolean, default=True)
    global_admin = Column(Boolean, default=False)
    avatar_url = Column(Text, nullable=True)
    google_id = Column(String(255), unique=True, nullable=True)
    last_login = Column(DateTime, nullable=True)
    date_joined = Column(DateTime, default=func.now())
    deleted_at = Column(DateTime, nullable=True)

    groups = relationship("Group", secondary="user_group", back_populates="users", lazy="selectin")
    notifications = relationship("Notification", back_populates="user", lazy="selectin")
    logs = relationship("Log", back_populates="user", lazy="noload")


# ─────────────────────────────────────────────
# 8. Log – سجل التغييرات (immutable)
# ─────────────────────────────────────────────
class Log(Base):
    __tablename__ = "log"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    action_type = Column(String(50), nullable=False)
    table_name = Column(String(100), nullable=False)
    record_id = Column(Integer, nullable=True)
    old_data = Column(JSONB, nullable=True)
    new_data = Column(JSONB, nullable=True)
    ip_address = Column(String(45), nullable=True)
    created_at = Column(DateTime, default=func.now(), nullable=False)

    user = relationship("User", back_populates="logs", lazy="noload")


# ─────────────────────────────────────────────
# 9. Notification – الإشعارات
# ─────────────────────────────────────────────
class Notification(Base):
    __tablename__ = "notification"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    title = Column(String(255), nullable=False)
    message = Column(Text, nullable=False)
    is_read = Column(Boolean, default=False)
    created_at = Column(DateTime, default=func.now())
    deleted_at = Column(DateTime, nullable=True)

    user = relationship("User", back_populates="notifications", lazy="noload")


# ─────────────────────────────────────────────
# 10. Groups – مجموعات الصلاحيات
# ─────────────────────────────────────────────
class Group(Base):
    __tablename__ = "groups"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), unique=True, nullable=False)
    deleted_at = Column(DateTime, nullable=True)

    users = relationship("User", secondary="user_group", back_populates="groups", lazy="selectin")
    permissions = relationship("Permission", secondary="group_permission", back_populates="groups", lazy="selectin")


# ─────────────────────────────────────────────
# 11. Permission – الصلاحيات
# ─────────────────────────────────────────────
class Permission(Base):
    __tablename__ = "permissions"

    id = Column(Integer, primary_key=True, index=True)
    codename = Column(String(100), unique=True, nullable=False)
    name = Column(String(255), nullable=False)
    content_type = Column(String(100), nullable=False)
    deleted_at = Column(DateTime, nullable=True)

    groups = relationship("Group", secondary="group_permission", back_populates="permissions", lazy="selectin")


# ─────────────────────────────────────────────
# 12. UserGroup – ربط المستخدمين بالمجموعات
# ─────────────────────────────────────────────
class UserGroup(Base):
    __tablename__ = "user_group"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    group_id = Column(Integer, ForeignKey("groups.id", ondelete="CASCADE"), nullable=False)

    __table_args__ = (UniqueConstraint("user_id", "group_id"),)


# ─────────────────────────────────────────────
# 13. GroupPermission – ربط المجموعات بالصلاحيات
# ─────────────────────────────────────────────
class GroupPermission(Base):
    __tablename__ = "group_permission"

    id = Column(Integer, primary_key=True, index=True)
    group_id = Column(Integer, ForeignKey("groups.id", ondelete="CASCADE"), nullable=False)
    permission_id = Column(Integer, ForeignKey("permissions.id", ondelete="CASCADE"), nullable=False)

    __table_args__ = (UniqueConstraint("group_id", "permission_id"),)


# ─────────────────────────────────────────────
# 14. ExportTemplate – قوالب التصدير
# ─────────────────────────────────────────────
class ExportType(str, enum.Enum):
    table_only = "table_only"
    related = "related"


class ExportTemplate(Base):
    __tablename__ = "export_template"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False)
    table_name = Column(String(100), nullable=False)
    export_type = Column(Enum(ExportType), nullable=False, default=ExportType.table_only)
    template_path = Column(String(500), nullable=True)
    is_default = Column(Boolean, default=False)
    created_at = Column(DateTime, default=func.now())
    deleted_at = Column(DateTime, nullable=True)

from pydantic import BaseModel, EmailStr, field_validator
from typing import Optional, List, Any
from datetime import datetime, date
from decimal import Decimal


# ─────────────────────────────────────────────
# Area Schemas
# ─────────────────────────────────────────────
class AreaBase(BaseModel):
    area_name: str

class AreaCreate(AreaBase):
    pass

class AreaUpdate(BaseModel):
    area_name: Optional[str] = None

class AreaOut(AreaBase):
    area_id: int
    deleted_at: Optional[datetime] = None

    class Config:
        from_attributes = True

class AreaWithEmployees(AreaOut):
    employees: List["EmployeeOut"] = []


# ─────────────────────────────────────────────
# EmpJob Schemas
# ─────────────────────────────────────────────
class EmpJobBase(BaseModel):
    job_name: str

class EmpJobCreate(EmpJobBase):
    pass

class EmpJobUpdate(BaseModel):
    job_name: Optional[str] = None

class EmpJobOut(EmpJobBase):
    job_id: int
    deleted_at: Optional[datetime] = None

    class Config:
        from_attributes = True


# ─────────────────────────────────────────────
# AwDeg Schemas
# ─────────────────────────────────────────────
class AwDegBase(BaseModel):
    deg_name: Optional[str] = None
    def_mony: Optional[Decimal] = None
    rate: Optional[Decimal] = None
    tax_percent: Optional[Decimal] = Decimal("0")

class AwDegCreate(AwDegBase):
    pass

class AwDegUpdate(AwDegBase):
    pass

class AwDegOut(AwDegBase):
    deg_id: int
    deleted_at: Optional[datetime] = None

    class Config:
        from_attributes = True


# ─────────────────────────────────────────────
# Awardes Schemas
# ─────────────────────────────────────────────
class AwardesBase(BaseModel):
    award_title: Optional[str] = None
    award_reson: Optional[str] = None
    award_date: Optional[datetime] = None

class AwardesCreate(AwardesBase):
    pass

class AwardesUpdate(AwardesBase):
    pass

class AwardesOut(AwardesBase):
    award_id: int
    deleted_at: Optional[datetime] = None

    class Config:
        from_attributes = True


# ─────────────────────────────────────────────
# AweEmp Schemas
# ─────────────────────────────────────────────
class AweEmpBase(BaseModel):
    award_id: int
    emp_id: int
    aw_mony: Optional[Decimal] = None
    award_date: Optional[date] = None
    tax_percent_applied: Optional[Decimal] = None
    total_amount: Optional[Decimal] = None

class AweEmpCreate(AweEmpBase):
    pass

class AweEmpUpdate(BaseModel):
    aw_mony: Optional[Decimal] = None
    award_date: Optional[date] = None
    tax_percent_applied: Optional[Decimal] = None
    total_amount: Optional[Decimal] = None

class AweEmpOut(AweEmpBase):
    awemp_id: int
    deleted_at: Optional[datetime] = None

    class Config:
        from_attributes = True

class AweEmpWithDetails(AweEmpOut):
    award: Optional[AwardesOut] = None
    employee: Optional["EmployeeOut"] = None


# ─────────────────────────────────────────────
# Employee Schemas
# ─────────────────────────────────────────────
class EmployeeBase(BaseModel):
    file_number: Optional[str] = None
    emp_name: Optional[str] = None
    area_id: Optional[int] = None
    job_id: Optional[int] = None
    deg_id: Optional[int] = None

class EmployeeCreate(EmployeeBase):
    pass

class EmployeeUpdate(EmployeeBase):
    pass

class EmployeeOut(EmployeeBase):
    emp_id: int
    deleted_at: Optional[datetime] = None
    area: Optional[AreaOut] = None
    job: Optional[EmpJobOut] = None
    degree: Optional[AwDegOut] = None

    class Config:
        from_attributes = True

class EmployeeWithRewards(EmployeeOut):
    awemp_records: List[AweEmpOut] = []
    total_rewards: Optional[Decimal] = None


# ─────────────────────────────────────────────
# User Schemas
# ─────────────────────────────────────────────
class UserBase(BaseModel):
    full_name: str
    email: EmailStr
    employee_number: Optional[str] = None
    is_active: bool = True
    global_admin: bool = False

class UserCreate(UserBase):
    password: Optional[str] = None

class UserUpdate(BaseModel):
    full_name: Optional[str] = None
    email: Optional[EmailStr] = None
    employee_number: Optional[str] = None
    is_active: Optional[bool] = None
    global_admin: Optional[bool] = None
    password: Optional[str] = None

class UserOut(UserBase):
    id: int
    avatar_url: Optional[str] = None
    last_login: Optional[datetime] = None
    date_joined: Optional[datetime] = None
    deleted_at: Optional[datetime] = None
    groups: List["GroupOut"] = []

    class Config:
        from_attributes = True


# ─────────────────────────────────────────────
# Auth Schemas
# ─────────────────────────────────────────────
class LoginRequest(BaseModel):
    username: str  # email or employee_number
    password: str

class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    user: UserOut

class RefreshRequest(BaseModel):
    refresh_token: str


# ─────────────────────────────────────────────
# Group & Permission Schemas
# ─────────────────────────────────────────────
class PermissionOut(BaseModel):
    id: int
    codename: str
    name: str
    content_type: str

    class Config:
        from_attributes = True

class GroupBase(BaseModel):
    name: str

class GroupCreate(GroupBase):
    permission_ids: List[int] = []

class GroupUpdate(BaseModel):
    name: Optional[str] = None
    permission_ids: Optional[List[int]] = None

class GroupOut(GroupBase):
    id: int
    deleted_at: Optional[datetime] = None
    permissions: List[PermissionOut] = []

    class Config:
        from_attributes = True


# ─────────────────────────────────────────────
# Log Schemas
# ─────────────────────────────────────────────
class LogOut(BaseModel):
    id: int
    user_id: Optional[int] = None
    action_type: str
    table_name: str
    record_id: Optional[int] = None
    old_data: Optional[Any] = None
    new_data: Optional[Any] = None
    ip_address: Optional[str] = None
    created_at: datetime

    class Config:
        from_attributes = True


# ─────────────────────────────────────────────
# Notification Schemas
# ─────────────────────────────────────────────
class NotificationOut(BaseModel):
    id: int
    user_id: int
    title: str
    message: str
    is_read: bool
    created_at: datetime

    class Config:
        from_attributes = True


# ─────────────────────────────────────────────
# Export Template Schemas
# ─────────────────────────────────────────────
class ExportTemplateOut(BaseModel):
    id: int
    name: str
    table_name: str
    export_type: str
    is_default: bool
    created_at: datetime

    class Config:
        from_attributes = True


# ─────────────────────────────────────────────
# Pagination
# ─────────────────────────────────────────────
class PaginatedResponse(BaseModel):
    items: List[Any]
    total: int
    page: int
    page_size: int
    pages: int


# ─────────────────────────────────────────────
# Bulk operations
# ─────────────────────────────────────────────
class BulkDeleteRequest(BaseModel):
    ids: List[int]

class BulkDeleteResponse(BaseModel):
    deleted_count: int
    ids: List[int]


# Update forward refs
AreaWithEmployees.model_rebuild()
EmployeeWithRewards.model_rebuild()
AweEmpWithDetails.model_rebuild()
UserOut.model_rebuild()

"""
Import data from CSV files exported from the old Django system.

Usage:
    python -m app.scripts.import_data --data-dir /path/to/csv/files

Expected files:
    area.csv, empjob.csv, awdeg.csv, awardes.csv, employee.csv, awemp.csv
"""
import asyncio
import csv
import argparse
import os
from datetime import datetime
from decimal import Decimal

import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from app.db.session import AsyncSessionLocal
from app.models.models import Area, EmpJob, AwDeg, Awardes, Employee, AweEmp


def parse_decimal(val):
    if not val or val.strip() == "":
        return None
    try:
        return Decimal(val.strip())
    except Exception:
        return None


def parse_datetime(val):
    if not val or val.strip() == "":
        return None
    for fmt in ["%Y-%m-%d %H:%M:%S", "%Y-%m-%d", "%d/%m/%Y"]:
        try:
            return datetime.strptime(val.strip(), fmt)
        except ValueError:
            continue
    return None


def parse_date(val):
    if not val or val.strip() == "":
        return None
    for fmt in ["%Y-%m-%d", "%d/%m/%Y"]:
        try:
            return datetime.strptime(val.strip(), fmt).date()
        except ValueError:
            continue
    return None


async def import_data(data_dir: str):
    async with AsyncSessionLocal() as db:

        # ── area.csv ──────────────────────────────────────
        area_file = os.path.join(data_dir, "area.csv")
        area_id_map = {}  # old_id -> new_id
        if os.path.exists(area_file):
            print("📂 Importing areas...")
            with open(area_file, encoding="utf-8-sig") as f:
                reader = csv.DictReader(f)
                for row in reader:
                    old_id = row.get("area_id") or row.get("id")
                    name = row.get("area_name") or row.get("name", "")
                    area = Area(area_name=name.strip())
                    db.add(area)
                    await db.flush()
                    if old_id:
                        area_id_map[str(old_id).strip()] = area.area_id
            await db.commit()
            print(f"  ✅ Imported {len(area_id_map)} areas")

        # ── empjob.csv ────────────────────────────────────
        job_file = os.path.join(data_dir, "empjob.csv")
        job_id_map = {}
        if os.path.exists(job_file):
            print("📂 Importing jobs...")
            with open(job_file, encoding="utf-8-sig") as f:
                reader = csv.DictReader(f)
                for row in reader:
                    old_id = row.get("job_id") or row.get("id")
                    name = row.get("job_name") or row.get("name", "")
                    job = EmpJob(job_name=name.strip())
                    db.add(job)
                    await db.flush()
                    if old_id:
                        job_id_map[str(old_id).strip()] = job.job_id
            await db.commit()
            print(f"  ✅ Imported {len(job_id_map)} jobs")

        # ── awdeg.csv ─────────────────────────────────────
        deg_file = os.path.join(data_dir, "awdeg.csv")
        deg_id_map = {}
        if os.path.exists(deg_file):
            print("📂 Importing degrees...")
            with open(deg_file, encoding="utf-8-sig") as f:
                reader = csv.DictReader(f)
                for row in reader:
                    old_id = row.get("deg_id") or row.get("id")
                    deg = AwDeg(
                        deg_name=(row.get("deg_name") or "").strip(),
                        def_mony=parse_decimal(row.get("def_mony") or row.get("default_money")),
                        rate=parse_decimal(row.get("rate")),
                        tax_percent=parse_decimal(row.get("tax_percent") or row.get("tax")) or Decimal("0"),
                    )
                    db.add(deg)
                    await db.flush()
                    if old_id:
                        deg_id_map[str(old_id).strip()] = deg.deg_id
            await db.commit()
            print(f"  ✅ Imported {len(deg_id_map)} degrees")

        # ── awardes.csv ───────────────────────────────────
        award_file = os.path.join(data_dir, "awardes.csv")
        award_id_map = {}
        if os.path.exists(award_file):
            print("📂 Importing award decisions...")
            with open(award_file, encoding="utf-8-sig") as f:
                reader = csv.DictReader(f)
                for row in reader:
                    old_id = row.get("award_id") or row.get("id")
                    award = Awardes(
                        award_title=(row.get("award_title") or row.get("title") or "").strip(),
                        award_reson=(row.get("award_reson") or row.get("reason") or "").strip(),
                        award_date=parse_datetime(row.get("award_date") or row.get("date")),
                    )
                    db.add(award)
                    await db.flush()
                    if old_id:
                        award_id_map[str(old_id).strip()] = award.award_id
            await db.commit()
            print(f"  ✅ Imported {len(award_id_map)} award decisions")

        # ── employee.csv ──────────────────────────────────
        emp_file = os.path.join(data_dir, "employee.csv")
        emp_id_map = {}
        if os.path.exists(emp_file):
            print("📂 Importing employees...")
            with open(emp_file, encoding="utf-8-sig") as f:
                reader = csv.DictReader(f)
                for row in reader:
                    old_id = row.get("emp_id") or row.get("id")
                    old_area = str(row.get("area_id") or "").strip()
                    old_job = str(row.get("job_id") or "").strip()
                    old_deg = str(row.get("deg_id") or "").strip()

                    emp = Employee(
                        file_number=(row.get("file_number") or row.get("file_no") or "")[:6] or None,
                        emp_name=(row.get("emp_name") or row.get("name") or "").strip(),
                        area_id=area_id_map.get(old_area) if old_area else None,
                        job_id=job_id_map.get(old_job) if old_job else None,
                        deg_id=deg_id_map.get(old_deg) if old_deg else None,
                    )
                    db.add(emp)
                    await db.flush()
                    if old_id:
                        emp_id_map[str(old_id).strip()] = emp.emp_id
            await db.commit()
            print(f"  ✅ Imported {len(emp_id_map)} employees")

        # ── awemp.csv ─────────────────────────────────────
        awemp_file = os.path.join(data_dir, "awemp.csv")
        if os.path.exists(awemp_file):
            print("📂 Importing employee reward records...")
            count = 0
            with open(awemp_file, encoding="utf-8-sig") as f:
                reader = csv.DictReader(f)
                for row in reader:
                    old_award_id = str(row.get("award_id") or "").strip()
                    old_emp_id = str(row.get("emp_id") or "").strip()

                    new_award_id = award_id_map.get(old_award_id)
                    new_emp_id = emp_id_map.get(old_emp_id)

                    if not new_award_id or not new_emp_id:
                        print(f"  ⚠️  Skipping row: award={old_award_id}, emp={old_emp_id} not found in maps")
                        continue

                    aw_mony = parse_decimal(row.get("aw_mony") or row.get("amount"))
                    tax_pct = parse_decimal(row.get("tax_percent_applied") or row.get("tax_percent") or "0")
                    total_amount = parse_decimal(row.get("total_amount"))

                    if not total_amount and aw_mony and tax_pct is not None:
                        total_amount = aw_mony + (aw_mony * tax_pct / 100)

                    awemp = AweEmp(
                        award_id=new_award_id,
                        emp_id=new_emp_id,
                        aw_mony=aw_mony,
                        award_date=parse_date(row.get("award_date")),
                        tax_percent_applied=tax_pct,
                        total_amount=total_amount,
                    )
                    db.add(awemp)
                    count += 1

            await db.commit()
            print(f"  ✅ Imported {count} employee reward records")

        print("\n✅ Import complete!")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Import data from CSV files")
    parser.add_argument("--data-dir", required=True, help="Directory containing CSV files")
    args = parser.parse_args()
    asyncio.run(import_data(args.data_dir))

"""
Seed script: creates default permissions, groups, and admin user.
Run via: python -m app.scripts.seed_data
"""
import asyncio
import os
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from app.db.session import AsyncSessionLocal
from app.models.models import User, Group, Permission, UserGroup, GroupPermission
from app.core.security import get_password_hash
from app.core.config import settings

# All permissions
ALL_PERMISSIONS = [
    # area
    ("add_area", "Can add area", "awards"),
    ("change_area", "Can change area", "awards"),
    ("delete_area", "Can delete area", "awards"),
    ("view_area", "Can view area", "awards"),
    # empjob
    ("add_empjob", "Can add job", "awards"),
    ("change_empjob", "Can change job", "awards"),
    ("delete_empjob", "Can delete job", "awards"),
    ("view_empjob", "Can view job", "awards"),
    # awdeg
    ("add_awdeg", "Can add degree", "awards"),
    ("change_awdeg", "Can change degree", "awards"),
    ("delete_awdeg", "Can delete degree", "awards"),
    ("view_awdeg", "Can view degree", "awards"),
    # awardes
    ("add_awardes", "Can add award decision", "awards"),
    ("change_awardes", "Can change award decision", "awards"),
    ("delete_awardes", "Can delete award decision", "awards"),
    ("view_awardes", "Can view award decision", "awards"),
    # employee
    ("add_employee", "Can add employee", "awards"),
    ("change_employee", "Can change employee", "awards"),
    ("delete_employee", "Can delete employee", "awards"),
    ("view_employee", "Can view employee", "awards"),
    # awemp
    ("add_awemp", "Can add employee reward", "awards"),
    ("change_awemp", "Can change employee reward", "awards"),
    ("delete_awemp", "Can delete employee reward", "awards"),
    ("view_awemp", "Can view employee reward", "awards"),
    # users
    ("add_user", "Can add user", "auth"),
    ("change_user", "Can change user", "auth"),
    ("delete_user", "Can delete user", "auth"),
    ("view_user", "Can view user", "auth"),
    # groups
    ("add_group", "Can add group", "auth"),
    ("change_group", "Can change group", "auth"),
    ("delete_group", "Can delete group", "auth"),
    ("view_group", "Can view group", "auth"),
    # permissions
    ("add_permission", "Can add permission", "auth"),
    ("change_permission", "Can change permission", "auth"),
    ("delete_permission", "Can delete permission", "auth"),
    ("view_permission", "Can view permission", "auth"),
    # log
    ("add_logentry", "Can add log entry", "log"),
    ("view_logentry", "Can view log entry", "log"),
    # notification
    ("add_notification", "Can add notification", "notification"),
    ("change_notification", "Can change notification", "notification"),
    ("delete_notification", "Can delete notification", "notification"),
    ("view_notification", "Can view notification", "notification"),
    # export templates
    ("manage_export_templates", "Can manage export templates", "awards"),
]

# Default group configurations
DEFAULT_GROUPS = {
    "إدارة الموقع": ALL_PERMISSIONS,  # Site Admin
    "تعديل": [  # Editor
        p for p in ALL_PERMISSIONS
        if p[0].startswith(("add_", "change_", "view_"))
        and not p[0].endswith(("_user", "_group", "_permission"))
    ],
    "إدخال": [  # Data Entry
        p for p in ALL_PERMISSIONS
        if p[0].startswith(("add_", "view_"))
        and not p[0].endswith(("_user", "_group", "_permission"))
    ],
    "مشرف": [  # Viewer
        p for p in ALL_PERMISSIONS
        if p[0].startswith("view_")
    ],
}


async def seed():
    async with AsyncSessionLocal() as db:
        print("🌱 Seeding permissions...")
        perm_map = {}
        for codename, name, content_type in ALL_PERMISSIONS:
            result = await db.execute(select(Permission).where(Permission.codename == codename))
            perm = result.scalar_one_or_none()
            if not perm:
                perm = Permission(codename=codename, name=name, content_type=content_type)
                db.add(perm)
                await db.flush()
            perm_map[codename] = perm.id

        await db.commit()
        print(f"  ✅ {len(perm_map)} permissions ready")

        print("🌱 Seeding groups...")
        for group_name, group_perms in DEFAULT_GROUPS.items():
            result = await db.execute(select(Group).where(Group.name == group_name))
            group = result.scalar_one_or_none()
            if not group:
                group = Group(name=group_name)
                db.add(group)
                await db.flush()

                for codename, _, _ in group_perms:
                    if codename in perm_map:
                        db.add(GroupPermission(
                            group_id=group.id,
                            permission_id=perm_map[codename]
                        ))
                await db.commit()
                print(f"  ✅ Group '{group_name}' created")
            else:
                print(f"  ⏭️  Group '{group_name}' already exists")

        print("🌱 Creating admin user...")
        result = await db.execute(
            select(User).where(User.email == settings.FIRST_ADMIN_EMAIL)
        )
        admin = result.scalar_one_or_none()
        if not admin:
            admin = User(
                full_name=settings.FIRST_ADMIN_NAME,
                email=settings.FIRST_ADMIN_EMAIL,
                password_hash=get_password_hash(settings.FIRST_ADMIN_PASSWORD),
                global_admin=True,
                is_active=True,
            )
            db.add(admin)
            await db.commit()
            print(f"  ✅ Admin user created: {settings.FIRST_ADMIN_EMAIL}")
        else:
            print(f"  ⏭️  Admin user already exists")

        print("✅ Seeding complete!")


if __name__ == "__main__":
    asyncio.run(seed())

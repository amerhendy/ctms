from sqlalchemy.ext.asyncio import AsyncSession
from typing import Optional, Any, Dict
from datetime import datetime

from app.models.models import Log


async def create_log(
    db: AsyncSession,
    action_type: str,
    table_name: str,
    user_id: Optional[int] = None,
    record_id: Optional[int] = None,
    old_data: Optional[Dict] = None,
    new_data: Optional[Dict] = None,
    ip_address: Optional[str] = None,
):
    """Create an immutable audit log entry."""
    log_entry = Log(
        user_id=user_id,
        action_type=action_type,
        table_name=table_name,
        record_id=record_id,
        old_data=old_data,
        new_data=new_data,
        ip_address=ip_address,
    )
    db.add(log_entry)
    # Don't commit here — caller manages transaction
    return log_entry


def model_to_dict(obj) -> Dict:
    """Convert SQLAlchemy model to dict for logging."""
    result = {}
    for col in obj.__table__.columns:
        val = getattr(obj, col.name)
        if isinstance(val, datetime):
            val = val.isoformat()
        result[col.name] = val
    return result

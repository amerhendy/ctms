"""
Rewards Management System - Desktop App (Flet)
Runs on Windows, macOS, Linux.

Install: pip install flet httpx
Run:     python desktop/main.py
"""

import flet as ft
import httpx
import asyncio
import json
from datetime import datetime

API_BASE = "http://localhost:8000/api/v1"

# ─── Global state ──────────────────────────────────────────────────────────────
_token = None
_user = None


def get_headers():
    return {"Authorization": f"Bearer {_token}"} if _token else {}


async def api_get(path: str, params: dict = None):
    async with httpx.AsyncClient() as client:
        r = await client.get(f"{API_BASE}{path}", headers=get_headers(), params=params, timeout=15)
        r.raise_for_status()
        return r.json()


async def api_post(path: str, data: dict):
    async with httpx.AsyncClient() as client:
        r = await client.post(f"{API_BASE}{path}", headers=get_headers(), json=data, timeout=15)
        r.raise_for_status()
        return r.json()


async def api_put(path: str, data: dict):
    async with httpx.AsyncClient() as client:
        r = await client.put(f"{API_BASE}{path}", headers=get_headers(), json=data, timeout=15)
        r.raise_for_status()
        return r.json()


async def api_delete(path: str):
    async with httpx.AsyncClient() as client:
        r = await client.delete(f"{API_BASE}{path}", headers=get_headers(), timeout=15)
        r.raise_for_status()
        return r.json()


# ─── Views ─────────────────────────────────────────────────────────────────────

class LoginView:
    def __init__(self, page: ft.Page, on_login):
        self.page = page
        self.on_login = on_login
        self.username = ft.TextField(label="البريد الإلكتروني أو رقم الملف", width=320, text_align=ft.TextAlign.RIGHT)
        self.password = ft.TextField(label="كلمة المرور", password=True, can_reveal_password=True, width=320, text_align=ft.TextAlign.RIGHT)
        self.error = ft.Text("", color=ft.colors.RED_400, size=13)
        self.loading = ft.ProgressRing(width=20, height=20, visible=False)

    def build(self):
        return ft.Container(
            content=ft.Column(
                [
                    ft.Icon(ft.icons.EMOJI_EVENTS, size=56, color=ft.colors.BLUE_600),
                    ft.Text("نظام إدارة المكافآت", size=22, weight=ft.FontWeight.BOLD, text_align=ft.TextAlign.CENTER),
                    ft.Text("Rewards Management System", size=13, color=ft.colors.GREY_500, text_align=ft.TextAlign.CENTER),
                    ft.Divider(height=20, color=ft.colors.TRANSPARENT),
                    self.username,
                    self.password,
                    self.error,
                    ft.ElevatedButton(
                        "تسجيل الدخول",
                        width=320,
                        height=44,
                        on_click=self._do_login,
                        bgcolor=ft.colors.BLUE_600,
                        color=ft.colors.WHITE,
                        style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=10))
                    ),
                    self.loading,
                ],
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                spacing=14,
            ),
            alignment=ft.alignment.center,
            expand=True,
            padding=40,
        )

    async def _do_login(self, e):
        global _token, _user
        self.error.value = ""
        self.loading.visible = True
        self.page.update()
        try:
            data = await api_post("/auth/login", {
                "username": self.username.value,
                "password": self.password.value,
            })
            _token = data["access_token"]
            _user = data["user"]
            self.on_login()
        except httpx.HTTPStatusError as ex:
            msg = ex.response.json().get("detail", "خطأ في الدخول")
            self.error.value = msg
        except Exception as ex:
            self.error.value = f"تعذر الاتصال بالخادم: {ex}"
        finally:
            self.loading.visible = False
            self.page.update()


class EmployeesView:
    def __init__(self, page: ft.Page):
        self.page = page
        self.search_field = ft.TextField(
            hint_text="بحث بالاسم أو رقم الملف...",
            prefix_icon=ft.icons.SEARCH,
            on_change=self._on_search,
            width=280,
        )
        self.data_table = ft.DataTable(
            columns=[
                ft.DataColumn(ft.Text("#")),
                ft.DataColumn(ft.Text("رقم الملف")),
                ft.DataColumn(ft.Text("الاسم")),
                ft.DataColumn(ft.Text("المنطقة")),
                ft.DataColumn(ft.Text("الوظيفة")),
                ft.DataColumn(ft.Text("الدرجة")),
            ],
            rows=[],
            border=ft.border.all(1, ft.colors.GREY_200),
            border_radius=10,
            horizontal_lines=ft.BorderSide(1, ft.colors.GREY_100),
        )
        self.page_num = 1
        self.total = 0
        self.loading = ft.ProgressBar(visible=False)
        self.status = ft.Text("", size=12, color=ft.colors.GREY_500)

    def build(self):
        self._load_data()
        return ft.Column(
            [
                ft.Row(
                    [
                        ft.Icon(ft.icons.PEOPLE, color=ft.colors.BLUE_600),
                        ft.Text("الموظفون", size=18, weight=ft.FontWeight.BOLD),
                    ],
                    spacing=8,
                ),
                ft.Row(
                    [
                        self.search_field,
                        ft.ElevatedButton(
                            "إضافة موظف",
                            icon=ft.icons.ADD,
                            on_click=self._open_add,
                            bgcolor=ft.colors.BLUE_600,
                            color=ft.colors.WHITE,
                        ),
                    ],
                    alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                ),
                self.loading,
                ft.Container(
                    content=ft.Column([self.data_table], scroll=ft.ScrollMode.AUTO),
                    border=ft.border.all(1, ft.colors.GREY_200),
                    border_radius=10,
                    padding=8,
                    expand=True,
                ),
                ft.Row(
                    [
                        self.status,
                        ft.Row(
                            [
                                ft.IconButton(ft.icons.CHEVRON_RIGHT, on_click=self._prev_page),
                                ft.IconButton(ft.icons.CHEVRON_LEFT, on_click=self._next_page),
                            ]
                        ),
                    ],
                    alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                ),
            ],
            spacing=12,
            expand=True,
        )

    def _load_data(self):
        asyncio.ensure_future(self._fetch())

    async def _fetch(self):
        self.loading.visible = True
        self.page.update()
        try:
            data = await api_get("/employees", {
                "page": self.page_num,
                "page_size": 25,
                "search": self.search_field.value or "",
            })
            self.total = data["total"]
            self.status.value = f"الإجمالي: {self.total} | الصفحة {self.page_num}"
            self.data_table.rows = [
                ft.DataRow(cells=[
                    ft.DataCell(ft.Text(str(emp["emp_id"]))),
                    ft.DataCell(ft.Text(emp.get("file_number") or "—")),
                    ft.DataCell(ft.Text(emp.get("emp_name") or "—")),
                    ft.DataCell(ft.Text(emp.get("area", {}).get("area_name") if emp.get("area") else "—")),
                    ft.DataCell(ft.Text(emp.get("job", {}).get("job_name") if emp.get("job") else "—")),
                    ft.DataCell(ft.Text(emp.get("degree", {}).get("deg_name") if emp.get("degree") else "—")),
                ])
                for emp in data["items"]
            ]
        except Exception as ex:
            self.status.value = f"خطأ: {ex}"
        finally:
            self.loading.visible = False
            self.page.update()

    def _on_search(self, e):
        self.page_num = 1
        self._load_data()

    def _prev_page(self, e):
        if self.page_num > 1:
            self.page_num -= 1
            self._load_data()

    def _next_page(self, e):
        if self.page_num * 25 < self.total:
            self.page_num += 1
            self._load_data()

    def _open_add(self, e):
        dlg = AddEmployeeDialog(self.page, on_save=self._load_data)
        self.page.dialog = dlg.build()
        self.page.dialog.open = True
        self.page.update()


class AwardsView:
    def __init__(self, page: ft.Page):
        self.page = page
        self.search_field = ft.TextField(hint_text="بحث...", prefix_icon=ft.icons.SEARCH, on_change=self._on_search, width=280)
        self.data_table = ft.DataTable(
            columns=[
                ft.DataColumn(ft.Text("#")),
                ft.DataColumn(ft.Text("عنوان القرار")),
                ft.DataColumn(ft.Text("التاريخ")),
                ft.DataColumn(ft.Text("السبب")),
            ],
            rows=[],
            border=ft.border.all(1, ft.colors.GREY_200),
            border_radius=10,
        )
        self.status = ft.Text("", size=12, color=ft.colors.GREY_500)
        self.page_num = 1
        self.total = 0

    def build(self):
        self._load_data()
        return ft.Column(
            [
                ft.Row([ft.Icon(ft.icons.EMOJI_EVENTS, color=ft.colors.AMBER_600), ft.Text("قرارات المكافآت", size=18, weight=ft.FontWeight.BOLD)], spacing=8),
                ft.Row([self.search_field, ft.ElevatedButton("إضافة قرار", icon=ft.icons.ADD, bgcolor=ft.colors.AMBER_600, color=ft.colors.WHITE)], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                ft.Container(content=ft.Column([self.data_table], scroll=ft.ScrollMode.AUTO), border=ft.border.all(1, ft.colors.GREY_200), border_radius=10, padding=8, expand=True),
                self.status,
            ],
            spacing=12, expand=True,
        )

    def _load_data(self):
        asyncio.ensure_future(self._fetch())

    async def _fetch(self):
        try:
            data = await api_get("/awards", {"page": self.page_num, "page_size": 25, "search": self.search_field.value or ""})
            self.total = data["total"]
            self.status.value = f"الإجمالي: {self.total}"
            self.data_table.rows = [
                ft.DataRow(cells=[
                    ft.DataCell(ft.Text(str(a["award_id"]))),
                    ft.DataCell(ft.Text(a.get("award_title") or "—")),
                    ft.DataCell(ft.Text(str(a.get("award_date") or "—")[:10])),
                    ft.DataCell(ft.Text((a.get("award_reson") or "")[:40])),
                ])
                for a in data["items"]
            ]
        except Exception as ex:
            self.status.value = f"خطأ: {ex}"
        self.page.update()

    def _on_search(self, e):
        self.page_num = 1
        self._load_data()


class AddEmployeeDialog:
    def __init__(self, page, on_save):
        self.page = page
        self.on_save = on_save
        self.name = ft.TextField(label="الاسم الكامل", width=300)
        self.file_number = ft.TextField(label="رقم الملف (6 أرقام)", max_length=6, width=300)
        self.error = ft.Text("", color=ft.colors.RED_400)

    def build(self):
        return ft.AlertDialog(
            title=ft.Text("إضافة موظف جديد"),
            content=ft.Column([self.name, self.file_number, self.error], tight=True, spacing=10),
            actions=[
                ft.TextButton("إلغاء", on_click=lambda e: self._close()),
                ft.ElevatedButton("حفظ", on_click=self._save, bgcolor=ft.colors.BLUE_600, color=ft.colors.WHITE),
            ],
        )

    def _close(self):
        self.page.dialog.open = False
        self.page.update()

    async def _save_async(self):
        try:
            await api_post("/employees", {"emp_name": self.name.value, "file_number": self.file_number.value or None})
            self._close()
            self.on_save()
        except Exception as ex:
            self.error.value = str(ex)
            self.page.update()

    def _save(self, e):
        asyncio.ensure_future(self._save_async())


# ─── Main App Shell ────────────────────────────────────────────────────────────

def main(page: ft.Page):
    page.title = "نظام إدارة المكافآت"
    page.rtl = True
    page.theme_mode = ft.ThemeMode.LIGHT
    page.theme = ft.Theme(color_scheme_seed=ft.colors.BLUE_600, font_family="Cairo")
    page.window_width = 1100
    page.window_height = 720
    page.window_min_width = 800
    page.window_min_height = 600
    page.padding = 0

    current_view = ft.Ref[ft.Column]()
    nav_rail = ft.NavigationRail(
        selected_index=0,
        label_type=ft.NavigationRailLabelType.ALL,
        min_width=72,
        min_extended_width=180,
        extended=True,
        destinations=[
            ft.NavigationRailDestination(icon=ft.icons.PEOPLE_OUTLINED, selected_icon=ft.icons.PEOPLE, label="الموظفون"),
            ft.NavigationRailDestination(icon=ft.icons.EMOJI_EVENTS_OUTLINED, selected_icon=ft.icons.EMOJI_EVENTS, label="المكافآت"),
            ft.NavigationRailDestination(icon=ft.icons.LOCATION_ON_OUTLINED, selected_icon=ft.icons.LOCATION_ON, label="المناطق"),
            ft.NavigationRailDestination(icon=ft.icons.WORK_OUTLINED, selected_icon=ft.icons.WORK, label="الوظائف"),
            ft.NavigationRailDestination(icon=ft.icons.STAR_OUTLINED, selected_icon=ft.icons.STAR, label="الدرجات"),
        ],
        bgcolor=ft.colors.BLUE_GREY_900,
        indicator_color=ft.colors.BLUE_600,
    )

    content_area = ft.Container(expand=True, padding=24)

    def show_view(index: int):
        views = [EmployeesView, AwardsView]
        if index < len(views):
            v = views[index](page)
            content_area.content = v.build()
        else:
            content_area.content = ft.Text("قريباً...", size=16, color=ft.colors.GREY_400)
        page.update()

    def on_nav_change(e):
        show_view(e.control.selected_index)

    nav_rail.on_change = on_nav_change

    def build_main_shell():
        page.controls.clear()
        page.add(
            ft.Row(
                [
                    nav_rail,
                    ft.VerticalDivider(width=1, color=ft.colors.GREY_200),
                    content_area,
                ],
                expand=True,
                spacing=0,
            )
        )
        show_view(0)

    def on_login():
        build_main_shell()

    # Start with login view
    login_view = LoginView(page, on_login=on_login)
    page.add(login_view.build())
    page.update()


if __name__ == "__main__":
    ft.app(target=main)

<template>
  <el-config-provider :locale="arLocale" direction="rtl">
    <router-view />
  </el-config-provider>
</template>

<script setup>
import ar from 'element-plus/es/locale/lang/ar'
const arLocale = ar
</script>

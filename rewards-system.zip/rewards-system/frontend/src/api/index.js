import axios from 'axios'
import { useAuthStore } from '@/stores/auth'
import router from '@/router'

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL
    ? `${import.meta.env.VITE_API_URL}/api/v1`
    : '/api/v1',
  timeout: 30000,
  headers: { 'Content-Type': 'application/json' }
})

// Request: attach token
api.interceptors.request.use(config => {
  const token = localStorage.getItem('access_token')
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})

// Response: handle 401 → refresh token
api.interceptors.response.use(
  res => res,
  async err => {
    const original = err.config
    if (err.response?.status === 401 && !original._retry) {
      original._retry = true
      const refreshToken = localStorage.getItem('refresh_token')
      if (refreshToken) {
        try {
          const { data } = await axios.post(
            `${api.defaults.baseURL}/auth/refresh`,
            { refresh_token: refreshToken }
          )
          localStorage.setItem('access_token', data.access_token)
          localStorage.setItem('refresh_token', data.refresh_token)
          original.headers.Authorization = `Bearer ${data.access_token}`
          return api(original)
        } catch {
          localStorage.clear()
          router.push('/login')
        }
      } else {
        router.push('/login')
      }
    }
    return Promise.reject(err)
  }
)

export default api

// ─── Resource helpers ───────────────────────
export const authApi = {
  login: (data) => api.post('/auth/login', data),
  logout: () => api.post('/auth/logout'),
  me: () => api.get('/auth/me'),
  refresh: (token) => api.post('/auth/refresh', { refresh_token: token }),
  googleUrl: () => api.get('/auth/google')
}

export const areaApi = {
  list: (params) => api.get('/areas', { params }),
  get: (id) => api.get(`/areas/${id}`),
  create: (data) => api.post('/areas', data),
  update: (id, data) => api.put(`/areas/${id}`, data),
  delete: (id) => api.delete(`/areas/${id}`),
  bulkDelete: (ids) => api.post('/areas/bulk-delete', { ids }),
  stats: (id, params) => api.get(`/areas/${id}/stats`, { params }),
  exportCsv: (params) => api.get('/export/areas/csv', { params, responseType: 'blob' }),
  exportExcel: (params) => api.get('/export/areas/excel', { params, responseType: 'blob' })
}

export const employeeApi = {
  list: (params) => api.get('/employees', { params }),
  get: (id, params) => api.get(`/employees/${id}`, { params }),
  create: (data) => api.post('/employees', data),
  update: (id, data) => api.put(`/employees/${id}`, data),
  delete: (id) => api.delete(`/employees/${id}`),
  bulkDelete: (ids) => api.post('/employees/bulk-delete', { ids }),
  degreeDefaults: (id) => api.get(`/employees/${id}/degree-defaults`),
  addReward: (id, data) => api.post(`/employees/${id}/rewards`, data),
  exportCsv: (params) => api.get('/export/employees/csv', { params, responseType: 'blob' }),
  exportExcel: (params) => api.get('/export/employees/excel', { params, responseType: 'blob' })
}

export const jobApi = {
  list: (params) => api.get('/jobs', { params }),
  get: (id) => api.get(`/jobs/${id}`),
  create: (data) => api.post('/jobs', data),
  update: (id, data) => api.put(`/jobs/${id}`, data),
  delete: (id) => api.delete(`/jobs/${id}`),
  bulkDelete: (ids) => api.post('/jobs/bulk-delete', { ids })
}

export const degreeApi = {
  list: (params) => api.get('/degrees', { params }),
  get: (id) => api.get(`/degrees/${id}`),
  create: (data) => api.post('/degrees', data),
  update: (id, data) => api.put(`/degrees/${id}`, data),
  delete: (id) => api.delete(`/degrees/${id}`),
  bulkDelete: (ids) => api.post('/degrees/bulk-delete', { ids })
}

export const awardApi = {
  list: (params) => api.get('/awards', { params }),
  get: (id) => api.get(`/awards/${id}`),
  getEmployees: (id) => api.get(`/awards/${id}/employees`),
  create: (data) => api.post('/awards', data),
  update: (id, data) => api.put(`/awards/${id}`, data),
  delete: (id) => api.delete(`/awards/${id}`),
  bulkDelete: (ids) => api.post('/awards/bulk-delete', { ids }),
  addEmployee: (id, data) => api.post(`/awards/${id}/employees`, data),
  updateAwemp: (id, data) => api.put(`/awards/awemp/${id}`, data),
  deleteAwemp: (id) => api.delete(`/awards/awemp/${id}`),
  exportWord: (id, templateId) =>
    api.get(`/export/awards/${id}/word`, {
      params: templateId ? { template_id: templateId } : {},
      responseType: 'blob'
    })
}

export const userApi = {
  list: (params) => api.get('/users', { params }),
  get: (id) => api.get(`/users/${id}`),
  create: (data) => api.post('/users', data),
  update: (id, data) => api.put(`/users/${id}`, data),
  delete: (id) => api.delete(`/users/${id}`),
  groups: () => api.get('/users/groups/all'),
  permissions: () => api.get('/users/permissions/all'),
  assignGroup: (uid, gid) => api.post(`/users/${uid}/groups/${gid}`),
  removeGroup: (uid, gid) => api.delete(`/users/${uid}/groups/${gid}`)
}

export const notifApi = {
  list: (params) => api.get('/notifications', { params }),
  unreadCount: () => api.get('/notifications/unread-count'),
  markRead: (id) => api.patch(`/notifications/${id}/read`),
  markAllRead: () => api.patch('/notifications/mark-all-read'),
  delete: (id) => api.delete(`/notifications/${id}`)
}

export const logApi = {
  list: (params) => api.get('/logs', { params })
}

export const exportApi = {
  templates: (tableName) =>
    api.get('/export/templates', { params: { table_name: tableName } }),
  uploadTemplate: (formData) =>
    api.post('/export/templates/upload', formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    })
}

<template>
  <div>
    <!-- Filter bar -->
    <div class="filter-bar">
      <el-input
        v-model="localSearch"
        :placeholder="searchPlaceholder"
        clearable
        style="width: 280px"
        @input="onSearchDebounce"
      >
        <template #prefix><el-icon><Search /></el-icon></template>
      </el-input>

      <slot name="filters" />

      <el-button-group style="margin-right: auto">
        <el-button
          v-if="showExportCsv"
          :icon="Download"
          @click="$emit('export-csv')"
        >CSV</el-button>
        <el-button
          v-if="showExportExcel"
          :icon="Download"
          type="success"
          @click="$emit('export-excel')"
        >Excel</el-button>
        <el-button
          v-if="showExportWord"
          :icon="Document"
          type="warning"
          @click="$emit('export-word')"
        >Word</el-button>
      </el-button-group>

      <el-button
        v-if="canAdd"
        type="primary"
        :icon="Plus"
        @click="$emit('add')"
      >{{ addLabel }}</el-button>
    </div>

    <!-- Bulk actions bar -->
    <transition name="fade">
      <div v-if="selectedRows.length" class="bulk-bar">
        <span>تم تحديد {{ selectedRows.length }} سجل</span>
        <el-button
          v-if="canDelete"
          type="danger"
          size="small"
          :icon="Delete"
          @click="$emit('bulk-delete', selectedRows)"
        >حذف المحدد</el-button>
        <el-button size="small" @click="clearSelection">إلغاء التحديد</el-button>
      </div>
    </transition>

    <!-- Table -->
    <el-card style="margin-top: 0" shadow="never">
      <el-table
        ref="tableRef"
        v-loading="loading"
        :data="data"
        @selection-change="selectedRows = $event"
        @sort-change="onSortChange"
        stripe
        style="width: 100%"
        :row-key="rowKey"
      >
        <el-table-column v-if="canDelete" type="selection" width="48" />

        <slot />

        <el-table-column label="إجراءات" width="130" fixed="left" v-if="showActions">
          <template #default="{ row }">
            <el-button-group>
              <el-button
                v-if="canView"
                size="small"
                text
                :icon="View"
                @click="$emit('view', row)"
              />
              <el-button
                v-if="canEdit"
                size="small"
                text
                type="primary"
                :icon="Edit"
                @click="$emit('edit', row)"
              />
              <el-popconfirm
                v-if="canDelete"
                :title="`هل أنت متأكد من حذف هذا السجل؟`"
                confirm-button-text="حذف"
                cancel-button-text="إلغاء"
                confirm-button-type="danger"
                @confirm="$emit('delete', row)"
              >
                <template #reference>
                  <el-button size="small" text type="danger" :icon="Delete" />
                </template>
              </el-popconfirm>
            </el-button-group>
          </template>
        </el-table-column>
      </el-table>

      <!-- Pagination -->
      <div class="table-footer">
        <span class="total-label">الإجمالي: {{ total }} سجل</span>
        <el-pagination
          v-model:current-page="localPage"
          v-model:page-size="localPageSize"
          :page-sizes="[10, 25, 50, 100]"
          layout="sizes, prev, pager, next"
          :total="total"
          @change="$emit('page-change', { page: localPage, pageSize: localPageSize })"
        />
      </div>
    </el-card>
  </div>
</template>

<script setup>
import { ref, watch } from 'vue'
import { Search, Plus, Delete, Edit, View, Download, Document } from '@element-plus/icons-vue'

const props = defineProps({
  data: Array,
  total: { type: Number, default: 0 },
  loading: Boolean,
  rowKey: { type: String, default: 'id' },
  searchPlaceholder: { type: String, default: 'بحث...' },
  addLabel: { type: String, default: 'إضافة' },
  canAdd: { type: Boolean, default: true },
  canEdit: { type: Boolean, default: true },
  canDelete: { type: Boolean, default: true },
  canView: { type: Boolean, default: false },
  showActions: { type: Boolean, default: true },
  showExportCsv: { type: Boolean, default: false },
  showExportExcel: { type: Boolean, default: false },
  showExportWord: { type: Boolean, default: false },
  page: { type: Number, default: 1 },
  pageSize: { type: Number, default: 25 }
})

const emit = defineEmits([
  'add', 'edit', 'delete', 'view', 'bulk-delete',
  'search', 'page-change', 'sort-change',
  'export-csv', 'export-excel', 'export-word'
])

const tableRef = ref()
const selectedRows = ref([])
const localSearch = ref('')
const localPage = ref(props.page)
const localPageSize = ref(props.pageSize)

let searchTimer = null
function onSearchDebounce() {
  clearTimeout(searchTimer)
  searchTimer = setTimeout(() => emit('search', localSearch.value), 350)
}

function onSortChange({ prop, order }) {
  emit('sort-change', { sortBy: prop, sortDir: order === 'ascending' ? 'asc' : 'desc' })
}

function clearSelection() {
  tableRef.value?.clearSelection()
  selectedRows.value = []
}
</script>

<style scoped>
.bulk-bar {
  display: flex;
  align-items: center;
  gap: 12px;
  background: #eff6ff;
  border: 1px solid #bfdbfe;
  border-radius: 8px;
  padding: 8px 16px;
  margin-bottom: 10px;
  font-weight: 600;
  font-size: .9rem;
  color: var(--primary);
}
.table-footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding-top: 16px;
  flex-wrap: wrap;
  gap: 12px;
}
.total-label { color: var(--text-muted); font-size: .88rem; }
</style>

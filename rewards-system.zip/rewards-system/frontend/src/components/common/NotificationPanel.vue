<template>
  <div class="notif-panel">
    <div class="notif-header">
      <span class="notif-title">الإشعارات</span>
      <el-button text size="small" @click="markAll">تعليم الكل كمقروء</el-button>
    </div>
    <div v-if="loading" class="notif-loading"><el-icon class="is-loading"><Loading /></el-icon></div>
    <div v-else-if="!items.length" class="notif-empty">لا توجد إشعارات</div>
    <div v-else class="notif-list">
      <div
        v-for="n in items"
        :key="n.id"
        class="notif-item"
        :class="{ unread: !n.is_read }"
        @click="markOne(n)"
      >
        <div class="notif-dot" v-if="!n.is_read" />
        <div class="notif-body">
          <div class="notif-item-title">{{ n.title }}</div>
          <div class="notif-msg">{{ n.message }}</div>
          <div class="notif-time">{{ dayjs(n.created_at).fromNow() }}</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { notifApi } from '@/api'
import dayjs from 'dayjs'
import relativeTime from 'dayjs/plugin/relativeTime'
import 'dayjs/locale/ar'
dayjs.extend(relativeTime)
dayjs.locale('ar')

const emit = defineEmits(['read'])
const items = ref([])
const loading = ref(false)

async function load() {
  loading.value = true
  try {
    const { data } = await notifApi.list({ page_size: 20 })
    items.value = data.items
  } finally {
    loading.value = false
  }
}

async function markOne(n) {
  if (!n.is_read) {
    await notifApi.markRead(n.id)
    n.is_read = true
    emit('read')
  }
}

async function markAll() {
  await notifApi.markAllRead()
  items.value.forEach(n => n.is_read = true)
  emit('read')
}

onMounted(load)
</script>

<style scoped>
.notif-panel { min-height: 80px; }
.notif-header { display: flex; justify-content: space-between; align-items: center; padding: 0 0 12px; border-bottom: 1px solid var(--border); margin-bottom: 8px; }
.notif-title { font-weight: 700; font-size: 1rem; }
.notif-loading, .notif-empty { text-align: center; padding: 24px; color: var(--text-muted); }
.notif-list { max-height: 340px; overflow-y: auto; }
.notif-item { display: flex; gap: 10px; padding: 10px 8px; border-radius: 8px; cursor: pointer; transition: background .15s; }
.notif-item:hover { background: #f8fafc; }
.notif-item.unread { background: #eff6ff; }
.notif-dot { width: 8px; height: 8px; border-radius: 50%; background: var(--primary); flex-shrink: 0; margin-top: 6px; }
.notif-item-title { font-weight: 600; font-size: .88rem; }
.notif-msg { font-size: .82rem; color: var(--text-muted); margin-top: 2px; }
.notif-time { font-size: .75rem; color: #94a3b8; margin-top: 4px; }
</style>

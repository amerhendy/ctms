<template>
  <div class="app-layout">
    <!-- Sidebar -->
    <aside class="sidebar" :class="{ collapsed: sidebarCollapsed }">
      <div class="sidebar-logo">
        <el-icon size="28" color="#fff"><Trophy /></el-icon>
        <span v-if="!sidebarCollapsed" class="logo-text">نظام المكافآت</span>
      </div>

      <el-menu
        :collapse="sidebarCollapsed"
        :default-active="route.path"
        router
        class="sidebar-menu"
        background-color="transparent"
        text-color="#cbd5e1"
        active-text-color="#ffffff"
      >
        <el-menu-item index="/dashboard">
          <el-icon><DataAnalysis /></el-icon>
          <template #title>لوحة التحكم</template>
        </el-menu-item>

        <el-menu-item index="/awards" v-if="auth.can('view_awardes')">
          <el-icon><Medal /></el-icon>
          <template #title>قرارات المكافآت</template>
        </el-menu-item>

        <el-menu-item index="/employees" v-if="auth.can('view_employee')">
          <el-icon><User /></el-icon>
          <template #title>الموظفون</template>
        </el-menu-item>

        <el-menu-item index="/areas" v-if="auth.can('view_area')">
          <el-icon><Location /></el-icon>
          <template #title>المناطق</template>
        </el-menu-item>

        <el-menu-item index="/jobs" v-if="auth.can('view_empjob')">
          <el-icon><Briefcase /></el-icon>
          <template #title>الوظائف</template>
        </el-menu-item>

        <el-menu-item index="/degrees" v-if="auth.can('view_awdeg')">
          <el-icon><Star /></el-icon>
          <template #title>درجات المكافأة</template>
        </el-menu-item>

        <el-divider style="border-color: #334155; margin: 8px 0" />

        <el-menu-item index="/users" v-if="auth.can('view_user')">
          <el-icon><UserFilled /></el-icon>
          <template #title>المستخدمون</template>
        </el-menu-item>

        <el-menu-item index="/logs" v-if="auth.can('view_logentry')">
          <el-icon><Document /></el-icon>
          <template #title>سجل التغييرات</template>
        </el-menu-item>

        <el-menu-item index="/settings">
          <el-icon><Setting /></el-icon>
          <template #title>الإعدادات</template>
        </el-menu-item>
      </el-menu>
    </aside>

    <!-- Main -->
    <div class="main-wrapper">
      <!-- Header -->
      <header class="app-header">
        <div class="header-right">
          <el-button text @click="sidebarCollapsed = !sidebarCollapsed">
            <el-icon size="20"><Fold v-if="!sidebarCollapsed" /><Expand v-else /></el-icon>
          </el-button>
          <el-breadcrumb separator="/">
            <el-breadcrumb-item :to="{ path: '/' }">الرئيسية</el-breadcrumb-item>
            <el-breadcrumb-item>{{ route.name }}</el-breadcrumb-item>
          </el-breadcrumb>
        </div>

        <div class="header-left">
          <!-- Notifications bell -->
          <el-popover placement="bottom-end" width="360" trigger="click">
            <template #reference>
              <el-badge :value="unreadCount || ''" :hidden="!unreadCount">
                <el-button text circle>
                  <el-icon size="20"><Bell /></el-icon>
                </el-button>
              </el-badge>
            </template>
            <NotificationPanel @read="loadUnread" />
          </el-popover>

          <!-- User menu -->
          <el-dropdown @command="handleUserCommand">
            <div class="user-avatar">
              <el-avatar :size="36" :src="auth.user?.avatar_url">
                {{ auth.user?.full_name?.[0] }}
              </el-avatar>
              <span class="user-name">{{ auth.user?.full_name }}</span>
            </div>
            <template #dropdown>
              <el-dropdown-menu>
                <el-dropdown-item command="profile">الملف الشخصي</el-dropdown-item>
                <el-dropdown-item command="logout" divided>تسجيل الخروج</el-dropdown-item>
              </el-dropdown-menu>
            </template>
          </el-dropdown>
        </div>
      </header>

      <!-- Content -->
      <main class="app-content">
        <transition name="fade" mode="out-in">
          <router-view :key="route.path" />
        </transition>
      </main>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import { notifApi } from '@/api'
import NotificationPanel from '@/components/common/NotificationPanel.vue'
import { ElMessage } from 'element-plus'

const route = useRoute()
const router = useRouter()
const auth = useAuthStore()
const sidebarCollapsed = ref(false)
const unreadCount = ref(0)

async function loadUnread() {
  try {
    const { data } = await notifApi.unreadCount()
    unreadCount.value = data.unread_count
  } catch {}
}

async function handleUserCommand(cmd) {
  if (cmd === 'logout') {
    await auth.logout()
    router.push('/login')
    ElMessage.success('تم تسجيل الخروج')
  }
}

onMounted(loadUnread)
</script>

<style scoped>
.app-layout { display: flex; height: 100vh; overflow: hidden; }

/* Sidebar */
.sidebar {
  width: var(--sidebar-width);
  background: linear-gradient(160deg, #1e293b 0%, #0f172a 100%);
  display: flex;
  flex-direction: column;
  transition: width .25s;
  overflow: hidden;
  flex-shrink: 0;
  box-shadow: 2px 0 12px rgba(0,0,0,.2);
  z-index: 100;
}
.sidebar.collapsed { width: 64px; }

.sidebar-logo {
  height: var(--header-height);
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 0 18px;
  border-bottom: 1px solid #334155;
  flex-shrink: 0;
}
.logo-text { color: #fff; font-weight: 700; font-size: 1rem; white-space: nowrap; }

.sidebar-menu { border: none; flex: 1; overflow-y: auto; overflow-x: hidden; }
.sidebar-menu .el-menu-item { border-radius: 8px; margin: 2px 8px; }
.sidebar-menu .el-menu-item.is-active { background: rgba(37,99,235,.6) !important; }
.sidebar-menu .el-menu-item:hover { background: rgba(255,255,255,.07) !important; }

/* Header */
.main-wrapper { flex: 1; display: flex; flex-direction: column; overflow: hidden; }

.app-header {
  height: var(--header-height);
  background: var(--surface);
  border-bottom: 1px solid var(--border);
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 20px;
  flex-shrink: 0;
  box-shadow: 0 1px 3px rgba(0,0,0,.06);
}
.header-right, .header-left { display: flex; align-items: center; gap: 12px; }

.user-avatar { display: flex; align-items: center; gap: 8px; cursor: pointer; }
.user-name { font-weight: 600; font-size: .9rem; }

/* Content */
.app-content { flex: 1; overflow-y: auto; padding: 24px; background: var(--bg); }
</style>

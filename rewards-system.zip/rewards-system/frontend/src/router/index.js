import { createRouter, createWebHistory } from 'vue-router'
import { useAuthStore } from '@/stores/auth'

const routes = [
  {
    path: '/login',
    name: 'Login',
    component: () => import('@/views/auth/LoginView.vue'),
    meta: { public: true }
  },
  {
    path: '/',
    component: () => import('@/components/layout/AppLayout.vue'),
    meta: { requiresAuth: true },
    children: [
      { path: '', redirect: '/dashboard' },
      { path: 'dashboard', name: 'Dashboard', component: () => import('@/views/dashboard/DashboardView.vue') },
      // Areas
      { path: 'areas', name: 'Areas', component: () => import('@/views/area/AreaList.vue') },
      { path: 'areas/:id', name: 'AreaDetail', component: () => import('@/views/area/AreaDetail.vue') },
      // Employees
      { path: 'employees', name: 'Employees', component: () => import('@/views/employee/EmployeeList.vue') },
      { path: 'employees/:id', name: 'EmployeeDetail', component: () => import('@/views/employee/EmployeeDetail.vue') },
      // Jobs
      { path: 'jobs', name: 'Jobs', component: () => import('@/views/empjob/JobList.vue') },
      // Degrees
      { path: 'degrees', name: 'Degrees', component: () => import('@/views/awdeg/DegreeList.vue') },
      // Awards
      { path: 'awards', name: 'Awards', component: () => import('@/views/awardes/AwardList.vue') },
      { path: 'awards/:id', name: 'AwardDetail', component: () => import('@/views/awardes/AwardDetail.vue') },
      // Users & permissions
      { path: 'users', name: 'Users', component: () => import('@/views/users/UserList.vue') },
      { path: 'settings', name: 'Settings', component: () => import('@/views/settings/SettingsView.vue') },
      // Logs
      { path: 'logs', name: 'Logs', component: () => import('@/views/logs/LogList.vue') }
    ]
  },
  { path: '/:pathMatch(.*)*', redirect: '/' }
]

const router = createRouter({
  history: createWebHistory(),
  routes,
  scrollBehavior: () => ({ top: 0 })
})

router.beforeEach((to) => {
  const auth = useAuthStore()
  if (!to.meta.public && !auth.isLoggedIn) return '/login'
  if (to.path === '/login' && auth.isLoggedIn) return '/'
})

export default router

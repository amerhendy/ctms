import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import { authApi } from '@/api'

export const useAuthStore = defineStore('auth', () => {
  const user = ref(JSON.parse(localStorage.getItem('user') || 'null'))
  const accessToken = ref(localStorage.getItem('access_token') || '')

  const isLoggedIn = computed(() => !!accessToken.value)
  const isAdmin = computed(() => user.value?.global_admin || false)

  // All permission codenames the user has
  const userPermissions = computed(() => {
    if (!user.value) return new Set()
    if (user.value.global_admin) return new Set(['*'])
    const perms = new Set()
    user.value.groups?.forEach(g => g.permissions?.forEach(p => perms.add(p.codename)))
    return perms
  })

  function can(codename) {
    if (!user.value) return false
    if (user.value.global_admin) return true
    return userPermissions.value.has(codename)
  }

  async function login(username, password) {
    const { data } = await authApi.login({ username, password })
    accessToken.value = data.access_token
    user.value = data.user
    localStorage.setItem('access_token', data.access_token)
    localStorage.setItem('refresh_token', data.refresh_token)
    localStorage.setItem('user', JSON.stringify(data.user))
    return data
  }

  async function logout() {
    try { await authApi.logout() } catch {}
    accessToken.value = ''
    user.value = null
    localStorage.clear()
  }

  async function fetchMe() {
    const { data } = await authApi.me()
    user.value = data
    localStorage.setItem('user', JSON.stringify(data))
  }

  return { user, accessToken, isLoggedIn, isAdmin, userPermissions, can, login, logout, fetchMe }
})

<template>
  <div v-loading="loading">
    <div class="page-header">
      <h1>
        <el-button text :icon="ArrowRight" @click="$router.back()" />
        <el-icon><Location /></el-icon>
        منطقة: {{ area?.area_name }}
      </h1>
      <el-button v-if="auth.can('change_area')" type="primary" :icon="Edit" @click="showEdit = true">
        تعديل
      </el-button>
    </div>

    <!-- Stats -->
    <div class="stats-grid" style="grid-template-columns: repeat(3, 1fr)">
      <div class="stat-card">
        <div class="stat-icon" style="background:#eff6ff">
          <el-icon size="22" color="#2563eb"><User /></el-icon>
        </div>
        <div class="stat-info">
          <div class="value" style="color:#2563eb">{{ area?.employees?.length ?? 0 }}</div>
          <div class="label">عدد الموظفين</div>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon" style="background:#ecfdf5">
          <el-icon size="22" color="#059669"><Money /></el-icon>
        </div>
        <div class="stat-info">
          <div class="value" style="color:#059669">{{ totalRewards.toLocaleString('ar') }}</div>
          <div class="label">إجمالي المكافآت</div>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon" style="background:#fffbeb">
          <el-icon size="22" color="#d97706"><Calendar /></el-icon>
        </div>
        <div class="stat-info">
          <div class="label" style="font-size:.8rem">فلترة حسب التاريخ</div>
          <el-date-picker
            v-model="dateRange"
            type="daterange"
            range-separator="إلى"
            start-placeholder="من"
            end-placeholder="إلى"
            format="YYYY/MM/DD"
            value-format="YYYY-MM-DD"
            size="small"
            style="margin-top:4px"
            @change="loadStats"
          />
        </div>
      </div>
    </div>

    <!-- Employees in area -->
    <el-card shadow="never" style="margin-top: 0">
      <template #header>
        <div style="display:flex; justify-content:space-between; align-items:center">
          <span style="font-weight:700">موظفو المنطقة</span>
          <el-button
            v-if="auth.can('change_employee')"
            type="primary"
            size="small"
            :icon="Plus"
            @click="showAddEmp = true"
          >إضافة موظف</el-button>
        </div>
      </template>

      <el-table :data="area?.employees" stripe>
        <el-table-column prop="emp_id" label="#" width="70" />
        <el-table-column prop="file_number" label="رقم الملف" width="100" />
        <el-table-column prop="emp_name" label="الاسم" />
        <el-table-column label="الوظيفة">
          <template #default="{ row }">{{ row.job?.job_name || '—' }}</template>
        </el-table-column>
        <el-table-column label="الدرجة">
          <template #default="{ row }">{{ row.degree?.deg_name || '—' }}</template>
        </el-table-column>
        <el-table-column label="إجراءات" width="130">
          <template #default="{ row }">
            <el-button text type="primary" size="small" @click="$router.push(`/employees/${row.emp_id}`)">عرض</el-button>
            <el-popconfirm
              title="إزالة الموظف من هذه المنطقة؟"
              confirm-button-text="نعم"
              cancel-button-text="لا"
              @confirm="removeEmployee(row)"
            >
              <template #reference>
                <el-button text type="danger" size="small" v-if="auth.can('change_employee')">إزالة</el-button>
              </template>
            </el-popconfirm>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- Edit dialog -->
    <el-dialog v-model="showEdit" title="تعديل المنطقة" width="400px">
      <el-form :model="editForm" ref="editRef" label-position="top">
        <el-form-item label="اسم المنطقة" :rules="[{ required: true }]" prop="area_name">
          <el-input v-model="editForm.area_name" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showEdit = false">إلغاء</el-button>
        <el-button type="primary" :loading="saving" @click="saveEdit">حفظ</el-button>
      </template>
    </el-dialog>

    <!-- Add employee dialog -->
    <el-dialog v-model="showAddEmp" title="إضافة موظف للمنطقة" width="480px">
      <el-form label-position="top">
        <el-form-item label="اختر موظفاً">
          <el-select
            v-model="selectedEmpId"
            filterable
            remote
            :remote-method="searchEmployees"
            placeholder="ابحث باسم الموظف أو رقم الملف"
            style="width: 100%"
            :loading="empSearchLoading"
          >
            <el-option
              v-for="e in empOptions"
              :key="e.emp_id"
              :label="`${e.emp_name} (${e.file_number || '—'})`"
              :value="e.emp_id"
            />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showAddEmp = false">إلغاء</el-button>
        <el-button type="primary" :disabled="!selectedEmpId" @click="addEmployee">إضافة</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import { areaApi, employeeApi } from '@/api'
import { ElMessage } from 'element-plus'
import { ArrowRight, Edit, Plus } from '@element-plus/icons-vue'

const route = useRoute()
const auth = useAuthStore()

const area = ref(null)
const loading = ref(false)
const saving = ref(false)
const showEdit = ref(false)
const showAddEmp = ref(false)
const editRef = ref()
const editForm = reactive({ area_name: '' })
const dateRange = ref(null)
const totalRewards = ref(0)
const selectedEmpId = ref(null)
const empOptions = ref([])
const empSearchLoading = ref(false)

async function load() {
  loading.value = true
  try {
    const { data } = await areaApi.get(route.params.id)
    area.value = data
    editForm.area_name = data.area_name
    await loadStats()
  } finally {
    loading.value = false
  }
}

async function loadStats() {
  const params = {}
  if (dateRange.value) {
    params.date_from = dateRange.value[0]
    params.date_to = dateRange.value[1]
  }
  const { data } = await areaApi.stats(route.params.id, params)
  totalRewards.value = data.total_rewards || 0
}

async function saveEdit() {
  saving.value = true
  try {
    await areaApi.update(area.value.area_id, editForm)
    area.value.area_name = editForm.area_name
    showEdit.value = false
    ElMessage.success('تم التعديل')
  } finally {
    saving.value = false
  }
}

async function removeEmployee(emp) {
  await employeeApi.update(emp.emp_id, { area_id: null })
  area.value.employees = area.value.employees.filter(e => e.emp_id !== emp.emp_id)
  ElMessage.success('تمت الإزالة')
}

async function searchEmployees(query) {
  if (!query) return
  empSearchLoading.value = true
  try {
    const { data } = await employeeApi.list({ search: query, page_size: 20 })
    empOptions.value = data.items
  } finally {
    empSearchLoading.value = false
  }
}

async function addEmployee() {
  if (!selectedEmpId.value) return
  await employeeApi.update(selectedEmpId.value, { area_id: area.value.area_id })
  ElMessage.success('تمت الإضافة')
  showAddEmp.value = false
  selectedEmpId.value = null
  await load()
}

onMounted(load)
</script>

<template>
  <div>
    <div class="page-header">
      <h1><el-icon><Location /></el-icon> المناطق</h1>
    </div>

    <DataTable
      :data="areas"
      :total="total"
      :loading="loading"
      row-key="area_id"
      search-placeholder="بحث باسم المنطقة..."
      add-label="إضافة منطقة"
      :can-add="auth.can('add_area')"
      :can-edit="auth.can('change_area')"
      :can-delete="auth.can('delete_area')"
      :can-view="true"
      :show-export-csv="auth.can('view_area')"
      :show-export-excel="auth.can('view_area')"
      @add="openForm()"
      @edit="openForm($event)"
      @delete="doDelete($event)"
      @view="goDetail($event)"
      @bulk-delete="doBulkDelete($event)"
      @search="q => { params.search = q; params.page = 1; load() }"
      @page-change="p => { params.page = p.page; params.page_size = p.pageSize; load() }"
      @sort-change="s => { params.sort_by = s.sortBy; params.sort_dir = s.sortDir; load() }"
      @export-csv="exportCsv"
      @export-excel="exportExcel"
    >
      <el-table-column prop="area_id" label="#" width="70" sortable="custom" />
      <el-table-column prop="area_name" label="اسم المنطقة" sortable="custom" />
      <el-table-column label="عدد الموظفين" width="130">
        <template #default="{ row }">
          <el-tag>{{ row.employees?.length ?? 0 }}</el-tag>
        </template>
      </el-table-column>
    </DataTable>

    <!-- Form Dialog -->
    <el-dialog v-model="showForm" :title="editRow ? 'تعديل منطقة' : 'إضافة منطقة'" width="420px">
      <el-form :model="form" :rules="rules" ref="formRef" label-position="top">
        <el-form-item label="اسم المنطقة" prop="area_name">
          <el-input v-model="form.area_name" placeholder="أدخل اسم المنطقة" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showForm = false">إلغاء</el-button>
        <el-button type="primary" :loading="saving" @click="save">حفظ</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import { areaApi } from '@/api'
import { ElMessage, ElMessageBox } from 'element-plus'
import DataTable from '@/components/common/DataTable.vue'

const auth = useAuthStore()
const router = useRouter()

const areas = ref([])
const total = ref(0)
const loading = ref(false)
const saving = ref(false)
const showForm = ref(false)
const editRow = ref(null)
const formRef = ref()

const params = reactive({ page: 1, page_size: 25, search: '', sort_by: 'area_id', sort_dir: 'asc' })
const form = reactive({ area_name: '' })
const rules = { area_name: [{ required: true, message: 'الحقل مطلوب' }] }

async function load() {
  loading.value = true
  try {
    const { data } = await areaApi.list(params)
    areas.value = data.items
    total.value = data.total
  } finally {
    loading.value = false
  }
}

function openForm(row = null) {
  editRow.value = row
  form.area_name = row?.area_name || ''
  showForm.value = true
  formRef.value?.clearValidate()
}

async function save() {
  const valid = await formRef.value?.validate().catch(() => false)
  if (!valid) return
  saving.value = true
  try {
    if (editRow.value) {
      await areaApi.update(editRow.value.area_id, form)
      ElMessage.success('تم التعديل')
    } else {
      await areaApi.create(form)
      ElMessage.success('تمت الإضافة')
    }
    showForm.value = false
    load()
  } catch (e) {
    ElMessage.error(e.response?.data?.detail || 'حدث خطأ')
  } finally {
    saving.value = false
  }
}

async function doDelete(row) {
  await areaApi.delete(row.area_id)
  ElMessage.success('تم الحذف')
  load()
}

async function doBulkDelete(rows) {
  await ElMessageBox.confirm(`هل تريد حذف ${rows.length} سجل؟`, 'تأكيد الحذف', {
    confirmButtonText: 'حذف', cancelButtonText: 'إلغاء', type: 'warning'
  })
  await areaApi.bulkDelete(rows.map(r => r.area_id))
  ElMessage.success('تم الحذف الجماعي')
  load()
}

function goDetail(row) {
  router.push(`/areas/${row.area_id}`)
}

function downloadBlob(blob, name) {
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url; a.download = name; a.click()
  URL.revokeObjectURL(url)
}

async function exportCsv() {
  const { data } = await areaApi.exportCsv(params)
  downloadBlob(data, 'areas.csv')
}
async function exportExcel() {
  const { data } = await areaApi.exportExcel(params)
  downloadBlob(data, 'areas.xlsx')
}

onMounted(load)
</script>

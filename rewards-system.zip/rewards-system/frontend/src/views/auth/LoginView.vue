<template>
  <div class="login-page">
    <div class="login-card">
      <div class="login-logo">
        <el-icon size="48" color="#2563eb"><Trophy /></el-icon>
        <h1>نظام إدارة المكافآت</h1>
        <p>Rewards Management System</p>
      </div>

      <el-form :model="form" :rules="rules" ref="formRef" label-position="top" @submit.prevent="doLogin">
        <el-form-item label="البريد الإلكتروني أو رقم الملف" prop="username">
          <el-input
            v-model="form.username"
            placeholder="أدخل البريد الإلكتروني أو رقم الملف"
            size="large"
            :prefix-icon="User"
            autocomplete="username"
          />
        </el-form-item>

        <el-form-item label="كلمة المرور" prop="password">
          <el-input
            v-model="form.password"
            type="password"
            placeholder="أدخل كلمة المرور"
            size="large"
            :prefix-icon="Lock"
            show-password
            autocomplete="current-password"
            @keyup.enter="doLogin"
          />
        </el-form-item>

        <el-button
          type="primary"
          size="large"
          :loading="loading"
          style="width: 100%; margin-top: 8px; font-size: 1rem; height: 48px"
          @click="doLogin"
        >
          تسجيل الدخول
        </el-button>

        <el-divider>أو</el-divider>

        <el-button
          size="large"
          style="width: 100%"
          @click="loginGoogle"
        >
          <img src="https://www.google.com/favicon.ico" width="18" style="margin-left: 8px" />
          الدخول عبر Google
        </el-button>
      </el-form>
    </div>

    <div class="login-bg" />
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import { ElMessage } from 'element-plus'
import { User, Lock } from '@element-plus/icons-vue'
import { authApi } from '@/api'

const router = useRouter()
const auth = useAuthStore()
const formRef = ref()
const loading = ref(false)

const form = ref({ username: '', password: '' })
const rules = {
  username: [{ required: true, message: 'الحقل مطلوب' }],
  password: [{ required: true, message: 'الحقل مطلوب' }]
}

async function doLogin() {
  const valid = await formRef.value?.validate().catch(() => false)
  if (!valid) return
  loading.value = true
  try {
    await auth.login(form.value.username, form.value.password)
    ElMessage.success('مرحباً ' + auth.user?.full_name)
    router.push('/')
  } catch (e) {
    ElMessage.error(e.response?.data?.detail || 'بيانات الدخول غير صحيحة')
  } finally {
    loading.value = false
  }
}

async function loginGoogle() {
  try {
    const { data } = await authApi.googleUrl()
    window.location.href = data.url
  } catch {
    ElMessage.error('خطأ في الاتصال بـ Google')
  }
}
</script>

<style scoped>
.login-page {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(135deg, #1e3a5f 0%, #2563eb 100%);
  position: relative;
  overflow: hidden;
}
.login-bg {
  position: absolute;
  inset: 0;
  background: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.04'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
}
.login-card {
  background: #fff;
  border-radius: 20px;
  padding: 40px 44px;
  width: 420px;
  box-shadow: 0 24px 64px rgba(0,0,0,.25);
  z-index: 1;
  position: relative;
}
.login-logo {
  text-align: center;
  margin-bottom: 32px;
}
.login-logo h1 {
  font-size: 1.4rem;
  font-weight: 700;
  margin-top: 12px;
  color: #1e293b;
}
.login-logo p {
  color: #64748b;
  font-size: .85rem;
  margin-top: 4px;
}
</style>

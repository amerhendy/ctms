<template>
  <div v-loading="loading">
    <div class="page-header">
      <h1>
        <el-button text :icon="ArrowRight" @click="$router.back()" />
        <el-icon><Medal /></el-icon>
        {{ award?.award_title }}
      </h1>
      <div style="display:flex; gap:8px">
        <el-button :icon="Download" @click="exportWord">تصدير Word</el-button>
        <el-button v-if="auth.can('change_awardes')" type="primary" :icon="Edit" @click="$router.push('/awards')">
          العودة للقائمة
        </el-button>
      </div>
    </div>

    <!-- Award info -->
    <el-card shadow="never" style="margin-bottom: 16px">
      <el-descriptions :column="3" border>
        <el-descriptions-item label="عنوان القرار">{{ award?.award_title }}</el-descriptions-item>
        <el-descriptions-item label="تاريخ القرار">{{ formatDate(award?.award_date) }}</el-descriptions-item>
        <el-descriptions-item label="عدد الموظفين">
          <el-tag>{{ awemps.length }}</el-tag>
        </el-descriptions-item>
        <el-descriptions-item label="سبب المكافأة" :span="3">{{ award?.award_reson || '—' }}</el-descriptions-item>
      </el-descriptions>
    </el-card>

    <!-- Summary -->
    <div class="stats-grid" style="grid-template-columns: repeat(3, 1fr); margin-bottom: 16px">
      <div class="stat-card">
        <div class="stat-icon" style="background:#eff6ff">
          <el-icon size="22" color="#2563eb"><User /></el-icon>
        </div>
        <div class="stat-info">
          <div class="value" style="color:#2563eb">{{ awemps.length }}</div>
          <div class="label">عدد الموظفين</div>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon" style="background:#ecfdf5">
          <el-icon size="22" color="#059669"><Money /></el-icon>
        </div>
        <div class="stat-info">
          <div class="value" style="color:#059669">{{ totalAmount.toLocaleString('ar') }}</div>
          <div class="label">الإجمالي بعد الضريبة</div>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon" style="background:#f5f3ff">
          <el-icon size="22" color="#7c3aed"><Coin /></el-icon>
        </div>
        <div class="stat-info">
          <div class="value" style="color:#7c3aed">{{ totalBase.toLocaleString('ar') }}</div>
          <div class="label">المبلغ الأساسي قبل الضريبة</div>
        </div>
      </div>
    </div>

    <!-- Employees table -->
    <el-card shadow="never">
      <template #header>
        <div style="display:flex; justify-content:space-between; align-items:center">
          <span style="font-weight:700">قائمة الموظفين المستفيدين</span>
          <el-button
            v-if="auth.can('add_awemp')"
            type="primary" size="small" :icon="Plus"
            @click="showAddEmp = true"
          >إضافة موظف</el-button>
        </div>
      </template>

      <el-table :data="awemps" stripe>
        <el-table-column type="index" width="50" />
        <el-table-column label="الاسم">
          <template #default="{ row }">{{ row.employee?.emp_name || '—' }}</template>
        </el-table-column>
        <el-table-column label="رقم الملف" width="100">
          <template #default="{ row }">{{ row.employee?.file_number || '—' }}</template>
        </el-table-column>
        <el-table-column label="المنطقة">
          <template #default="{ row }">{{ row.employee?.area?.area_name || '—' }}</template>
        </el-table-column>
        <el-table-column label="الوظيفة">
          <template #default="{ row }">{{ row.employee?.job?.job_name || '—' }}</template>
        </el-table-column>
        <el-table-column prop="aw_mony" label="المبلغ الأساسي" width="120" align="left">
          <template #default="{ row }">{{ Number(row.aw_mony || 0).toLocaleString('ar') }}</template>
        </el-table-column>
        <el-table-column prop="tax_percent_applied" label="الضريبة %" width="85" align="center" />
        <el-table-column label="الإجمالي" width="120" align="left">
          <template #default="{ row }">
            <strong style="color:#059669">{{ Number(row.total_amount || 0).toLocaleString('ar') }}</strong>
          </template>
        </el-table-column>
        <el-table-column prop="award_date" label="تاريخ الصرف" width="120" />
        <el-table-column label="إجراءات" width="90">
          <template #default="{ row }">
            <el-button text type="primary" size="small" :icon="Edit" @click="openEditEmp(row)" v-if="auth.can('change_awemp')" />
            <el-popconfirm title="حذف هذا الموظف من القرار؟" @confirm="deleteAwemp(row)">
              <template #reference>
                <el-button text type="danger" size="small" :icon="Delete" v-if="auth.can('delete_awemp')" />
              </template>
            </el-popconfirm>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- Add employee dialog -->
    <el-dialog v-model="showAddEmp" title="إضافة موظف للقرار" width="500px">
      <el-form :model="empForm" ref="empRef" label-position="top">
        <el-form-item label="الموظف" prop="emp_id" :rules="[{ required: true }]">
          <el-select
            v-model="empForm.emp_id"
            filterable remote :remote-method="searchEmployees"
            placeholder="ابحث..." style="width:100%"
            @change="onEmpSelect"
          >
            <el-option
              v-for="e in empOptions"
              :key="e.emp_id"
              :label="`${e.emp_name} (${e.file_number||'—'})`"
              :value="e.emp_id"
            />
          </el-select>
        </el-form-item>
        <el-row :gutter="12">
          <el-col :span="12">
            <el-form-item label="المبلغ الأساسي">
              <el-input-number v-model="empForm.aw_mony" :min="0" :precision="2" style="width:100%" @change="calcEmpTotal" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="نسبة الضريبة %">
              <el-input-number v-model="empForm.tax_percent_applied" :min="0" :max="100" :precision="2" style="width:100%" @change="calcEmpTotal" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="12">
          <el-col :span="12">
            <el-form-item label="الإجمالي">
              <el-input :value="empForm.total_amount" readonly>
                <template #suffix><el-tag type="success">{{ Number(empForm.total_amount).toLocaleString('ar') }}</el-tag></template>
              </el-input>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="تاريخ الصرف">
              <el-date-picker v-model="empForm.award_date" format="YYYY/MM/DD" value-format="YYYY-MM-DD" style="width:100%" />
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <template #footer>
        <el-button @click="showAddEmp = false">إلغاء</el-button>
        <el-button type="primary" :loading="savingEmp" @click="saveEmp">حفظ</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import { awardApi, employeeApi } from '@/api'
import { ElMessage } from 'element-plus'
import { ArrowRight, Edit, Plus, Delete, Download } from '@element-plus/icons-vue'
import dayjs from 'dayjs'

const route = useRoute()
const auth = useAuthStore()

const award = ref(null)
const awemps = ref([])
const loading = ref(false)
const showAddEmp = ref(false)
const savingEmp = ref(false)
const empOptions = ref([])
const empRef = ref()
const editingAwemp = ref(null)

const empForm = reactive({
  emp_id: null, aw_mony: 0, tax_percent_applied: 0,
  total_amount: 0, award_date: dayjs().format('YYYY-MM-DD')
})

const totalAmount = computed(() => awemps.value.reduce((s, r) => s + Number(r.total_amount || 0), 0))
const totalBase = computed(() => awemps.value.reduce((s, r) => s + Number(r.aw_mony || 0), 0))

function formatDate(d) { return d ? dayjs(d).format('YYYY/MM/DD') : '—' }
function calcEmpTotal() {
  const m = Number(empForm.aw_mony) || 0
  const t = Number(empForm.tax_percent_applied) || 0
  empForm.total_amount = +(m + m * t / 100).toFixed(2)
}

async function load() {
  loading.value = true
  try {
    const [aRes, eRes] = await Promise.all([
      awardApi.get(route.params.id),
      awardApi.getEmployees(route.params.id)
    ])
    award.value = aRes.data
    awemps.value = eRes.data
  } finally {
    loading.value = false
  }
}

async function searchEmployees(q) {
  if (!q) return
  const { data } = await employeeApi.list({ search: q, page_size: 20 })
  empOptions.value = data.items
}

async function onEmpSelect(empId) {
  const { data } = await employeeApi.degreeDefaults(empId)
  empForm.aw_mony = data.def_mony
  empForm.tax_percent_applied = data.tax_percent
  calcEmpTotal()
}

function openEditEmp(row) {
  editingAwemp.value = row
  Object.assign(empForm, {
    emp_id: row.emp_id,
    aw_mony: Number(row.aw_mony || 0),
    tax_percent_applied: Number(row.tax_percent_applied || 0),
    total_amount: Number(row.total_amount || 0),
    award_date: row.award_date
  })
  empOptions.value = row.employee ? [row.employee] : []
  showAddEmp.value = true
}

async function saveEmp() {
  const valid = await empRef.value?.validate().catch(() => false)
  if (!valid) return
  savingEmp.value = true
  try {
    if (editingAwemp.value) {
      await awardApi.updateAwemp(editingAwemp.value.awemp_id, empForm)
    } else {
      await awardApi.addEmployee(route.params.id, empForm)
    }
    ElMessage.success('تم الحفظ')
    showAddEmp.value = false
    editingAwemp.value = null
    await load()
  } catch (e) {
    ElMessage.error(e.response?.data?.detail || 'حدث خطأ')
  } finally {
    savingEmp.value = false
  }
}

async function deleteAwemp(row) {
  await awardApi.deleteAwemp(row.awemp_id)
  ElMessage.success('تم الحذف')
  awemps.value = awemps.value.filter(r => r.awemp_id !== row.awemp_id)
}

async function exportWord() {
  try {
    const { data } = await awardApi.exportWord(route.params.id)
    const url = URL.createObjectURL(data)
    const a = document.createElement('a')
    a.href = url
    a.download = `award_${route.params.id}.docx`
    a.click()
    URL.revokeObjectURL(url)
  } catch {
    ElMessage.error('فشل التصدير')
  }
}

onMounted(load)
</script>

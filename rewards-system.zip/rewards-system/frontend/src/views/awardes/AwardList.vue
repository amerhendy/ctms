<template>
  <div>
    <div class="page-header">
      <h1><el-icon><Medal /></el-icon> قرارات المكافآت</h1>
    </div>

    <DataTable
      :data="awards"
      :total="total"
      :loading="loading"
      row-key="award_id"
      search-placeholder="بحث بعنوان القرار أو السبب..."
      add-label="قرار جديد"
      :can-add="auth.can('add_awardes')"
      :can-edit="auth.can('change_awardes')"
      :can-delete="auth.can('delete_awardes')"
      :can-view="true"
      :show-export-word="auth.can('view_awardes')"
      @add="openForm()"
      @edit="openForm($event)"
      @delete="doDelete($event)"
      @view="$router.push(`/awards/${$event.award_id}`)"
      @bulk-delete="doBulkDelete($event)"
      @search="q => { params.search = q; params.page = 1; load() }"
      @page-change="p => { params.page = p.page; params.page_size = p.pageSize; load() }"
      @sort-change="s => { params.sort_by = s.sortBy; params.sort_dir = s.sortDir; load() }"
      @export-word="exportSelectedWord"
    >
      <template #filters>
        <el-select v-model="params.year" placeholder="السنة" clearable style="width:100px" @change="load">
          <el-option v-for="y in years" :key="y" :label="y" :value="y" />
        </el-select>
        <el-select v-model="params.month" placeholder="الشهر" clearable style="width:110px" @change="load">
          <el-option v-for="m in months" :key="m.v" :label="m.l" :value="m.v" />
        </el-select>
        <el-date-picker
          v-model="dateRange"
          type="daterange"
          range-separator="إلى"
          start-placeholder="من"
          end-placeholder="إلى"
          value-format="YYYY-MM-DD"
          style="width:240px"
          @change="onDateRange"
        />
      </template>

      <el-table-column prop="award_id" label="#" width="70" sortable="custom" />
      <el-table-column prop="award_title" label="عنوان القرار" sortable="custom" />
      <el-table-column prop="award_reson" label="السبب" show-overflow-tooltip />
      <el-table-column prop="award_date" label="التاريخ" width="130" sortable="custom">
        <template #default="{ row }">{{ formatDate(row.award_date) }}</template>
      </el-table-column>
    </DataTable>

    <!-- Award Form Dialog -->
    <el-dialog
      v-model="showForm"
      :title="editRow ? 'تعديل قرار مكافأة' : 'قرار مكافأة جديد'"
      width="760px"
      top="40px"
    >
      <el-form :model="form" :rules="rules" ref="formRef" label-position="top">
        <el-row :gutter="16">
          <el-col :span="16">
            <el-form-item label="عنوان القرار" prop="award_title">
              <el-input v-model="form.award_title" />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="تاريخ القرار">
              <el-date-picker
                v-model="form.award_date"
                format="YYYY/MM/DD"
                value-format="YYYY-MM-DD HH:mm:ss"
                style="width:100%"
              />
            </el-form-item>
          </el-col>
        </el-row>
        <el-form-item label="سبب المكافأة">
          <el-input v-model="form.award_reson" type="textarea" :rows="2" />
        </el-form-item>

        <!-- Employees inline formset -->
        <el-divider>الموظفون المستفيدون</el-divider>
        <div class="emp-formset">
          <el-table :data="empRows" :show-header="empRows.length > 0" style="width:100%">
            <el-table-column label="الموظف" min-width="180">
              <template #default="{ row, $index }">
                <el-select
                  v-model="row.emp_id"
                  filterable
                  remote
                  :remote-method="(q) => searchEmp(q, $index)"
                  placeholder="بحث..."
                  style="width:100%"
                  size="small"
                  @change="(val) => onEmpChange(val, $index)"
                >
                  <el-option
                    v-for="e in row._options || []"
                    :key="e.emp_id"
                    :label="`${e.emp_name} (${e.file_number || '—'})`"
                    :value="e.emp_id"
                  />
                </el-select>
              </template>
            </el-table-column>
            <el-table-column label="المبلغ" width="120">
              <template #default="{ row, $index }">
                <el-input-number
                  v-model="row.aw_mony"
                  :min="0"
                  :precision="2"
                  size="small"
                  style="width:100%"
                  @change="() => calcRowTotal($index)"
                />
              </template>
            </el-table-column>
            <el-table-column label="ضريبة%" width="90">
              <template #default="{ row, $index }">
                <el-input-number
                  v-model="row.tax_percent_applied"
                  :min="0" :max="100" :precision="2"
                  size="small"
                  style="width:100%"
                  @change="() => calcRowTotal($index)"
                />
              </template>
            </el-table-column>
            <el-table-column label="الإجمالي" width="110">
              <template #default="{ row }">
                <strong style="color:#059669">{{ Number(row.total_amount||0).toLocaleString('ar') }}</strong>
              </template>
            </el-table-column>
            <el-table-column label="تاريخ الصرف" width="145">
              <template #default="{ row }">
                <el-date-picker
                  v-model="row.award_date"
                  format="YYYY/MM/DD"
                  value-format="YYYY-MM-DD"
                  size="small"
                  style="width:100%"
                />
              </template>
            </el-table-column>
            <el-table-column width="40">
              <template #default="{ $index }">
                <el-button text type="danger" :icon="Delete" size="small" @click="empRows.splice($index, 1)" />
              </template>
            </el-table-column>
          </el-table>
          <el-button text type="primary" :icon="Plus" @click="addEmpRow" style="margin-top:8px">
            إضافة موظف
          </el-button>
        </div>
      </el-form>

      <div v-if="empRows.length" class="total-summary">
        الإجمالي الكلي:
        <strong style="color:#059669; font-size:1.1rem">
          {{ empRows.reduce((s, r) => s + Number(r.total_amount||0), 0).toLocaleString('ar') }}
        </strong>
      </div>

      <template #footer>
        <el-button @click="showForm = false">إلغاء</el-button>
        <el-button type="primary" :loading="saving" @click="save">حفظ القرار</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { useAuthStore } from '@/stores/auth'
import { awardApi, employeeApi } from '@/api'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Delete, Plus } from '@element-plus/icons-vue'
import DataTable from '@/components/common/DataTable.vue'
import dayjs from 'dayjs'

const auth = useAuthStore()
const awards = ref([])
const total = ref(0)
const loading = ref(false)
const saving = ref(false)
const showForm = ref(false)
const editRow = ref(null)
const formRef = ref()
const dateRange = ref(null)
const empRows = ref([])

const params = reactive({
  page: 1, page_size: 25, search: '',
  year: null, month: null,
  date_from: null, date_to: null,
  sort_by: 'award_id', sort_dir: 'desc'
})

const form = reactive({
  award_title: '', award_reson: '', award_date: dayjs().format('YYYY-MM-DD HH:mm:ss')
})
const rules = { award_title: [{ required: true, message: 'العنوان مطلوب' }] }

const years = Array.from({ length: 10 }, (_, i) => new Date().getFullYear() - i)
const months = [
  { v: 1, l: 'يناير' }, { v: 2, l: 'فبراير' }, { v: 3, l: 'مارس' },
  { v: 4, l: 'أبريل' }, { v: 5, l: 'مايو' }, { v: 6, l: 'يونيو' },
  { v: 7, l: 'يوليو' }, { v: 8, l: 'أغسطس' }, { v: 9, l: 'سبتمبر' },
  { v: 10, l: 'أكتوبر' }, { v: 11, l: 'نوفمبر' }, { v: 12, l: 'ديسمبر' }
]

function formatDate(d) {
  return d ? dayjs(d).format('YYYY/MM/DD') : '—'
}

async function load() {
  loading.value = true
  try {
    const { data } = await awardApi.list(params)
    awards.value = data.items
    total.value = data.total
  } finally {
    loading.value = false
  }
}

function onDateRange(val) {
  params.date_from = val?.[0] || null
  params.date_to = val?.[1] || null
  params.year = null
  params.month = null
  load()
}

function openForm(row = null) {
  editRow.value = row
  Object.assign(form, {
    award_title: row?.award_title || '',
    award_reson: row?.award_reson || '',
    award_date: row?.award_date || dayjs().format('YYYY-MM-DD HH:mm:ss')
  })
  empRows.value = []
  showForm.value = true
  formRef.value?.clearValidate()

  // Load existing employees if editing
  if (row) loadAwardEmployees(row.award_id)
}

async function loadAwardEmployees(awardId) {
  const { data } = await awardApi.getEmployees(awardId)
  empRows.value = data.map(r => ({
    _awemp_id: r.awemp_id,
    emp_id: r.emp_id,
    aw_mony: Number(r.aw_mony || 0),
    tax_percent_applied: Number(r.tax_percent_applied || 0),
    total_amount: Number(r.total_amount || 0),
    award_date: r.award_date,
    _options: r.employee ? [r.employee] : []
  }))
}

function addEmpRow() {
  empRows.value.push({
    emp_id: null,
    aw_mony: 0,
    tax_percent_applied: 0,
    total_amount: 0,
    award_date: dayjs().format('YYYY-MM-DD'),
    _options: []
  })
}

function calcRowTotal(idx) {
  const row = empRows.value[idx]
  const m = Number(row.aw_mony) || 0
  const t = Number(row.tax_percent_applied) || 0
  row.total_amount = +(m + m * t / 100).toFixed(2)
}

async function searchEmp(query, idx) {
  if (!query) return
  const { data } = await employeeApi.list({ search: query, page_size: 20 })
  empRows.value[idx]._options = data.items
}

async function onEmpChange(empId, idx) {
  if (!empId) return
  const { data } = await employeeApi.degreeDefaults(empId)
  const row = empRows.value[idx]
  row.aw_mony = data.def_mony
  row.tax_percent_applied = data.tax_percent
  calcRowTotal(idx)
}

async function save() {
  const valid = await formRef.value?.validate().catch(() => false)
  if (!valid) return
  saving.value = true
  try {
    let awardId
    if (editRow.value) {
      await awardApi.update(editRow.value.award_id, form)
      awardId = editRow.value.award_id
    } else {
      const { data } = await awardApi.create(form)
      awardId = data.award_id
    }

    // Save employee rows
    for (const row of empRows.value) {
      if (!row.emp_id) continue
      const payload = {
        emp_id: row.emp_id,
        aw_mony: row.aw_mony,
        tax_percent_applied: row.tax_percent_applied,
        total_amount: row.total_amount,
        award_date: row.award_date
      }
      if (row._awemp_id) {
        await awardApi.updateAwemp(row._awemp_id, payload)
      } else {
        await awardApi.addEmployee(awardId, payload)
      }
    }

    ElMessage.success('تم الحفظ')
    showForm.value = false
    load()
  } catch (e) {
    ElMessage.error(e.response?.data?.detail || 'حدث خطأ')
  } finally {
    saving.value = false
  }
}

async function doDelete(row) {
  await awardApi.delete(row.award_id)
  ElMessage.success('تم الحذف')
  load()
}

async function doBulkDelete(rows) {
  await ElMessageBox.confirm(`حذف ${rows.length} قرار؟`, 'تأكيد', {
    confirmButtonText: 'حذف', cancelButtonText: 'إلغاء', type: 'warning'
  })
  await awardApi.bulkDelete(rows.map(r => r.award_id))
  ElMessage.success('تم الحذف')
  load()
}

async function exportSelectedWord() {
  ElMessage.info('الرجاء الدخول لتفاصيل القرار لتصديره')
}

onMounted(load)
</script>

<style scoped>
.emp-formset { background: #f8fafc; border-radius: 8px; padding: 12px; }
.total-summary {
  margin-top: 12px;
  padding: 10px 16px;
  background: #ecfdf5;
  border-radius: 8px;
  display: flex;
  align-items: center;
  gap: 12px;
  font-weight: 600;
}
</style>

<template>
  <div>
    <div class="page-header">
      <h1><el-icon><Star /></el-icon> درجات المكافأة</h1>
    </div>
    <DataTable
      :data="degrees" :total="total" :loading="loading"
      row-key="deg_id" search-placeholder="بحث..."
      add-label="إضافة درجة"
      :can-add="auth.can('add_awdeg')"
      :can-edit="auth.can('change_awdeg')"
      :can-delete="auth.can('delete_awdeg')"
      @add="openForm()" @edit="openForm($event)" @delete="doDelete($event)"
      @bulk-delete="doBulkDelete($event)"
      @search="q => { params.search = q; load() }"
      @page-change="p => { params.page = p.page; params.page_size = p.pageSize; load() }"
    >
      <el-table-column prop="deg_id" label="#" width="70" />
      <el-table-column prop="deg_name" label="اسم الدرجة" />
      <el-table-column prop="def_mony" label="المبلغ الأساسي" width="130" align="left">
        <template #default="{ row }">{{ Number(row.def_mony || 0).toLocaleString('ar') }}</template>
      </el-table-column>
      <el-table-column prop="tax_percent" label="الضريبة %" width="100" align="center" />
      <el-table-column label="الإجمالي" width="130" align="left">
        <template #default="{ row }">
          <strong style="color:#059669">
            {{ calcTotal(row).toLocaleString('ar') }}
          </strong>
        </template>
      </el-table-column>
    </DataTable>

    <el-dialog v-model="showForm" :title="editRow ? 'تعديل درجة' : 'إضافة درجة'" width="460px">
      <el-form :model="form" :rules="rules" ref="formRef" label-position="top">
        <el-form-item label="اسم الدرجة" prop="deg_name">
          <el-input v-model="form.deg_name" />
        </el-form-item>
        <el-row :gutter="16">
          <el-col :span="12">
            <el-form-item label="المبلغ الأساسي">
              <el-input-number v-model="form.def_mony" :min="0" :precision="2" style="width:100%" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="نسبة الضريبة %">
              <el-input-number v-model="form.tax_percent" :min="0" :max="100" :precision="2" style="width:100%" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-alert
          v-if="form.def_mony"
          :title="`الإجمالي بعد الضريبة: ${calcFormTotal().toLocaleString('ar')}`"
          type="success" :closable="false" style="margin-top: 8px"
        />
      </el-form>
      <template #footer>
        <el-button @click="showForm = false">إلغاء</el-button>
        <el-button type="primary" :loading="saving" @click="save">حفظ</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { useAuthStore } from '@/stores/auth'
import { degreeApi } from '@/api'
import { ElMessage, ElMessageBox } from 'element-plus'
import DataTable from '@/components/common/DataTable.vue'

const auth = useAuthStore()
const degrees = ref([])
const total = ref(0)
const loading = ref(false)
const saving = ref(false)
const showForm = ref(false)
const editRow = ref(null)
const formRef = ref()
const params = reactive({ page: 1, page_size: 25, search: '' })
const form = reactive({ deg_name: '', def_mony: 0, tax_percent: 0 })
const rules = { deg_name: [{ required: true, message: 'الحقل مطلوب' }] }

const calcTotal = (row) => {
  const m = Number(row.def_mony || 0)
  const t = Number(row.tax_percent || 0)
  return +(m + m * t / 100).toFixed(2)
}
const calcFormTotal = () => calcTotal(form)

async function load() {
  loading.value = true
  try {
    const { data } = await degreeApi.list(params)
    degrees.value = data.items; total.value = data.total
  } finally { loading.value = false }
}

function openForm(row = null) {
  editRow.value = row
  Object.assign(form, {
    deg_name: row?.deg_name || '',
    def_mony: Number(row?.def_mony || 0),
    tax_percent: Number(row?.tax_percent || 0)
  })
  showForm.value = true
  formRef.value?.clearValidate()
}

async function save() {
  const valid = await formRef.value?.validate().catch(() => false)
  if (!valid) return
  saving.value = true
  try {
    if (editRow.value) { await degreeApi.update(editRow.value.deg_id, form) }
    else { await degreeApi.create(form) }
    ElMessage.success('تم الحفظ')
    showForm.value = false; load()
  } finally { saving.value = false }
}

async function doDelete(row) {
  await degreeApi.delete(row.deg_id)
  ElMessage.success('تم الحذف'); load()
}

async function doBulkDelete(rows) {
  await ElMessageBox.confirm(`حذف ${rows.length} درجة؟`, 'تأكيد', { type: 'warning', confirmButtonText: 'حذف', cancelButtonText: 'إلغاء' })
  await degreeApi.bulkDelete(rows.map(r => r.deg_id))
  ElMessage.success('تم الحذف'); load()
}

onMounted(load)
</script>

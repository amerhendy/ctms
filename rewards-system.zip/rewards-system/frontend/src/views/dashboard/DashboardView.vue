<template>
  <div>
    <div class="page-header">
      <h1><el-icon><DataAnalysis /></el-icon> لوحة التحكم</h1>
      <el-tag type="info">{{ today }}</el-tag>
    </div>

    <!-- Stats -->
    <div class="stats-grid">
      <div class="stat-card" v-for="s in stats" :key="s.label">
        <div class="stat-icon" :style="{ background: s.bg }">
          <el-icon :size="22" :color="s.color"><component :is="s.icon" /></el-icon>
        </div>
        <div class="stat-info">
          <div class="value" :style="{ color: s.color }">{{ s.value }}</div>
          <div class="label">{{ s.label }}</div>
        </div>
      </div>
    </div>

    <!-- Charts row -->
    <el-row :gutter="20" style="margin-bottom: 20px">
      <el-col :span="14">
        <el-card shadow="never">
          <template #header><span style="font-weight:700">المكافآت الشهرية (آخر 6 أشهر)</span></template>
          <apexchart type="bar" height="260" :options="barOptions" :series="barSeries" v-if="barSeries[0]?.data?.length" />
          <el-skeleton :rows="5" animated v-else />
        </el-card>
      </el-col>
      <el-col :span="10">
        <el-card shadow="never">
          <template #header><span style="font-weight:700">توزيع الموظفين على المناطق</span></template>
          <apexchart type="donut" height="260" :options="pieOptions" :series="pieSeries" v-if="pieSeries.length" />
          <el-skeleton :rows="5" animated v-else />
        </el-card>
      </el-col>
    </el-row>

    <!-- Recent awards -->
    <el-card shadow="never">
      <template #header>
        <div style="display:flex; justify-content:space-between; align-items:center">
          <span style="font-weight:700">آخر قرارات المكافآت</span>
          <el-button text type="primary" @click="$router.push('/awards')">عرض الكل</el-button>
        </div>
      </template>
      <el-table :data="recentAwards" stripe>
        <el-table-column prop="award_id" label="#" width="60" />
        <el-table-column prop="award_title" label="عنوان القرار" />
        <el-table-column prop="award_date" label="تاريخ القرار" width="140">
          <template #default="{ row }">{{ formatDate(row.award_date) }}</template>
        </el-table-column>
        <el-table-column label="الموظفون" width="90">
          <template #default="{ row }">
            <el-tag>{{ row._emp_count || '—' }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="" width="80">
          <template #default="{ row }">
            <el-button text type="primary" size="small" @click="$router.push(`/awards/${row.award_id}`)">تفاصيل</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue'
import { awardApi, employeeApi, areaApi } from '@/api'
import VueApexCharts from 'vue3-apexcharts'
import dayjs from 'dayjs'

const apexchart = VueApexCharts

const today = dayjs().format('dddd، D MMMM YYYY')
const stats = ref([
  { label: 'إجمالي الموظفين', value: '—', icon: 'User', color: '#2563eb', bg: '#eff6ff' },
  { label: 'قرارات المكافآت', value: '—', icon: 'Medal', color: '#7c3aed', bg: '#f5f3ff' },
  { label: 'إجمالي المكافآت', value: '—', icon: 'Money', color: '#059669', bg: '#ecfdf5' },
  { label: 'المناطق', value: '—', icon: 'Location', color: '#d97706', bg: '#fffbeb' }
])

const recentAwards = ref([])
const barSeries = ref([{ name: 'المكافآت', data: [] }])
const pieSeries = ref([])
const pieOptions = ref({ labels: [], legend: { position: 'bottom' }, chart: { fontFamily: 'Cairo' } })
const barOptions = ref({
  chart: { fontFamily: 'Cairo', toolbar: { show: false } },
  plotOptions: { bar: { borderRadius: 6 } },
  xaxis: { categories: [] },
  colors: ['#2563eb'],
  dataLabels: { enabled: false }
})

function formatDate(d) {
  return d ? dayjs(d).format('YYYY/MM/DD') : '—'
}

async function loadStats() {
  try {
    const [emps, awards, areas] = await Promise.all([
      employeeApi.list({ page_size: 1 }),
      awardApi.list({ page_size: 10, sort_dir: 'desc' }),
      areaApi.list({ page_size: 100 })
    ])
    stats.value[0].value = emps.data.total.toLocaleString('ar')
    stats.value[1].value = awards.data.total.toLocaleString('ar')
    stats.value[3].value = areas.data.total.toLocaleString('ar')
    recentAwards.value = awards.data.items.slice(0, 8)

    // Pie chart: employees per area
    const areaItems = areas.data.items.slice(0, 6)
    pieOptions.value = {
      ...pieOptions.value,
      labels: areaItems.map(a => a.area_name)
    }
    pieSeries.value = areaItems.map(a => a.employees?.length || 0)

    // Bar chart: monthly rewards (last 6 months)
    const months = []
    const monthData = []
    for (let i = 5; i >= 0; i--) {
      const d = dayjs().subtract(i, 'month')
      months.push(d.format('MMM YY'))
      const r = await awardApi.list({ year: d.year(), month: d.month() + 1, page_size: 1 })
      monthData.push(r.data.total)
    }
    barOptions.value = { ...barOptions.value, xaxis: { categories: months } }
    barSeries.value = [{ name: 'عدد القرارات', data: monthData }]
  } catch (e) {
    console.error(e)
  }
}

onMounted(loadStats)
</script>

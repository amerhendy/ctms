<template>
  <div>
    <div class="page-header">
      <h1><el-icon><Briefcase /></el-icon> الوظائف</h1>
    </div>
    <DataTable
      :data="jobs" :total="total" :loading="loading"
      row-key="job_id" search-placeholder="بحث..."
      add-label="إضافة وظيفة"
      :can-add="auth.can('add_empjob')"
      :can-edit="auth.can('change_empjob')"
      :can-delete="auth.can('delete_empjob')"
      @add="openForm()" @edit="openForm($event)" @delete="doDelete($event)"
      @bulk-delete="doBulkDelete($event)"
      @search="q => { params.search = q; load() }"
      @page-change="p => { params.page = p.page; params.page_size = p.pageSize; load() }"
    >
      <el-table-column prop="job_id" label="#" width="70" />
      <el-table-column prop="job_name" label="اسم الوظيفة" />
      <el-table-column label="عدد الموظفين" width="130">
        <template #default="{ row }">
          <el-tag>{{ row.employees?.length ?? 0 }}</el-tag>
        </template>
      </el-table-column>
    </DataTable>

    <el-dialog v-model="showForm" :title="editRow ? 'تعديل وظيفة' : 'إضافة وظيفة'" width="400px">
      <el-form :model="form" :rules="rules" ref="formRef" label-position="top">
        <el-form-item label="اسم الوظيفة" prop="job_name">
          <el-input v-model="form.job_name" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showForm = false">إلغاء</el-button>
        <el-button type="primary" :loading="saving" @click="save">حفظ</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { useAuthStore } from '@/stores/auth'
import { jobApi } from '@/api'
import { ElMessage, ElMessageBox } from 'element-plus'
import DataTable from '@/components/common/DataTable.vue'

const auth = useAuthStore()
const jobs = ref([])
const total = ref(0)
const loading = ref(false)
const saving = ref(false)
const showForm = ref(false)
const editRow = ref(null)
const formRef = ref()
const params = reactive({ page: 1, page_size: 25, search: '' })
const form = reactive({ job_name: '' })
const rules = { job_name: [{ required: true, message: 'الحقل مطلوب' }] }

async function load() {
  loading.value = true
  try {
    const { data } = await jobApi.list(params)
    jobs.value = data.items; total.value = data.total
  } finally { loading.value = false }
}

function openForm(row = null) {
  editRow.value = row
  form.job_name = row?.job_name || ''
  showForm.value = true
  formRef.value?.clearValidate()
}

async function save() {
  const valid = await formRef.value?.validate().catch(() => false)
  if (!valid) return
  saving.value = true
  try {
    if (editRow.value) { await jobApi.update(editRow.value.job_id, form) }
    else { await jobApi.create(form) }
    ElMessage.success('تم الحفظ')
    showForm.value = false; load()
  } finally { saving.value = false }
}

async function doDelete(row) {
  await jobApi.delete(row.job_id)
  ElMessage.success('تم الحذف'); load()
}

async function doBulkDelete(rows) {
  await ElMessageBox.confirm(`حذف ${rows.length} وظيفة؟`, 'تأكيد', { type: 'warning', confirmButtonText: 'حذف', cancelButtonText: 'إلغاء' })
  await jobApi.bulkDelete(rows.map(r => r.job_id))
  ElMessage.success('تم الحذف'); load()
}

onMounted(load)
</script>

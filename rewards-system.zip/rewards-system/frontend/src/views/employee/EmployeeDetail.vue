<template>
  <div v-loading="loading">
    <div class="page-header">
      <h1>
        <el-button text :icon="ArrowRight" @click="$router.back()" />
        <el-icon><User /></el-icon>
        {{ emp?.emp_name }}
      </h1>
      <el-button v-if="auth.can('change_employee')" type="primary" :icon="Edit" @click="showEdit = true">تعديل</el-button>
    </div>

    <!-- Info cards -->
    <el-row :gutter="16" style="margin-bottom: 20px">
      <el-col :span="6">
        <el-card shadow="never" class="info-card">
          <div class="info-label">رقم الملف</div>
          <div class="info-value">{{ emp?.file_number || '—' }}</div>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card shadow="never" class="info-card">
          <div class="info-label">المنطقة</div>
          <div class="info-value">{{ emp?.area?.area_name || '—' }}</div>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card shadow="never" class="info-card">
          <div class="info-label">الوظيفة</div>
          <div class="info-value">{{ emp?.job?.job_name || '—' }}</div>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card shadow="never" class="info-card" style="background:#ecfdf5">
          <div class="info-label">إجمالي المكافآت</div>
          <div class="info-value" style="color:#059669; font-size:1.4rem">
            {{ Number(totalRewards).toLocaleString('ar') }}
          </div>
        </el-card>
      </el-col>
    </el-row>

    <!-- Date filter for total -->
    <div class="filter-bar" style="margin-bottom: 16px">
      <el-date-picker
        v-model="dateRange"
        type="daterange"
        range-separator="إلى"
        start-placeholder="من تاريخ"
        end-placeholder="إلى تاريخ"
        format="YYYY/MM/DD"
        value-format="YYYY-MM-DD"
        @change="loadEmp"
      />
      <el-button :icon="Refresh" @click="dateRange = null; loadEmp()">إعادة ضبط</el-button>
    </div>

    <!-- Rewards table -->
    <el-card shadow="never">
      <template #header>
        <div style="display:flex; justify-content:space-between; align-items:center">
          <span style="font-weight:700">سجل المكافآت</span>
          <el-button
            v-if="auth.can('add_awemp')"
            type="primary"
            size="small"
            :icon="Plus"
            @click="showAddReward = true"
          >إضافة مكافأة</el-button>
        </div>
      </template>

      <el-table :data="emp?.awemp_records?.filter(r => !r.deleted_at)" stripe>
        <el-table-column prop="award_date" label="تاريخ الصرف" width="130">
          <template #default="{ row }">{{ row.award_date || '—' }}</template>
        </el-table-column>
        <el-table-column label="قرار المكافأة">
          <template #default="{ row }">{{ row.award?.award_title || '—' }}</template>
        </el-table-column>
        <el-table-column prop="aw_mony" label="المبلغ الأساسي" width="130" align="left">
          <template #default="{ row }">{{ Number(row.aw_mony || 0).toLocaleString('ar') }}</template>
        </el-table-column>
        <el-table-column prop="tax_percent_applied" label="الضريبة %" width="90" />
        <el-table-column label="الإجمالي" width="130" align="left">
          <template #default="{ row }">
            <strong style="color:#059669">{{ Number(row.total_amount || 0).toLocaleString('ar') }}</strong>
          </template>
        </el-table-column>
        <el-table-column label="إجراءات" width="80">
          <template #default="{ row }">
            <el-popconfirm title="حذف هذا السجل؟" @confirm="deleteAwemp(row)">
              <template #reference>
                <el-button text type="danger" size="small" :icon="Delete" v-if="auth.can('delete_awemp')" />
              </template>
            </el-popconfirm>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- Add reward dialog -->
    <el-dialog v-model="showAddReward" title="إضافة مكافأة جديدة" width="520px">
      <el-form :model="rewardForm" ref="rewardRef" label-position="top">
        <el-form-item label="اختر قرار مكافأة" prop="award_id" :rules="[{ required: true }]">
          <el-select
            v-model="rewardForm.award_id"
            filterable
            remote
            :remote-method="searchAwards"
            placeholder="ابحث باسم القرار"
            style="width: 100%"
          >
            <el-option
              v-for="a in awardOptions"
              :key="a.award_id"
              :label="a.award_title"
              :value="a.award_id"
            />
          </el-select>
        </el-form-item>
        <el-row :gutter="16">
          <el-col :span="12">
            <el-form-item label="المبلغ الأساسي">
              <el-input-number
                v-model="rewardForm.aw_mony"
                :min="0"
                :precision="2"
                style="width:100%"
                @change="calcTotal"
              />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="نسبة الضريبة %">
              <el-input-number
                v-model="rewardForm.tax_percent_applied"
                :min="0"
                :max="100"
                :precision="2"
                style="width:100%"
                @change="calcTotal"
              />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="16">
          <el-col :span="12">
            <el-form-item label="الإجمالي">
              <el-input :value="rewardForm.total_amount" readonly>
                <template #suffix>
                  <el-tag type="success">{{ Number(rewardForm.total_amount).toLocaleString('ar') }}</el-tag>
                </template>
              </el-input>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="تاريخ الصرف">
              <el-date-picker
                v-model="rewardForm.award_date"
                format="YYYY/MM/DD"
                value-format="YYYY-MM-DD"
                style="width:100%"
              />
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <template #footer>
        <el-button @click="showAddReward = false">إلغاء</el-button>
        <el-button type="primary" :loading="savingReward" @click="saveReward">حفظ</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import { employeeApi, awardApi } from '@/api'
import { ElMessage } from 'element-plus'
import { ArrowRight, Edit, Plus, Delete, Refresh } from '@element-plus/icons-vue'
import dayjs from 'dayjs'

const route = useRoute()
const auth = useAuthStore()

const emp = ref(null)
const loading = ref(false)
const showEdit = ref(false)
const showAddReward = ref(false)
const savingReward = ref(false)
const dateRange = ref(null)
const totalRewards = ref(0)
const awardOptions = ref([])
const rewardRef = ref()

const rewardForm = reactive({
  award_id: null,
  aw_mony: 0,
  tax_percent_applied: 0,
  total_amount: 0,
  award_date: dayjs().format('YYYY-MM-DD')
})

function calcTotal() {
  const m = Number(rewardForm.aw_mony) || 0
  const t = Number(rewardForm.tax_percent_applied) || 0
  rewardForm.total_amount = +(m + (m * t / 100)).toFixed(2)
}

async function loadEmp() {
  loading.value = true
  try {
    const params = {}
    if (dateRange.value) {
      params.date_from = dateRange.value[0]
      params.date_to = dateRange.value[1]
    }
    const { data } = await employeeApi.get(route.params.id, params)
    emp.value = data
    totalRewards.value = data.total_rewards || 0

    // Load degree defaults
    if (data.deg_id) {
      const { data: def } = await employeeApi.degreeDefaults(route.params.id)
      rewardForm.aw_mony = def.def_mony
      rewardForm.tax_percent_applied = def.tax_percent
      calcTotal()
    }
  } finally {
    loading.value = false
  }
}

async function searchAwards(q) {
  if (!q) return
  const { data } = await awardApi.list({ search: q, page_size: 20 })
  awardOptions.value = data.items
}

async function saveReward() {
  const valid = await rewardRef.value?.validate().catch(() => false)
  if (!valid) return
  savingReward.value = true
  try {
    await employeeApi.addReward(emp.value.emp_id, rewardForm)
    ElMessage.success('تمت إضافة المكافأة')
    showAddReward.value = false
    await loadEmp()
  } catch (e) {
    ElMessage.error(e.response?.data?.detail || 'حدث خطأ')
  } finally {
    savingReward.value = false
  }
}

async function deleteAwemp(row) {
  await awardApi.deleteAwemp(row.awemp_id)
  ElMessage.success('تم الحذف')
  await loadEmp()
}

onMounted(loadEmp)
</script>

<style scoped>
.info-card { text-align: center; padding: 4px; }
.info-label { font-size: .8rem; color: var(--text-muted); margin-bottom: 4px; }
.info-value { font-size: 1.1rem; font-weight: 700; }
</style>

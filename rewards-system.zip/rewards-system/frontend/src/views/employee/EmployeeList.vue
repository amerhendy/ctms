<template>
  <div>
    <div class="page-header">
      <h1><el-icon><User /></el-icon> الموظفون</h1>
    </div>

    <DataTable
      :data="employees"
      :total="total"
      :loading="loading"
      row-key="emp_id"
      search-placeholder="بحث بالاسم أو رقم الملف..."
      add-label="إضافة موظف"
      :can-add="auth.can('add_employee')"
      :can-edit="auth.can('change_employee')"
      :can-delete="auth.can('delete_employee')"
      :can-view="true"
      :show-export-csv="auth.can('view_employee')"
      :show-export-excel="auth.can('view_employee')"
      @add="openForm()"
      @edit="openForm($event)"
      @delete="doDelete($event)"
      @view="$router.push(`/employees/${$event.emp_id}`)"
      @bulk-delete="doBulkDelete($event)"
      @search="q => { params.search = q; params.page = 1; load() }"
      @page-change="p => { params.page = p.page; params.page_size = p.pageSize; load() }"
      @sort-change="s => { params.sort_by = s.sortBy; load() }"
      @export-csv="exportCsv"
      @export-excel="exportExcel"
    >
      <template #filters>
        <el-select v-model="params.area_id" placeholder="كل المناطق" clearable style="width:160px" @change="load">
          <el-option v-for="a in areaOptions" :key="a.area_id" :label="a.area_name" :value="a.area_id" />
        </el-select>
        <el-select v-model="params.job_id" placeholder="كل الوظائف" clearable style="width:160px" @change="load">
          <el-option v-for="j in jobOptions" :key="j.job_id" :label="j.job_name" :value="j.job_id" />
        </el-select>
      </template>

      <el-table-column prop="emp_id" label="#" width="70" sortable="custom" />
      <el-table-column prop="file_number" label="رقم الملف" width="100" />
      <el-table-column prop="emp_name" label="الاسم" sortable="custom" />
      <el-table-column label="المنطقة">
        <template #default="{ row }">{{ row.area?.area_name || '—' }}</template>
      </el-table-column>
      <el-table-column label="الوظيفة">
        <template #default="{ row }">{{ row.job?.job_name || '—' }}</template>
      </el-table-column>
      <el-table-column label="الدرجة">
        <template #default="{ row }">
          <el-tag size="small" type="info" v-if="row.degree">{{ row.degree.deg_name }}</el-tag>
          <span v-else>—</span>
        </template>
      </el-table-column>
    </DataTable>

    <!-- Employee Form Dialog -->
    <el-dialog v-model="showForm" :title="editRow ? 'تعديل موظف' : 'إضافة موظف'" width="520px">
      <el-form :model="form" :rules="rules" ref="formRef" label-position="top">
        <el-row :gutter="16">
          <el-col :span="12">
            <el-form-item label="الاسم الكامل" prop="emp_name">
              <el-input v-model="form.emp_name" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="رقم الملف" prop="file_number">
              <el-input v-model="form.file_number" maxlength="6" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="16">
          <el-col :span="12">
            <el-form-item label="المنطقة">
              <el-select v-model="form.area_id" clearable style="width:100%">
                <el-option v-for="a in areaOptions" :key="a.area_id" :label="a.area_name" :value="a.area_id" />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="الوظيفة">
              <el-select v-model="form.job_id" clearable style="width:100%">
                <el-option v-for="j in jobOptions" :key="j.job_id" :label="j.job_name" :value="j.job_id" />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-form-item label="درجة المكافأة">
          <el-select v-model="form.deg_id" clearable style="width:100%">
            <el-option v-for="d in degOptions" :key="d.deg_id" :label="d.deg_name" :value="d.deg_id" />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showForm = false">إلغاء</el-button>
        <el-button type="primary" :loading="saving" @click="save">حفظ</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { useAuthStore } from '@/stores/auth'
import { employeeApi, areaApi, jobApi, degreeApi } from '@/api'
import { ElMessage, ElMessageBox } from 'element-plus'
import DataTable from '@/components/common/DataTable.vue'

const auth = useAuthStore()
const employees = ref([])
const total = ref(0)
const loading = ref(false)
const saving = ref(false)
const showForm = ref(false)
const editRow = ref(null)
const formRef = ref()

const areaOptions = ref([])
const jobOptions = ref([])
const degOptions = ref([])

const params = reactive({
  page: 1, page_size: 25, search: '',
  area_id: null, job_id: null, sort_by: 'emp_id', sort_dir: 'asc'
})

const form = reactive({
  emp_name: '', file_number: '',
  area_id: null, job_id: null, deg_id: null
})

const rules = {
  emp_name: [{ required: true, message: 'اسم الموظف مطلوب' }]
}

async function load() {
  loading.value = true
  try {
    const { data } = await employeeApi.list(params)
    employees.value = data.items
    total.value = data.total
  } finally {
    loading.value = false
  }
}

async function loadOptions() {
  const [a, j, d] = await Promise.all([
    areaApi.list({ page_size: 200 }),
    jobApi.list({ page_size: 200 }),
    degreeApi.list({ page_size: 200 })
  ])
  areaOptions.value = a.data.items
  jobOptions.value = j.data.items
  degOptions.value = d.data.items
}

function openForm(row = null) {
  editRow.value = row
  Object.assign(form, {
    emp_name: row?.emp_name || '',
    file_number: row?.file_number || '',
    area_id: row?.area_id || null,
    job_id: row?.job_id || null,
    deg_id: row?.deg_id || null
  })
  showForm.value = true
  formRef.value?.clearValidate()
}

async function save() {
  const valid = await formRef.value?.validate().catch(() => false)
  if (!valid) return
  saving.value = true
  try {
    if (editRow.value) {
      await employeeApi.update(editRow.value.emp_id, form)
      ElMessage.success('تم التعديل')
    } else {
      await employeeApi.create(form)
      ElMessage.success('تمت الإضافة')
    }
    showForm.value = false
    load()
  } catch (e) {
    ElMessage.error(e.response?.data?.detail || 'حدث خطأ')
  } finally {
    saving.value = false
  }
}

async function doDelete(row) {
  await employeeApi.delete(row.emp_id)
  ElMessage.success('تم الحذف')
  load()
}

async function doBulkDelete(rows) {
  await ElMessageBox.confirm(`حذف ${rows.length} موظف؟`, 'تأكيد', {
    confirmButtonText: 'حذف', cancelButtonText: 'إلغاء', type: 'warning'
  })
  await employeeApi.bulkDelete(rows.map(r => r.emp_id))
  ElMessage.success('تم الحذف')
  load()
}

function downloadBlob(blob, name) {
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url; a.download = name; a.click()
  URL.revokeObjectURL(url)
}

async function exportCsv() {
  const { data } = await employeeApi.exportCsv(params)
  downloadBlob(data, 'employees.csv')
}
async function exportExcel() {
  const { data } = await employeeApi.exportExcel(params)
  downloadBlob(data, 'employees.xlsx')
}

onMounted(() => { load(); loadOptions() })
</script>

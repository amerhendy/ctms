<template>
  <div>
    <div class="page-header">
      <h1><el-icon><Document /></el-icon> سجل التغييرات</h1>
    </div>

    <div class="filter-bar">
      <el-select v-model="params.table_name" placeholder="الجدول" clearable style="width:140px" @change="load">
        <el-option v-for="t in tableOptions" :key="t" :label="t" :value="t" />
      </el-select>
      <el-select v-model="params.action_type" placeholder="نوع العملية" clearable style="width:140px" @change="load">
        <el-option label="إنشاء" value="create" />
        <el-option label="تعديل" value="update" />
        <el-option label="حذف" value="delete" />
        <el-option label="تصدير" value="export" />
        <el-option label="دخول" value="login" />
        <el-option label="خروج" value="logout" />
      </el-select>
      <el-date-picker
        v-model="dateRange"
        type="daterange"
        range-separator="إلى"
        start-placeholder="من"
        end-placeholder="إلى"
        value-format="YYYY-MM-DD"
        style="width:240px"
        @change="onDateChange"
      />
    </div>

    <el-card shadow="never">
      <el-table v-loading="loading" :data="logs" stripe>
        <el-table-column prop="id" label="#" width="70" />
        <el-table-column prop="created_at" label="التاريخ والوقت" width="170">
          <template #default="{ row }">{{ dayjs(row.created_at).format('YYYY/MM/DD HH:mm') }}</template>
        </el-table-column>
        <el-table-column prop="action_type" label="العملية" width="100">
          <template #default="{ row }">
            <el-tag :type="actionColor(row.action_type)" size="small">{{ actionLabel(row.action_type) }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="table_name" label="الجدول" width="110" />
        <el-table-column prop="record_id" label="المعرف" width="70" />
        <el-table-column prop="user_id" label="المستخدم" width="90" />
        <el-table-column prop="ip_address" label="IP" width="130" />
        <el-table-column label="البيانات" min-width="200">
          <template #default="{ row }">
            <el-button text size="small" @click="viewData(row)">عرض التفاصيل</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div class="table-footer">
        <span class="total-label">الإجمالي: {{ total }}</span>
        <el-pagination
          v-model:current-page="params.page"
          v-model:page-size="params.page_size"
          :page-sizes="[25, 50, 100]"
          layout="sizes, prev, pager, next"
          :total="total"
          @change="load"
        />
      </div>
    </el-card>

    <!-- Data detail dialog -->
    <el-dialog v-model="showData" title="تفاصيل السجل" width="640px">
      <el-descriptions :column="1" border>
        <el-descriptions-item label="البيانات القديمة (قبل)">
          <pre style="font-size:.8rem; max-height:200px; overflow:auto">{{ JSON.stringify(selectedLog?.old_data, null, 2) || 'لا يوجد' }}</pre>
        </el-descriptions-item>
        <el-descriptions-item label="البيانات الجديدة (بعد)">
          <pre style="font-size:.8rem; max-height:200px; overflow:auto">{{ JSON.stringify(selectedLog?.new_data, null, 2) || 'لا يوجد' }}</pre>
        </el-descriptions-item>
      </el-descriptions>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { logApi } from '@/api'
import dayjs from 'dayjs'

const logs = ref([])
const total = ref(0)
const loading = ref(false)
const showData = ref(false)
const selectedLog = ref(null)
const dateRange = ref(null)

const params = reactive({
  page: 1, page_size: 50,
  table_name: null, action_type: null,
  date_from: null, date_to: null
})

const tableOptions = ['area', 'empjob', 'awdeg', 'awardes', 'employee', 'awemp', 'users']

function actionLabel(t) {
  const m = { create: 'إنشاء', update: 'تعديل', delete: 'حذف', bulk_delete: 'حذف جماعي', export: 'تصدير', login: 'دخول', logout: 'خروج' }
  return m[t] || t
}
function actionColor(t) {
  const m = { create: 'success', update: 'warning', delete: 'danger', bulk_delete: 'danger', export: 'info', login: '', logout: '' }
  return m[t] || ''
}

function onDateChange(val) {
  params.date_from = val?.[0] || null
  params.date_to = val?.[1] || null
  load()
}

function viewData(row) {
  selectedLog.value = row
  showData.value = true
}

async function load() {
  loading.value = true
  try {
    const { data } = await logApi.list(params)
    logs.value = data.items; total.value = data.total
  } finally { loading.value = false }
}

onMounted(load)
</script>

<style scoped>
.table-footer { display: flex; align-items: center; justify-content: space-between; padding-top: 16px; flex-wrap: wrap; gap: 12px; }
.total-label { color: var(--text-muted); font-size: .88rem; }
</style>

<template>
  <div>
    <div class="page-header">
      <h1><el-icon><Setting /></el-icon> الإعدادات</h1>
    </div>

    <el-tabs type="border-card">
      <!-- Export templates -->
      <el-tab-pane label="قوالب التصدير" v-if="auth.can('manage_export_templates')">
        <div style="margin-bottom: 16px; display:flex; gap:12px; flex-wrap:wrap; align-items:flex-end">
          <el-upload
            :show-file-list="false"
            :before-upload="beforeUpload"
            :http-request="uploadTemplate"
            accept=".docx"
          >
            <el-button type="primary" :icon="Upload">رفع قالب Word جديد</el-button>
          </el-upload>
        </div>

        <!-- Upload form -->
        <el-dialog v-model="showUploadForm" title="معلومات القالب" width="420px">
          <el-form :model="uploadForm" label-position="top">
            <el-form-item label="اسم القالب">
              <el-input v-model="uploadForm.name" />
            </el-form-item>
            <el-form-item label="الجدول المرتبط">
              <el-select v-model="uploadForm.table_name" style="width:100%">
                <el-option label="المناطق" value="area" />
                <el-option label="الموظفون" value="employee" />
                <el-option label="قرارات المكافآت" value="awardes" />
                <el-option label="الوظائف" value="empjob" />
                <el-option label="الدرجات" value="awdeg" />
              </el-select>
            </el-form-item>
            <el-form-item label="نوع التصدير">
              <el-radio-group v-model="uploadForm.export_type">
                <el-radio value="table_only">بيانات الجدول فقط</el-radio>
                <el-radio value="related">مع البيانات المرتبطة</el-radio>
              </el-radio-group>
            </el-form-item>
            <el-form-item>
              <el-switch v-model="uploadForm.is_default" active-text="قالب افتراضي" />
            </el-form-item>
          </el-form>
          <template #footer>
            <el-button @click="showUploadForm = false">إلغاء</el-button>
            <el-button type="primary" :loading="uploading" @click="doUpload">رفع</el-button>
          </template>
        </el-dialog>

        <el-table :data="templates" v-loading="loadingTemplates" stripe>
          <el-table-column prop="id" label="#" width="60" />
          <el-table-column prop="name" label="الاسم" />
          <el-table-column prop="table_name" label="الجدول" width="120" />
          <el-table-column prop="export_type" label="النوع" width="160">
            <template #default="{ row }">
              <el-tag size="small">{{ row.export_type === 'related' ? 'مع المرتبطة' : 'جدول فقط' }}</el-tag>
            </template>
          </el-table-column>
          <el-table-column label="افتراضي" width="90">
            <template #default="{ row }">
              <el-tag type="success" v-if="row.is_default">نعم</el-tag>
            </template>
          </el-table-column>
          <el-table-column prop="created_at" label="تاريخ الرفع" width="150">
            <template #default="{ row }">{{ dayjs(row.created_at).format('YYYY/MM/DD') }}</template>
          </el-table-column>
        </el-table>
      </el-tab-pane>

      <!-- Groups management -->
      <el-tab-pane label="مجموعات الصلاحيات" v-if="auth.can('view_group')">
        <div style="margin-bottom:12px">
          <el-button type="primary" :icon="Plus" v-if="auth.can('add_group')" @click="openGroupForm()">
            إضافة مجموعة
          </el-button>
        </div>
        <el-table :data="groups" stripe>
          <el-table-column prop="id" label="#" width="60" />
          <el-table-column prop="name" label="اسم المجموعة" />
          <el-table-column label="الصلاحيات">
            <template #default="{ row }">
              <el-tag v-for="p in row.permissions?.slice(0,4)" :key="p.id" size="small" style="margin-left:3px">{{ p.codename }}</el-tag>
              <el-tag v-if="row.permissions?.length > 4" type="info" size="small">+{{ row.permissions.length - 4 }}</el-tag>
            </template>
          </el-table-column>
        </el-table>
      </el-tab-pane>

      <!-- Profile settings -->
      <el-tab-pane label="الملف الشخصي">
        <el-descriptions :column="2" border>
          <el-descriptions-item label="الاسم">{{ auth.user?.full_name }}</el-descriptions-item>
          <el-descriptions-item label="البريد الإلكتروني">{{ auth.user?.email }}</el-descriptions-item>
          <el-descriptions-item label="رقم الملف">{{ auth.user?.employee_number || '—' }}</el-descriptions-item>
          <el-descriptions-item label="مشرف عام">
            <el-tag :type="auth.user?.global_admin ? 'warning' : 'info'">
              {{ auth.user?.global_admin ? 'نعم' : 'لا' }}
            </el-tag>
          </el-descriptions-item>
          <el-descriptions-item label="تاريخ الانضمام">
            {{ dayjs(auth.user?.date_joined).format('YYYY/MM/DD') }}
          </el-descriptions-item>
          <el-descriptions-item label="آخر دخول">
            {{ auth.user?.last_login ? dayjs(auth.user.last_login).format('YYYY/MM/DD HH:mm') : '—' }}
          </el-descriptions-item>
        </el-descriptions>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { useAuthStore } from '@/stores/auth'
import { exportApi, userApi } from '@/api'
import { ElMessage } from 'element-plus'
import { Upload, Plus } from '@element-plus/icons-vue'
import dayjs from 'dayjs'

const auth = useAuthStore()
const templates = ref([])
const groups = ref([])
const loadingTemplates = ref(false)
const uploading = ref(false)
const showUploadForm = ref(false)
const pendingFile = ref(null)

const uploadForm = reactive({
  name: '', table_name: 'awardes',
  export_type: 'related', is_default: false
})

async function loadTemplates() {
  loadingTemplates.value = true
  try {
    const { data } = await exportApi.templates()
    templates.value = data
  } finally { loadingTemplates.value = false }
}

async function loadGroups() {
  const { data } = await userApi.groups()
  groups.value = data
}

function beforeUpload(file) {
  pendingFile.value = file
  showUploadForm.value = true
  return false // prevent auto upload
}

function uploadTemplate() {} // handled manually

async function doUpload() {
  if (!pendingFile.value) return
  uploading.value = true
  try {
    const fd = new FormData()
    fd.append('file', pendingFile.value)
    fd.append('name', uploadForm.name || pendingFile.value.name)
    fd.append('table_name', uploadForm.table_name)
    fd.append('export_type', uploadForm.export_type)
    fd.append('is_default', uploadForm.is_default)
    await exportApi.uploadTemplate(fd)
    ElMessage.success('تم رفع القالب')
    showUploadForm.value = false
    pendingFile.value = null
    loadTemplates()
  } catch {
    ElMessage.error('فشل الرفع')
  } finally {
    uploading.value = false
  }
}

function openGroupForm() {}

onMounted(() => {
  if (auth.can('manage_export_templates')) loadTemplates()
  if (auth.can('view_group')) loadGroups()
})
</script>

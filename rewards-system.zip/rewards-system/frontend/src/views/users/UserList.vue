<template>
  <div>
    <div class="page-header">
      <h1><el-icon><UserFilled /></el-icon> إدارة المستخدمين</h1>
    </div>
    <DataTable
      :data="users" :total="total" :loading="loading"
      row-key="id" search-placeholder="بحث بالاسم أو البريد..."
      add-label="مستخدم جديد"
      :can-add="auth.can('add_user')"
      :can-edit="auth.can('change_user')"
      :can-delete="auth.can('delete_user')"
      @add="openForm()" @edit="openForm($event)" @delete="doDelete($event)"
      @search="q => { params.search = q; load() }"
      @page-change="p => { params.page = p.page; load() }"
    >
      <el-table-column prop="id" label="#" width="60" />
      <el-table-column label="الاسم">
        <template #default="{ row }">
          <div style="display:flex; align-items:center; gap:8px">
            <el-avatar :size="32" :src="row.avatar_url">{{ row.full_name?.[0] }}</el-avatar>
            {{ row.full_name }}
          </div>
        </template>
      </el-table-column>
      <el-table-column prop="email" label="البريد الإلكتروني" />
      <el-table-column prop="employee_number" label="رقم الملف" width="100" />
      <el-table-column label="الحالة" width="90">
        <template #default="{ row }">
          <el-tag :type="row.is_active ? 'success' : 'danger'">
            {{ row.is_active ? 'نشط' : 'معطل' }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column label="مشرف عام" width="100">
        <template #default="{ row }">
          <el-tag v-if="row.global_admin" type="warning">نعم</el-tag>
          <span v-else>—</span>
        </template>
      </el-table-column>
      <el-table-column label="المجموعات">
        <template #default="{ row }">
          <el-tag v-for="g in row.groups" :key="g.id" size="small" style="margin-left: 4px">{{ g.name }}</el-tag>
        </template>
      </el-table-column>
    </DataTable>

    <!-- User form dialog -->
    <el-dialog v-model="showForm" :title="editRow ? 'تعديل مستخدم' : 'مستخدم جديد'" width="560px">
      <el-form :model="form" :rules="rules" ref="formRef" label-position="top">
        <el-row :gutter="16">
          <el-col :span="12">
            <el-form-item label="الاسم الكامل" prop="full_name">
              <el-input v-model="form.full_name" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="رقم الملف الوظيفي">
              <el-input v-model="form.employee_number" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-form-item label="البريد الإلكتروني" prop="email">
          <el-input v-model="form.email" type="email" />
        </el-form-item>
        <el-form-item label="كلمة المرور" :prop="editRow ? '' : 'password'">
          <el-input v-model="form.password" type="password" show-password
            :placeholder="editRow ? 'اتركه فارغاً للإبقاء على الحالي' : 'أدخل كلمة المرور'" />
        </el-form-item>
        <el-row :gutter="16">
          <el-col :span="12">
            <el-form-item label="الحالة">
              <el-switch v-model="form.is_active" active-text="نشط" inactive-text="معطل" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="مشرف عام">
              <el-switch v-model="form.global_admin" active-text="نعم" inactive-text="لا" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-form-item label="المجموعات">
          <el-select v-model="form.group_ids" multiple style="width:100%" placeholder="اختر المجموعات">
            <el-option v-for="g in groupOptions" :key="g.id" :label="g.name" :value="g.id" />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showForm = false">إلغاء</el-button>
        <el-button type="primary" :loading="saving" @click="save">حفظ</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { useAuthStore } from '@/stores/auth'
import { userApi } from '@/api'
import { ElMessage, ElMessageBox } from 'element-plus'
import DataTable from '@/components/common/DataTable.vue'

const auth = useAuthStore()
const users = ref([])
const total = ref(0)
const loading = ref(false)
const saving = ref(false)
const showForm = ref(false)
const editRow = ref(null)
const formRef = ref()
const groupOptions = ref([])

const params = reactive({ page: 1, page_size: 25, search: '' })
const form = reactive({
  full_name: '', email: '', employee_number: '', password: '',
  is_active: true, global_admin: false, group_ids: []
})
const rules = {
  full_name: [{ required: true, message: 'الاسم مطلوب' }],
  email: [{ required: true, type: 'email', message: 'البريد غير صحيح' }],
  password: [{ required: true, message: 'كلمة المرور مطلوبة للمستخدم الجديد' }]
}

async function load() {
  loading.value = true
  try {
    const { data } = await userApi.list(params)
    users.value = data.items; total.value = data.total
  } finally { loading.value = false }
}

async function loadGroups() {
  const { data } = await userApi.groups()
  groupOptions.value = data
}

function openForm(row = null) {
  editRow.value = row
  Object.assign(form, {
    full_name: row?.full_name || '',
    email: row?.email || '',
    employee_number: row?.employee_number || '',
    password: '',
    is_active: row?.is_active ?? true,
    global_admin: row?.global_admin ?? false,
    group_ids: row?.groups?.map(g => g.id) || []
  })
  showForm.value = true
  formRef.value?.clearValidate()
}

async function save() {
  const valid = await formRef.value?.validate().catch(() => false)
  if (!valid) return
  saving.value = true
  try {
    const payload = { ...form }
    if (!payload.password) delete payload.password

    if (editRow.value) {
      await userApi.update(editRow.value.id, payload)
      // Sync groups
      const currentGroups = editRow.value.groups?.map(g => g.id) || []
      const toAdd = form.group_ids.filter(id => !currentGroups.includes(id))
      const toRemove = currentGroups.filter(id => !form.group_ids.includes(id))
      await Promise.all([
        ...toAdd.map(gid => userApi.assignGroup(editRow.value.id, gid)),
        ...toRemove.map(gid => userApi.removeGroup(editRow.value.id, gid))
      ])
    } else {
      const { data } = await userApi.create(payload)
      for (const gid of form.group_ids) {
        await userApi.assignGroup(data.id, gid)
      }
    }
    ElMessage.success('تم الحفظ')
    showForm.value = false; load()
  } catch (e) {
    ElMessage.error(e.response?.data?.detail || 'حدث خطأ')
  } finally {
    saving.value = false
  }
}

async function doDelete(row) {
  await ElMessageBox.confirm('هل تريد حذف هذا المستخدم؟', 'تأكيد', { type: 'warning', confirmButtonText: 'حذف', cancelButtonText: 'إلغاء' })
  await userApi.delete(row.id)
  ElMessage.success('تم الحذف'); load()
}

onMounted(() => { load(); loadGroups() })
</script>

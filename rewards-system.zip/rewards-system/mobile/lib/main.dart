import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:go_router/go_router.dart';
import 'services/api_service.dart';
import 'services/auth_service.dart';
import 'screens/login_screen.dart';
import 'screens/dashboard_screen.dart';
import 'screens/employees_screen.dart';
import 'screens/awards_screen.dart';
import 'screens/areas_screen.dart';

void main() {
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthService()),
        Provider(create: (_) => ApiService()),
      ],
      child: const RewardsApp(),
    ),
  );
}

class RewardsApp extends StatelessWidget {
  const RewardsApp({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthService>();

    final router = GoRouter(
      initialLocation: auth.isLoggedIn ? '/' : '/login',
      redirect: (ctx, state) {
        final loggedIn = context.read<AuthService>().isLoggedIn;
        if (!loggedIn && state.uri.path != '/login') return '/login';
        if (loggedIn && state.uri.path == '/login') return '/';
        return null;
      },
      routes: [
        GoRoute(path: '/login', builder: (_, __) => const LoginScreen()),
        ShellRoute(
          builder: (ctx, state, child) => MainShell(child: child),
          routes: [
            GoRoute(path: '/', builder: (_, __) => const DashboardScreen()),
            GoRoute(path: '/employees', builder: (_, __) => const EmployeesScreen()),
            GoRoute(path: '/awards', builder: (_, __) => const AwardsScreen()),
            GoRoute(path: '/areas', builder: (_, __) => const AreasScreen()),
          ],
        ),
      ],
    );

    return MaterialApp.router(
      title: 'نظام المكافآت',
      debugShowCheckedModeBanner: false,
      routerConfig: router,
      theme: ThemeData(
        colorSchemeSeed: const Color(0xFF2563EB),
        useMaterial3: true,
        fontFamily: 'Cairo',
      ),
      locale: const Locale('ar'),
      builder: (ctx, child) => Directionality(
        textDirection: TextDirection.rtl,
        child: child!,
      ),
    );
  }
}

// ─── Main Shell with bottom navigation ────────────────────────────────────────
class MainShell extends StatefulWidget {
  final Widget child;
  const MainShell({super.key, required this.child});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _selectedIndex = 0;

  final _destinations = const [
    (path: '/',            icon: Icons.dashboard,     label: 'الرئيسية'),
    (path: '/employees',   icon: Icons.people,        label: 'الموظفون'),
    (path: '/awards',      icon: Icons.emoji_events,  label: 'المكافآت'),
    (path: '/areas',       icon: Icons.location_on,   label: 'المناطق'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: widget.child,
      bottomNavigationBar: NavigationBar(
        selectedIndex: _selectedIndex,
        onDestinationSelected: (i) {
          setState(() => _selectedIndex = i);
          context.go(_destinations[i].path);
        },
        destinations: _destinations.map((d) => NavigationDestination(
          icon: Icon(d.icon),
          label: d.label,
        )).toList(),
      ),
    );
  }
}

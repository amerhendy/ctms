export 'dashboard_screen.dart' show AreasScreen;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/api_service.dart';
import '../services/auth_service.dart';

// ─── Dashboard ─────────────────────────────────────────────────────────────────
class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});
  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  Map<String, int> stats = {};
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _loadStats();
  }

  Future<void> _loadStats() async {
    final api = context.read<ApiService>();
    try {
      final results = await Future.wait([
        api.get('/employees', params: {'page_size': '1'}),
        api.get('/awards', params: {'page_size': '1'}),
        api.get('/areas', params: {'page_size': '1'}),
      ]);
      if (mounted) {
        setState(() {
          stats = {
            'employees': results[0]['total'] as int,
            'awards': results[1]['total'] as int,
            'areas': results[2]['total'] as int,
          };
          loading = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = context.read<AuthService>().user;
    return Scaffold(
      appBar: AppBar(
        title: const Text('لوحة التحكم'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () => context.read<AuthService>().logout(),
          )
        ],
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _loadStats,
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  if (user != null)
                    Card(
                      color: const Color(0xFF2563EB),
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Row(
                          children: [
                            CircleAvatar(
                              backgroundColor: Colors.white24,
                              child: Text(user['full_name']?[0] ?? '?',
                                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                            ),
                            const SizedBox(width: 12),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(user['full_name'] ?? '', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
                                Text(user['email'] ?? '', style: const TextStyle(color: Colors.white70, fontSize: 13)),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  const SizedBox(height: 16),
                  _StatCard(label: 'الموظفون', value: stats['employees'] ?? 0, icon: Icons.people, color: const Color(0xFF2563EB)),
                  const SizedBox(height: 12),
                  _StatCard(label: 'قرارات المكافآت', value: stats['awards'] ?? 0, icon: Icons.emoji_events, color: const Color(0xFF7c3aed)),
                  const SizedBox(height: 12),
                  _StatCard(label: 'المناطق', value: stats['areas'] ?? 0, icon: Icons.location_on, color: const Color(0xFFd97706)),
                ],
              ),
            ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String label;
  final int value;
  final IconData icon;
  final Color color;
  const _StatCard({required this.label, required this.value, required this.icon, required this.color});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        leading: Container(
          width: 48, height: 48,
          decoration: BoxDecoration(color: color.withOpacity(.12), borderRadius: BorderRadius.circular(12)),
          child: Icon(icon, color: color, size: 26),
        ),
        title: Text(value.toString(), style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: color)),
        subtitle: Text(label, style: const TextStyle(fontSize: 14)),
      ),
    );
  }
}


// ─── Employees ─────────────────────────────────────────────────────────────────
class EmployeesScreen extends StatefulWidget {
  const EmployeesScreen({super.key});
  @override
  State<EmployeesScreen> createState() => _EmployeesScreenState();
}

class _EmployeesScreenState extends State<EmployeesScreen> {
  List items = [];
  int total = 0;
  bool loading = true;
  int page = 1;
  String search = '';
  final _searchCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => loading = true);
    try {
      final data = await context.read<ApiService>().get('/employees', params: {
        'page': page.toString(), 'page_size': '20', 'search': search,
      });
      if (mounted) setState(() { items = data['items']; total = data['total']; loading = false; });
    } catch (_) {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الموظفون')),
      floatingActionButton: context.read<AuthService>().can('add_employee')
          ? FloatingActionButton(onPressed: () => _showAddDialog(), child: const Icon(Icons.add))
          : null,
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: SearchBar(
              controller: _searchCtrl,
              hintText: 'بحث بالاسم أو رقم الملف...',
              leading: const Icon(Icons.search),
              onChanged: (v) { search = v; page = 1; _load(); },
            ),
          ),
          Expanded(
            child: loading
                ? const Center(child: CircularProgressIndicator())
                : RefreshIndicator(
                    onRefresh: _load,
                    child: ListView.builder(
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      itemCount: items.length,
                      itemBuilder: (_, i) {
                        final emp = items[i];
                        return Card(
                          margin: const EdgeInsets.only(bottom: 8),
                          child: ListTile(
                            leading: CircleAvatar(
                              child: Text(emp['emp_name']?[0] ?? '?'),
                            ),
                            title: Text(emp['emp_name'] ?? '—', style: const TextStyle(fontWeight: FontWeight.w600)),
                            subtitle: Text('${emp['file_number'] ?? '—'} | ${emp['area']?['area_name'] ?? '—'}'),
                            trailing: const Icon(Icons.arrow_forward_ios, size: 14),
                          ),
                        );
                      },
                    ),
                  ),
          ),
          if (total > 0)
            Padding(
              padding: const EdgeInsets.all(8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  TextButton(onPressed: page > 1 ? () { page--; _load(); } : null, child: const Text('السابق')),
                  Text('$page / ${(total / 20).ceil()}'),
                  TextButton(onPressed: page * 20 < total ? () { page++; _load(); } : null, child: const Text('التالي')),
                ],
              ),
            ),
        ],
      ),
    );
  }

  void _showAddDialog() {
    final nameCtrl = TextEditingController();
    final fileCtrl = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('إضافة موظف'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'الاسم الكامل')),
          const SizedBox(height: 12),
          TextField(controller: fileCtrl, decoration: const InputDecoration(labelText: 'رقم الملف'), maxLength: 6),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          ElevatedButton(
            onPressed: () async {
              await context.read<ApiService>().post('/employees', {'emp_name': nameCtrl.text, 'file_number': fileCtrl.text});
              if (mounted) Navigator.pop(ctx);
              _load();
            },
            child: const Text('حفظ'),
          ),
        ],
      ),
    );
  }
}


// ─── Awards ────────────────────────────────────────────────────────────────────
class AwardsScreen extends StatefulWidget {
  const AwardsScreen({super.key});
  @override
  State<AwardsScreen> createState() => _AwardsScreenState();
}

class _AwardsScreenState extends State<AwardsScreen> {
  List items = [];
  int total = 0;
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => loading = true);
    try {
      final data = await context.read<ApiService>().get('/awards', params: {'page': '1', 'page_size': '30', 'sort_dir': 'desc'});
      if (mounted) setState(() { items = data['items']; total = data['total']; loading = false; });
    } catch (_) {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('قرارات المكافآت')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView.builder(
                padding: const EdgeInsets.all(12),
                itemCount: items.length,
                itemBuilder: (_, i) {
                  final a = items[i];
                  return Card(
                    margin: const EdgeInsets.only(bottom: 8),
                    child: ListTile(
                      leading: Container(
                        width: 44, height: 44,
                        decoration: BoxDecoration(color: Colors.amber.shade100, borderRadius: BorderRadius.circular(10)),
                        child: const Icon(Icons.emoji_events, color: Colors.amber),
                      ),
                      title: Text(a['award_title'] ?? '—', style: const TextStyle(fontWeight: FontWeight.w600)),
                      subtitle: Text(a['award_date']?.toString().substring(0, 10) ?? '—'),
                    ),
                  );
                },
              ),
            ),
    );
  }
}


// ─── Areas ─────────────────────────────────────────────────────────────────────
class AreasScreen extends StatefulWidget {
  const AreasScreen({super.key});
  @override
  State<AreasScreen> createState() => _AreasScreenState();
}

class _AreasScreenState extends State<AreasScreen> {
  List items = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => loading = true);
    try {
      final data = await context.read<ApiService>().get('/areas', params: {'page_size': '100'});
      if (mounted) setState(() { items = data['items']; loading = false; });
    } catch (_) {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('المناطق')),
      floatingActionButton: FloatingActionButton(onPressed: _showAdd, child: const Icon(Icons.add)),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView.builder(
                padding: const EdgeInsets.all(12),
                itemCount: items.length,
                itemBuilder: (_, i) {
                  final a = items[i];
                  return Card(
                    margin: const EdgeInsets.only(bottom: 8),
                    child: ListTile(
                      leading: const Icon(Icons.location_on, color: Colors.orange),
                      title: Text(a['area_name'] ?? '—', style: const TextStyle(fontWeight: FontWeight.w600)),
                      subtitle: Text('${a['employees']?.length ?? 0} موظف'),
                    ),
                  );
                },
              ),
            ),
    );
  }

  void _showAdd() {
    final ctrl = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('إضافة منطقة'),
        content: TextField(controller: ctrl, decoration: const InputDecoration(labelText: 'اسم المنطقة')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          ElevatedButton(
            onPressed: () async {
              await context.read<ApiService>().post('/areas', {'area_name': ctrl.text});
              if (mounted) Navigator.pop(ctx);
              _load();
            },
            child: const Text('حفظ'),
          ),
        ],
      ),
    );
  }
}

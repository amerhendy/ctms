import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'api_service.dart';

const _storage = FlutterSecureStorage();

class AuthService extends ChangeNotifier {
  Map<String, dynamic>? _user;
  bool _isLoggedIn = false;

  bool get isLoggedIn => _isLoggedIn;
  Map<String, dynamic>? get user => _user;

  AuthService() {
    _restoreSession();
  }

  Future<void> _restoreSession() async {
    final token = await _storage.read(key: 'access_token');
    if (token != null) {
      _isLoggedIn = true;
      notifyListeners();
    }
  }

  Future<void> login(String username, String password) async {
    final api = ApiService();
    final data = await api.post('/auth/login', {
      'username': username,
      'password': password,
    });
    await _storage.write(key: 'access_token', value: data['access_token']);
    await _storage.write(key: 'refresh_token', value: data['refresh_token']);
    _user = data['user'];
    _isLoggedIn = true;
    notifyListeners();
  }

  Future<void> logout() async {
    try {
      final api = ApiService();
      await api.post('/auth/logout', {});
    } catch (_) {}
    await _storage.deleteAll();
    _user = null;
    _isLoggedIn = false;
    notifyListeners();
  }

  bool can(String codename) {
    if (_user == null) return false;
    if (_user!['global_admin'] == true) return true;
    final groups = _user!['groups'] as List? ?? [];
    for (final g in groups) {
      final perms = g['permissions'] as List? ?? [];
      if (perms.any((p) => p['codename'] == codename)) return true;
    }
    return false;
  }
}
